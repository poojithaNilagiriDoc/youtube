
 const GOOGLE_API_KEY = "AIzaSyBAubYkDr5e2UiKeBY1IZwlhMifex3urdc"

export const YOUTUBE_VIDEOS_API =
'https://youtube.googleapis.com/youtube/v3/videos?part=snippet%2CcontentDetails%2Cstatistics&chart=mostPopular&maxResults=50&regionCode=IN&key='+ GOOGLE_API_KEY ;



// https://youtube.googleapis.com/youtube/v3/videos?part=snippet%2CcontentDetails%2Cstatistics&chart=mostPopular&maxResults=50&regionCode=IN&key=AIzaSyBAubYkDr5e2UiKeBY1IZwlhMifex3urdc

// AIzaSyA8yub88TQZa1F29ekX-kHsSyHplnZcLgk


 export const searchResultAPI = 'https://youtube.googleapis.com/youtube/v3/search?part=snippet&maxResults=25&key=AIzaSyBAubYkDr5e2UiKeBY1IZwlhMifex3urdc&q='

  export const commentData= 'https://youtube.googleapis.com/youtube/v3/comment?part=snippet%2CcontentDetails%2Cstatistics&chart=mostPopular&maxResults=50&regionCode=IN&key=AIzaSyA8yub88TQZa1F29ekX-kHsSyHplnZcLgk' 

  export const YOUTUBE_SEARCH_API ="https://suggestqueries.google.com/complete/search?client=firefox&ds=yt&q=" ;


  export const plyListData_API = 'https://youtube.googleapis.com/youtube/v3/playlists?part=snippet%2CcontentDetails&channelId=UC_x5XG1OV2P6uZZ5FSM9Ttw&maxResults=25&key=AIzaSyBAubYkDr5e2UiKeBY1IZwlhMifex3urdc'

  export const OFFSET_liveChat = 10;

  // Live chat>>>>>>>infinite scroll >>>>>>>Pagination


  export const videoData = [
    {
      "kind": "youtube#video",
      "etag": "I7P2abtrVVhn1Pi16ndlJJqz2sM",
      "id": "JRU8WHomWWE",
      "snippet": {
        "publishedAt": "2023-10-20T05:30:08Z",
        "channelId": "UCSM54qcBP60U61HOMm_SUqA",
        "title": "BOLERO - Elvish Yadav & Manisha Rani | Preetinder | Asees Kaur | Rajat Nagpal | Babbu | Anshul Garg",
        "description": "Anshul Garg presents Bolero featuring Elvish Yadav & Manisha Rani \n\nAudio credits :-\nSinger : Preetinder & Asees Kaur\nComposer : Preetinder\nLyrics : Babbu\nMusic : Rajat Nagpal\n\nVideo credits :-\nFeaturing Elvish Yadav & Manisha Rani \nDirector : Nitish Raizada\nDOP : Sukh Kamboj  \nEditor DI & Colorist  : Ismile \nAssistant Directors : Kevin Thakur \nLine Producer : R.S Films and production Production Assistant- Jadu, Rohit, Honey, Gogi & Aamir\nCostume Stylist : Rajat Manchanda\nHairstylist : Salman\nStill Photography : Akki\nArt Director : Pinky Art \nJimmy Gib : Gourav\nChoreographer : Smile masih\n\nPlayDMF Team:-\nFounder & CEO : Anshul Garg\nPlayDMF Project Head : Raghav Sharma \nPlayDMF Project Manager : Sankalp Garg\nArtist Manager : Gaurav Arora\nPlayDMF Team : Ashima Chauhan & Akshay Mahadik\nArtwork : Vicky Sandhu\nSpecial Thanks : Ingrooves Team \n\nhttps://www.ingrooves.com/\n\nIngrooves Team :-\nHead : Amit Sharma \nTeam : Nagesh Jadhav, Kajal Israni, Amol Suryavanshi, Lavanya Das & Nishtha Sikroria\n\nTravel and hospitality partner :- PRM Hospitality\n\nLyrics :-\nTumse pyar kahan hoga tum to faraar ho jaate ho*\n4 gaadiyan aati hain kalli ko milne aate ho*\nLogon ke jo haath jurhaate\nAake baithte pairon mein\nChoti choti baatein hoti\nRehti hain bade shehron mein\nTu baith ton sahi bolero mein\n\nTu poori hai meri aur adha gurgaon apna hai\n10 saal pehle karndiya jo ab logon k sapna hai\nRaaton ko to sune the fire hote hain*\nDopehron mein*\nChoti choti baatein hoti\nRehti hain bade shehron mein\nTu baith ton sahi bolero mein\n\nMinister lagte ho babbu itna na tamjham karo*\nDar lagta hai duniya se ab itna bhi na naam karo*\nMinister lagte ho elvish itna na tamjham karo*\nDar lagta hai duniya se ab itna bhi na naam karo*\nBas abhi to charche hote hain\nKuch apno mein kuch gairon mein\nChoti choti baatein hoti\nRehti hain bade shehron mein\nTu baith ton sahi bolero mein",
        "thumbnails": {
          "default": {
            "url": "https://i.ytimg.com/vi/JRU8WHomWWE/default.jpg",
            "width": 120,
            "height": 90
          },
          "medium": {
            "url": "https://i.ytimg.com/vi/JRU8WHomWWE/mqdefault.jpg",
            "width": 320,
            "height": 180
          },
          "high": {
            "url": "https://i.ytimg.com/vi/JRU8WHomWWE/hqdefault.jpg",
            "width": 480,
            "height": 360
          },
          "standard": {
            "url": "https://i.ytimg.com/vi/JRU8WHomWWE/sddefault.jpg",
            "width": 640,
            "height": 480
          },
          "maxres": {
            "url": "https://i.ytimg.com/vi/JRU8WHomWWE/maxresdefault.jpg",
            "width": 1280,
            "height": 720
          }
        },
        "channelTitle": "Play DMF",
        "tags": [
          "Desi Music Factory",
          "Latest Hindi Songs'",
          "New Songs",
          "Viral Song",
          "Trending",
          "latest punjabi songs",
          "latest haryanvi song",
          "official video",
          "most watched",
          "New Hindi Song",
          "elvisha",
          "Elvish Yadav",
          "Manisha Rani",
          "Elvish Yadav new song",
          "Elvish Manisha new song",
          "Bolero elvish new song",
          "latest song 2023",
          "new song 2023",
          "chore haryane aale",
          "Preetinder",
          "Asees kaur",
          "Rajat Nagpal",
          "Babbu",
          "Big boss elvish yadav",
          "big boss manisha rani",
          "Asees Kaur latest songs",
          "Elvish Yadav Vlogs",
          "Preetinder songs"
        ],
        "categoryId": "10",
        "liveBroadcastContent": "none",
        "localized": {
          "title": "BOLERO - Elvish Yadav & Manisha Rani | Preetinder | Asees Kaur | Rajat Nagpal | Babbu | Anshul Garg",
          "description": "Anshul Garg presents Bolero featuring Elvish Yadav & Manisha Rani \n\nAudio credits :-\nSinger : Preetinder & Asees Kaur\nComposer : Preetinder\nLyrics : Babbu\nMusic : Rajat Nagpal\n\nVideo credits :-\nFeaturing Elvish Yadav & Manisha Rani \nDirector : Nitish Raizada\nDOP : Sukh Kamboj  \nEditor DI & Colorist  : Ismile \nAssistant Directors : Kevin Thakur \nLine Producer : R.S Films and production Production Assistant- Jadu, Rohit, Honey, Gogi & Aamir\nCostume Stylist : Rajat Manchanda\nHairstylist : Salman\nStill Photography : Akki\nArt Director : Pinky Art \nJimmy Gib : Gourav\nChoreographer : Smile masih\n\nPlayDMF Team:-\nFounder & CEO : Anshul Garg\nPlayDMF Project Head : Raghav Sharma \nPlayDMF Project Manager : Sankalp Garg\nArtist Manager : Gaurav Arora\nPlayDMF Team : Ashima Chauhan & Akshay Mahadik\nArtwork : Vicky Sandhu\nSpecial Thanks : Ingrooves Team \n\nhttps://www.ingrooves.com/\n\nIngrooves Team :-\nHead : Amit Sharma \nTeam : Nagesh Jadhav, Kajal Israni, Amol Suryavanshi, Lavanya Das & Nishtha Sikroria\n\nTravel and hospitality partner :- PRM Hospitality\n\nLyrics :-\nTumse pyar kahan hoga tum to faraar ho jaate ho*\n4 gaadiyan aati hain kalli ko milne aate ho*\nLogon ke jo haath jurhaate\nAake baithte pairon mein\nChoti choti baatein hoti\nRehti hain bade shehron mein\nTu baith ton sahi bolero mein\n\nTu poori hai meri aur adha gurgaon apna hai\n10 saal pehle karndiya jo ab logon k sapna hai\nRaaton ko to sune the fire hote hain*\nDopehron mein*\nChoti choti baatein hoti\nRehti hain bade shehron mein\nTu baith ton sahi bolero mein\n\nMinister lagte ho babbu itna na tamjham karo*\nDar lagta hai duniya se ab itna bhi na naam karo*\nMinister lagte ho elvish itna na tamjham karo*\nDar lagta hai duniya se ab itna bhi na naam karo*\nBas abhi to charche hote hain\nKuch apno mein kuch gairon mein\nChoti choti baatein hoti\nRehti hain bade shehron mein\nTu baith ton sahi bolero mein"
        },
        "defaultAudioLanguage": "en"
      },
      "contentDetails": {
        "duration": "PT2M58S",
        "dimension": "2d",
        "definition": "hd",
        "caption": "false",
        "licensedContent": true,
        "contentRating": {
          
        },
        "projection": "rectangular"
      },
      "statistics": {
        "viewCount": "2911393",
        "likeCount": "452842",
        "favoriteCount": "0",
        "commentCount": "65998"
      }
    },
    {
      "kind": "youtube#video",
      "etag": "gatW1dmjcZC_7m48pYgkfZ3_ZeY",
      "id": "aDBzdcJvqTs",
      "snippet": {
        "publishedAt": "2023-10-20T05:30:13Z",
        "channelId": "UCbTLwN10NoCU4WDzLf1JMOA",
        "title": "Leke Prabhu Ka Naam Teaser | Tiger 3 | Salman Khan, Katrina Kaif | Pritam, Arijit, Nikhita, Amitabh",
        "description": "A dance number to vibe on is comin’ your way on 23rd Oct! #LekePrabhuKaNaam #Tiger3 arriving in cinemas on 12th November. Releasing in Hindi, Tamil & Telugu.\n► Subscribe Now: https://goo.gl/xs3mrY 🔔 Stay updated!\n► YRF New Releases: https://www.youtube.com/playlist?list=PLCB05E03DA939D484\n\n🎧 Song Credits:\nSong: Leke Prabhu Ka Naam\nMusic: Pritam\nLyrics: Amitabh Bhattacharya\nSingers: Arijit Singh, Nikhita Gandhi\nDirector of Choreography: Vaibhavi Merchant\nDirector of Photography - Song: Sahil Bhardwaj\nRecording At: YRF Studios\nMixed By: Vijay Dayal (YRF Studios), Chinmay Mestry (Assistant Mixing Engineer - YRF Studios)\nMastered By: Donal Whelan (Hafod Mastering, Wales - UK)\n\nStay in the filmy loop:\n► Like us on Facebook: Facebook/yrf\n► Follow us on Twitter: Twitter/yrf\n► Follow us on Instagram: Instagram/yrf\n► Visit us on: yashrajfilms.com\n\n🎬 Movie Credits:\nStarring: Salman Khan, Katrina Kaif, Emraan Hashmi\nDirector: Maneesh Sharma\nProducer: Aditya Chopra\nCo-Producer: Akshaye Widhani\nScreenplay: Shridhar Raghavan\nDirector of Photography: Anay Om Goswamy (ISC)\nMusic: Pritam\nLyrics: Irshad Kamil, Amitabh Bhattacharya\nDialogues: Anckur Chaudhry\nStory: Aditya Chopra\nAssociate Producer: Rishabh Chopra\nExecutive Producers: Sudhanshu Kumar, Sanjay Shivalkar\nProduction Designer: Mayur Sharma\nEditor: Rameshwar S. Bhagat\nDirector of Choreography: Vaibhavi Merchant\nSound: Pritam Das, Ganesh Gangadharan\nAction Directors: Franz Spilhaus, Oh Sea Young, Sunil Rodrigues (ROD)\nBackground Music: Tanuj Tiku\nCostume Designers: Anaita Shroff Adajania, Alvira Khan Agnihotri, Ashley Rebello, Darshan Jalan \nVisual Effects Studio: yFX\nCasting Director: Shanoo Sharma\nTrailers & Promos: Mohit Sajnaney\nRelease Date: 12 November 2023\n\nAbout YRF Spy Universe:\nYRF Spy Universe is a first of its kind cinematic universe of spy thriller films in India. The first film in the universe, \"Ek Tha Tiger,\" starring Salman Khan and Katrina Kaif was released in 2012, followed by its sequel \"Tiger Zinda Hai\" in 2017. The third film in the universe, \"War,\" was released in 2019 and starred Hrithik Roshan and Tiger Shroff in pivotal roles. The recent release Pathaan (2023) starring Shah Rukh Khan, Deepika Padukone and John Abraham is the fourth instalment in the spy universe franchise.\n\nAll the films of the Spy Universe are blockbusters with Pathaan being the all-time highest grossing Hindi film ever. The YRF Spy Universe is now one of the biggest IP’s in the history of Indian cinema. The next film from this franchise is Tiger 3 releasing this Diwali!\n\nYRF Spy Universe films boast of incredible visual spectacles with high-octane action sequences, thrilling plot-lines, power-packed characters and musical chartbusters.\n\n#YRFSpyUniverse #yrfnewreleases #yrf50 #yrf #yashraj #yashrajfilms #yrfmovies #yrfmusic #yashchopra #adityachopra #salmankhan #katrinakaif #emraanhashmi #maneeshsharma #arijitsingh #nikhitagandhi #pritam #amitabhbhattacharya #newsong #tiger3songteaser\n\n© Yash Raj Films Pvt. Ltd.",
        "thumbnails": {
          "default": {
            "url": "https://i.ytimg.com/vi/aDBzdcJvqTs/default.jpg",
            "width": 120,
            "height": 90
          },
          "medium": {
            "url": "https://i.ytimg.com/vi/aDBzdcJvqTs/mqdefault.jpg",
            "width": 320,
            "height": 180
          },
          "high": {
            "url": "https://i.ytimg.com/vi/aDBzdcJvqTs/hqdefault.jpg",
            "width": 480,
            "height": 360
          },
          "standard": {
            "url": "https://i.ytimg.com/vi/aDBzdcJvqTs/sddefault.jpg",
            "width": 640,
            "height": 480
          },
          "maxres": {
            "url": "https://i.ytimg.com/vi/aDBzdcJvqTs/maxresdefault.jpg",
            "width": 1280,
            "height": 720
          }
        },
        "channelTitle": "YRF",
        "tags": [
          "salman khan",
          "katrina kaif",
          "tiger 3 song",
          "leke prabhu ka naam song",
          "salman khan song",
          "katrina kaif song",
          "leke prabhu ka naam song teaser",
          "tiger 3 song teaser",
          "salman khan new songs",
          "katrina kaif new songs",
          "tiger 3 new songs",
          "arijit singh songs",
          "nikhita gandhi songs",
          "arijtt singh tiger 3 songs",
          "arijit singh new songs",
          "new song",
          "new song 2023",
          "hindi songs",
          "new bollywood songs",
          "song teaser",
          "tiger song teaser",
          "salman khan tiger 3 song",
          "indian songs",
          "سلمان خان",
          "music",
          "yrf song"
        ],
        "categoryId": "10",
        "liveBroadcastContent": "none",
        "defaultLanguage": "en-GB",
        "localized": {
          "title": "Leke Prabhu Ka Naam Teaser | Tiger 3 | Salman Khan, Katrina Kaif | Pritam, Arijit, Nikhita, Amitabh",
          "description": "A dance number to vibe on is comin’ your way on 23rd Oct! #LekePrabhuKaNaam #Tiger3 arriving in cinemas on 12th November. Releasing in Hindi, Tamil & Telugu.\n► Subscribe Now: https://goo.gl/xs3mrY 🔔 Stay updated!\n► YRF New Releases: https://www.youtube.com/playlist?list=PLCB05E03DA939D484\n\n🎧 Song Credits:\nSong: Leke Prabhu Ka Naam\nMusic: Pritam\nLyrics: Amitabh Bhattacharya\nSingers: Arijit Singh, Nikhita Gandhi\nDirector of Choreography: Vaibhavi Merchant\nDirector of Photography - Song: Sahil Bhardwaj\nRecording At: YRF Studios\nMixed By: Vijay Dayal (YRF Studios), Chinmay Mestry (Assistant Mixing Engineer - YRF Studios)\nMastered By: Donal Whelan (Hafod Mastering, Wales - UK)\n\nStay in the filmy loop:\n► Like us on Facebook: Facebook/yrf\n► Follow us on Twitter: Twitter/yrf\n► Follow us on Instagram: Instagram/yrf\n► Visit us on: yashrajfilms.com\n\n🎬 Movie Credits:\nStarring: Salman Khan, Katrina Kaif, Emraan Hashmi\nDirector: Maneesh Sharma\nProducer: Aditya Chopra\nCo-Producer: Akshaye Widhani\nScreenplay: Shridhar Raghavan\nDirector of Photography: Anay Om Goswamy (ISC)\nMusic: Pritam\nLyrics: Irshad Kamil, Amitabh Bhattacharya\nDialogues: Anckur Chaudhry\nStory: Aditya Chopra\nAssociate Producer: Rishabh Chopra\nExecutive Producers: Sudhanshu Kumar, Sanjay Shivalkar\nProduction Designer: Mayur Sharma\nEditor: Rameshwar S. Bhagat\nDirector of Choreography: Vaibhavi Merchant\nSound: Pritam Das, Ganesh Gangadharan\nAction Directors: Franz Spilhaus, Oh Sea Young, Sunil Rodrigues (ROD)\nBackground Music: Tanuj Tiku\nCostume Designers: Anaita Shroff Adajania, Alvira Khan Agnihotri, Ashley Rebello, Darshan Jalan \nVisual Effects Studio: yFX\nCasting Director: Shanoo Sharma\nTrailers & Promos: Mohit Sajnaney\nRelease Date: 12 November 2023\n\nAbout YRF Spy Universe:\nYRF Spy Universe is a first of its kind cinematic universe of spy thriller films in India. The first film in the universe, \"Ek Tha Tiger,\" starring Salman Khan and Katrina Kaif was released in 2012, followed by its sequel \"Tiger Zinda Hai\" in 2017. The third film in the universe, \"War,\" was released in 2019 and starred Hrithik Roshan and Tiger Shroff in pivotal roles. The recent release Pathaan (2023) starring Shah Rukh Khan, Deepika Padukone and John Abraham is the fourth instalment in the spy universe franchise.\n\nAll the films of the Spy Universe are blockbusters with Pathaan being the all-time highest grossing Hindi film ever. The YRF Spy Universe is now one of the biggest IP’s in the history of Indian cinema. The next film from this franchise is Tiger 3 releasing this Diwali!\n\nYRF Spy Universe films boast of incredible visual spectacles with high-octane action sequences, thrilling plot-lines, power-packed characters and musical chartbusters.\n\n#YRFSpyUniverse #yrfnewreleases #yrf50 #yrf #yashraj #yashrajfilms #yrfmovies #yrfmusic #yashchopra #adityachopra #salmankhan #katrinakaif #emraanhashmi #maneeshsharma #arijitsingh #nikhitagandhi #pritam #amitabhbhattacharya #newsong #tiger3songteaser\n\n© Yash Raj Films Pvt. Ltd."
        },
        "defaultAudioLanguage": "hi"
      },
      "contentDetails": {
        "duration": "PT17S",
        "dimension": "2d",
        "definition": "hd",
        "caption": "false",
        "licensedContent": true,
        "contentRating": {
          
        },
        "projection": "rectangular"
      },
      "statistics": {
        "viewCount": "2172874",
        "likeCount": "140037",
        "favoriteCount": "0",
        "commentCount": "4475"
      }
    },
    {
      "kind": "youtube#video",
      "etag": "qnnq2tJGhRmFHT5VR442-bDc1Dc",
      "id": "-JFFtYCA8EA",
      "snippet": {
        "publishedAt": "2023-10-19T07:17:57Z",
        "channelId": "UCx6F-rETGiz7xf_vkMmX2yQ",
        "title": "I Hid in THE THUGESH SHOW",
        "description": "Today we  Sneak into the Thugesh Show which is Youtube's Biggest and Best Show by @Thugesh . Thugesh Show has featured Biggest indian Youtubers like Bhuvan Bam, Triggered Insaan, Fukra Insaan, Slayy Point and today I go inside the Thugesh Show and Hide from everyone including @FlyingBeast320 . This is one of my best videos and I hope you enjoy this Prank on Thugesh.\n\nmusic by @VasuKainth\nFur Elise Remix - https://www.youtube.com/watch?v=WheoGHREF60\n\nmy insta - https://www.instagram.com/mythpat",
        "thumbnails": {
          "default": {
            "url": "https://i.ytimg.com/vi/-JFFtYCA8EA/default.jpg",
            "width": 120,
            "height": 90
          },
          "medium": {
            "url": "https://i.ytimg.com/vi/-JFFtYCA8EA/mqdefault.jpg",
            "width": 320,
            "height": 180
          },
          "high": {
            "url": "https://i.ytimg.com/vi/-JFFtYCA8EA/hqdefault.jpg",
            "width": 480,
            "height": 360
          },
          "standard": {
            "url": "https://i.ytimg.com/vi/-JFFtYCA8EA/sddefault.jpg",
            "width": 640,
            "height": 480
          },
          "maxres": {
            "url": "https://i.ytimg.com/vi/-JFFtYCA8EA/maxresdefault.jpg",
            "width": 1280,
            "height": 720
          }
        },
        "channelTitle": "Mythpat",
        "tags": [
          "mythpat thugesh show",
          "mythpat pranks",
          "thugesh show episodes",
          "thugesh new video",
          "thugesh pranks",
          "funny indian pranks",
          "sneaking into the thugesh show"
        ],
        "categoryId": "24",
        "liveBroadcastContent": "none",
        "localized": {
          "title": "I Hid in THE THUGESH SHOW",
          "description": "Today we  Sneak into the Thugesh Show which is Youtube's Biggest and Best Show by @Thugesh . Thugesh Show has featured Biggest indian Youtubers like Bhuvan Bam, Triggered Insaan, Fukra Insaan, Slayy Point and today I go inside the Thugesh Show and Hide from everyone including @FlyingBeast320 . This is one of my best videos and I hope you enjoy this Prank on Thugesh.\n\nmusic by @VasuKainth\nFur Elise Remix - https://www.youtube.com/watch?v=WheoGHREF60\n\nmy insta - https://www.instagram.com/mythpat"
        }
      },
      "contentDetails": {
        "duration": "PT17M14S",
        "dimension": "2d",
        "definition": "hd",
        "caption": "false",
        "licensedContent": true,
        "contentRating": {
          
        },
        "projection": "rectangular"
      },
      "statistics": {
        "viewCount": "2297108",
        "likeCount": "230248",
        "favoriteCount": "0",
        "commentCount": "6576"
      }
    },
    {
      "kind": "youtube#video",
      "etag": "CXbpNpbuBQpnh9DFOX8RW5mLQOc",
      "id": "oB8QFjKhPkg",
      "snippet": {
        "publishedAt": "2023-10-19T18:10:41Z",
        "channelId": "UC2h1GsM_Ls1Cg6M-Mk42UYQ",
        "title": "देखिए,जीत के बाद अंपायर Richard Kettleborough ने Kohli का शतक बनवाने पर किया खुलासा कहा ऐसा सब हैरान",
        "description": "#HIGHLIGHTS #LIVE #IndiavsAustralia #Indvsauswtcfinal #indvsaus2023 #Ipl2023 #RohitSharma​  #ViratKohli​  #JaspritBumrah​ #RishabhPant​ #HardikPandya​ #RavindraJadeja​ #Shardulthakur #MsDhoni​ #SuryakumarYadav​ ​#ishankishan #UmranMalik #MohammedShami #klrahul #virendarsehwag  #davidwarner #usmankhawaja #marnuslabuschagne #stevesmith #Camerongreen #Mitchellstarc #scottboland #PATCUMMINS  #shoaibakhtar   #indvspak  #SPORTSEDGE\n \nदेखिए,जीत के बाद अंपायर Richard Kettleborough ने Kohli का शतक बनवाने पर किया खुलासा कहा ऐसा सब हैरान\n\nSubscribe SPORTS EDGE NEWS For Latest Cricket News and Videos...\nYouTube: https://www.youtube.com/c/SportsEdge007\n\nCOPYRIGHT DISCLAIMER\n_________________________________________________________\n\n\"Copyright Disclaimer Under Section 107 of the Copyright Act 1976, allowance is made for \"fair use\" for purposes such as criticism, comment, news reporting, teaching, scholarship, and research. Fair use is a use permitted by copyright statute that might otherwise be infringing. Non-profit, educational or personal use tips the balance in favour of fair use.\"",
        "thumbnails": {
          "default": {
            "url": "https://i.ytimg.com/vi/oB8QFjKhPkg/default.jpg",
            "width": 120,
            "height": 90
          },
          "medium": {
            "url": "https://i.ytimg.com/vi/oB8QFjKhPkg/mqdefault.jpg",
            "width": 320,
            "height": 180
          },
          "high": {
            "url": "https://i.ytimg.com/vi/oB8QFjKhPkg/hqdefault.jpg",
            "width": 480,
            "height": 360
          },
          "standard": {
            "url": "https://i.ytimg.com/vi/oB8QFjKhPkg/sddefault.jpg",
            "width": 640,
            "height": 480
          },
          "maxres": {
            "url": "https://i.ytimg.com/vi/oB8QFjKhPkg/maxresdefault.jpg",
            "width": 1280,
            "height": 720
          }
        },
        "channelTitle": "Sports Edge Cricket",
        "tags": [
          "virat kohli today century",
          "virat kohli last century in odi",
          "no of centuries of virat kohli",
          "virat kohli hundreds total",
          "virat kohli 78 century",
          "total 100 of virat kohli",
          "last century of virat kohli",
          "virat kohli goat meaning",
          "virat kohli last century",
          "total hundreds of virat kohli",
          "virat kohli total centuries in all format",
          "virat kohli hundreds",
          "virat kohli total centuries in all format including ipl",
          "total century of virat kohli",
          "virat kohli total international centuries"
        ],
        "categoryId": "17",
        "liveBroadcastContent": "none",
        "localized": {
          "title": "देखिए,जीत के बाद अंपायर Richard Kettleborough ने Kohli का शतक बनवाने पर किया खुलासा कहा ऐसा सब हैरान",
          "description": "#HIGHLIGHTS #LIVE #IndiavsAustralia #Indvsauswtcfinal #indvsaus2023 #Ipl2023 #RohitSharma​  #ViratKohli​  #JaspritBumrah​ #RishabhPant​ #HardikPandya​ #RavindraJadeja​ #Shardulthakur #MsDhoni​ #SuryakumarYadav​ ​#ishankishan #UmranMalik #MohammedShami #klrahul #virendarsehwag  #davidwarner #usmankhawaja #marnuslabuschagne #stevesmith #Camerongreen #Mitchellstarc #scottboland #PATCUMMINS  #shoaibakhtar   #indvspak  #SPORTSEDGE\n \nदेखिए,जीत के बाद अंपायर Richard Kettleborough ने Kohli का शतक बनवाने पर किया खुलासा कहा ऐसा सब हैरान\n\nSubscribe SPORTS EDGE NEWS For Latest Cricket News and Videos...\nYouTube: https://www.youtube.com/c/SportsEdge007\n\nCOPYRIGHT DISCLAIMER\n_________________________________________________________\n\n\"Copyright Disclaimer Under Section 107 of the Copyright Act 1976, allowance is made for \"fair use\" for purposes such as criticism, comment, news reporting, teaching, scholarship, and research. Fair use is a use permitted by copyright statute that might otherwise be infringing. Non-profit, educational or personal use tips the balance in favour of fair use.\""
        }
      },
      "contentDetails": {
        "duration": "PT4M23S",
        "dimension": "2d",
        "definition": "hd",
        "caption": "false",
        "licensedContent": true,
        "contentRating": {
          
        },
        "projection": "rectangular"
      },
      "statistics": {
        "viewCount": "2016717",
        "likeCount": "32463",
        "favoriteCount": "0",
        "commentCount": "1892"
      }
    },
    {
      "kind": "youtube#video",
      "etag": "JGOlirBkaaErqFtOS-0cDrrITbA",
      "id": "5oExKMYIE9U",
      "snippet": {
        "publishedAt": "2023-10-15T05:30:35Z",
        "channelId": "UCFFbwnve3yF62-tVXkTyHqg",
        "title": "KALAASTAR - Full Video | Honey 3.0 | Yo Yo Honey Singh & Sonakshi Sinha | Zee Music Originals",
        "description": "👉🏻 SUBSCRIBE to Zee Music Company - https://bit.ly/2yPcBkS \n\nTo Stream & Download Full Song: \nJioSaavn - https://bit.ly/4957LN0\nResso - https://bit.ly/3Qika8P\nGaana - https://bit.ly/3Qi5UNh\niTunes - https://apple.co/3RZQ1MD\nApple Music - https://apple.co/3RZQ1MD\nAmazon Prime Music - https://amzn.to/48Vglhi\nWynk Music - https://wynk.in/u/zEvRg7Y3Y\nHungama - https://bit.ly/3PUYJJB\nYouTube Music - https://bit.ly/3txAREp\n\nSong: Kalaastar\nSinger: Yo Yo Honey Singh\nFeaturing: Sonakshi Sinha\nComposer: Rony Ajnali & Gill Machhrai\nLyrics: Rony Ajnali & Gill Machhrai\nMusic: Bass Yogi \nMix & Master: Jaymeet\nGuitars: Faizan Rahman\nStory & Screenplay: Yo Yo Honey Singh\n\nProduced by: Zee Music Company\nDigital Strategy: RajDeep Mayer\nDirector: Jonas Beck\nLine Producer: Shanya Valies\nProduction Manager: Dilba Yasin\nDigital Marketing/Promotions: RDM Media\nPoster: RDM Media\nD.O.P: Tobias van Daal\n1st AC: Krijn Wintjes\nGaffer: Jan Nelemans\nBestboy: Mees Blaak\nLight Assistant: Leon de Haas\nSound Operator: Ralf de Krijger\nCrane Operator: Bram Marijnissen\n\nYYHS Management Team: Rohit Chhabra, Aanchal Kohli, Nikunj Khanna\n\nArt Director: Cheriva Volney\nArt Assistant: Charity Sumter\nProduction Assistant: Julie van Zolingen\nProduction Assistant: Yoshua Nahar\nMakeup Artist YYHS: Beyzanur Pinarbasi\nMakeup Artist Sonakshi: Heema Datani\nHairstylist Sonakshi: Hair By Jssca\nStylist Sonakshi: Sanam Ratansi\nActor Boyfriend Sonakshi: Alper Aykut Showpony\n\nEdit: Frogalised Productions\nGrading: Raoul Hulst - Crocodile Grading\n\nBig Thanks to:\nGrey Bottle Props\nBreda International Airport - Location Manager: Michiel van Dijk\nCamping Vliegenbos Amsterdam\nEventcity Aalsmeer\nTaets Art and Event Park\nPrison Escape and the city of Doetinchem, The Netherlands\nNhm Car Casting\n\n#yoyohoneysingh #sonakshisinha\n\n\nMusic on Zee Music Company\n\nConnect with us on :\nTwitter - https://www.twitter.com/ZeeMusicCompany\nFacebook - https://www.facebook.com/zeemusiccompany\nInstagram - https://www.instagram.com/zeemusiccompany\nYouTube - http://bit.ly/TYZMC",
        "thumbnails": {
          "default": {
            "url": "https://i.ytimg.com/vi/5oExKMYIE9U/default.jpg",
            "width": 120,
            "height": 90
          },
          "medium": {
            "url": "https://i.ytimg.com/vi/5oExKMYIE9U/mqdefault.jpg",
            "width": 320,
            "height": 180
          },
          "high": {
            "url": "https://i.ytimg.com/vi/5oExKMYIE9U/hqdefault.jpg",
            "width": 480,
            "height": 360
          },
          "standard": {
            "url": "https://i.ytimg.com/vi/5oExKMYIE9U/sddefault.jpg",
            "width": 640,
            "height": 480
          },
          "maxres": {
            "url": "https://i.ytimg.com/vi/5oExKMYIE9U/maxresdefault.jpg",
            "width": 1280,
            "height": 720
          }
        },
        "channelTitle": "Zee Music Company",
        "tags": [
          "kalaastar teaser",
          "kalaastar song",
          "kalaastar",
          "kalaastar honey singh",
          "yo yo honey singh",
          "kalaastar official song",
          "yo yo honey singh new song",
          "yo yo honey singh songs",
          "kalaastar yo yo honey singh",
          "new honey singh songs",
          "latest honey singh songs",
          "kalaastar honey song",
          "sonakshi sinha new songs",
          "sonakshi sinha songs",
          "honey singh new songs",
          "kalastar",
          "kalastaar",
          "kala star",
          "kalaa star",
          "sonakshi",
          "kalaastar song yo yo honey singh",
          "kalastar honey",
          "desi kalakar",
          "honey 3.0",
          "honey singh songs"
        ],
        "categoryId": "10",
        "liveBroadcastContent": "none",
        "localized": {
          "title": "KALAASTAR - Full Video | Honey 3.0 | Yo Yo Honey Singh & Sonakshi Sinha | Zee Music Originals",
          "description": "👉🏻 SUBSCRIBE to Zee Music Company - https://bit.ly/2yPcBkS \n\nTo Stream & Download Full Song: \nJioSaavn - https://bit.ly/4957LN0\nResso - https://bit.ly/3Qika8P\nGaana - https://bit.ly/3Qi5UNh\niTunes - https://apple.co/3RZQ1MD\nApple Music - https://apple.co/3RZQ1MD\nAmazon Prime Music - https://amzn.to/48Vglhi\nWynk Music - https://wynk.in/u/zEvRg7Y3Y\nHungama - https://bit.ly/3PUYJJB\nYouTube Music - https://bit.ly/3txAREp\n\nSong: Kalaastar\nSinger: Yo Yo Honey Singh\nFeaturing: Sonakshi Sinha\nComposer: Rony Ajnali & Gill Machhrai\nLyrics: Rony Ajnali & Gill Machhrai\nMusic: Bass Yogi \nMix & Master: Jaymeet\nGuitars: Faizan Rahman\nStory & Screenplay: Yo Yo Honey Singh\n\nProduced by: Zee Music Company\nDigital Strategy: RajDeep Mayer\nDirector: Jonas Beck\nLine Producer: Shanya Valies\nProduction Manager: Dilba Yasin\nDigital Marketing/Promotions: RDM Media\nPoster: RDM Media\nD.O.P: Tobias van Daal\n1st AC: Krijn Wintjes\nGaffer: Jan Nelemans\nBestboy: Mees Blaak\nLight Assistant: Leon de Haas\nSound Operator: Ralf de Krijger\nCrane Operator: Bram Marijnissen\n\nYYHS Management Team: Rohit Chhabra, Aanchal Kohli, Nikunj Khanna\n\nArt Director: Cheriva Volney\nArt Assistant: Charity Sumter\nProduction Assistant: Julie van Zolingen\nProduction Assistant: Yoshua Nahar\nMakeup Artist YYHS: Beyzanur Pinarbasi\nMakeup Artist Sonakshi: Heema Datani\nHairstylist Sonakshi: Hair By Jssca\nStylist Sonakshi: Sanam Ratansi\nActor Boyfriend Sonakshi: Alper Aykut Showpony\n\nEdit: Frogalised Productions\nGrading: Raoul Hulst - Crocodile Grading\n\nBig Thanks to:\nGrey Bottle Props\nBreda International Airport - Location Manager: Michiel van Dijk\nCamping Vliegenbos Amsterdam\nEventcity Aalsmeer\nTaets Art and Event Park\nPrison Escape and the city of Doetinchem, The Netherlands\nNhm Car Casting\n\n#yoyohoneysingh #sonakshisinha\n\n\nMusic on Zee Music Company\n\nConnect with us on :\nTwitter - https://www.twitter.com/ZeeMusicCompany\nFacebook - https://www.facebook.com/zeemusiccompany\nInstagram - https://www.instagram.com/zeemusiccompany\nYouTube - http://bit.ly/TYZMC"
        },
        "defaultAudioLanguage": "hi"
      },
      "contentDetails": {
        "duration": "PT4M30S",
        "dimension": "2d",
        "definition": "hd",
        "caption": "true",
        "licensedContent": true,
        "contentRating": {
          
        },
        "projection": "rectangular"
      },
      "statistics": {
        "viewCount": "72980445",
        "likeCount": "8141401",
        "favoriteCount": "0",
        "commentCount": "844803"
      }
    },
    {
      "kind": "youtube#video",
      "etag": "YStRn905pxAWKp48ifR8wJVI_F0",
      "id": "vEjTUDjjU6A",
      "snippet": {
        "publishedAt": "2023-10-16T06:30:08Z",
        "channelId": "UCbTLwN10NoCU4WDzLf1JMOA",
        "title": "Tiger 3 Trailer | Salman Khan, Katrina Kaif, Emraan Hashmi | Maneesh Sharma | YRF Spy Universe",
        "description": "Tiger and Zoya are back - to save the country and their family. This time it’s personal! #Tiger3 arriving in cinemas on 12th November. Releasing in Hindi, Tamil & Telugu.\nPre-book your BMS voucher now: https://bit.ly/Tiger3BMSoffer\n\n► Subscribe Now: https://goo.gl/xs3mrY 🔔 Stay updated!\n► YRF New Releases: https://www.youtube.com/playlist?list=PLCB05E03DA939D484\n\nStay in the filmy loop:\n► Like us on Facebook: Facebook/yrf\n► Follow us on Twitter: Twitter/yrf\n► Follow us on Instagram: Instagram/yrf\n► Visit us on: yashrajfilms.com\n\n🎬 Movie Credits:\nStarring: Salman Khan, Katrina Kaif, Emraan Hashmi \nDirector: Maneesh Sharma\nProducer: Aditya Chopra\nCo-Producer: Akshaye Widhani\nScreenplay: Shridhar Raghavan\nDirector of Photography: Anay Om Goswamy (ISC)\nMusic: Pritam\nLyrics: Irshad Kamil, Amitabh Bhattacharya \nDialogues: Anckur Chaudhry \nStory: Aditya Chopra\nAssociate Producer: Rishabh Chopra\nExecutive Producers: Sudhanshu Kumar, Sanjay Shivalkar\nProduction Designer: Mayur Sharma  \nEditor: Rameshwar S. Bhagat\nDirector of Choreography: Vaibhavi Merchant\nSound: Pritam Das, Ganesh Gangadharan\nAction Directors: Franz Spilhaus, Oh Sea Young, Sunil Rodrigues (ROD)\nBackground Music: Tanuj Tiku\nCostume Designers: Anaita Shroff Adajania, Alvira Khan Agnihotri, Ashley Rebello, Darshan Jalan \nVisual Effects Studio: yFX \nCasting Director: Shanoo Sharma \nTrailers & Promos: Mohit Sajnaney \nRelease Date: 12 November 2023\n \nTiger 3 Trailer:\nBackground Music: Tanuj Tiku \nOriginal Tiger Theme Composition: Julius Packiam\n\nAbout YRF Spy Universe:\nYRF Spy Universe is a first of its kind cinematic universe of spy thriller films in India. The first film in the universe, \"Ek Tha Tiger,\" starring Salman Khan and Katrina Kaif was released in 2012, followed by its sequel \"Tiger Zinda Hai\" in 2017. The third film in the universe, \"War,\" was released in 2019 and starred Hrithik Roshan and Tiger Shroff in pivotal roles. The recent release Pathaan (2023) starring Shah Rukh Khan, Deepika Padukone and John Abraham is the fourth instalment in the spy universe franchise.\n\nAll the films of the Spy Universe are blockbusters with Pathaan being the all-time highest grossing Hindi film ever. The YRF Spy Universe is now one of the biggest IP’s in the history of Indian cinema. The next film from this franchise is Tiger 3 releasing this Diwali!\n\nYRF Spy Universe films boast of incredible visual spectacles with high-octane action sequences, thrilling plot-lines, power-packed characters and musical chartbusters.\n\n#Tiger3Trailer #yrf50 #YRFSpyUniverse #yrfnewreleases #yrf #tiger3 #yashraj #yashrajfilms #yrfmovies #yrfmusic #yashchopra #adityachopra #salmankhan #katrinakaif #emraanhashmi #maneeshsharma #newmovie #newmovie2023 #bollywoodmovie #bollywoodmovie2023 #tiger3trailer\n\n© Yash Raj Films Pvt. Ltd.",
        "thumbnails": {
          "default": {
            "url": "https://i.ytimg.com/vi/vEjTUDjjU6A/default.jpg",
            "width": 120,
            "height": 90
          },
          "medium": {
            "url": "https://i.ytimg.com/vi/vEjTUDjjU6A/mqdefault.jpg",
            "width": 320,
            "height": 180
          },
          "high": {
            "url": "https://i.ytimg.com/vi/vEjTUDjjU6A/hqdefault.jpg",
            "width": 480,
            "height": 360
          },
          "standard": {
            "url": "https://i.ytimg.com/vi/vEjTUDjjU6A/sddefault.jpg",
            "width": 640,
            "height": 480
          },
          "maxres": {
            "url": "https://i.ytimg.com/vi/vEjTUDjjU6A/maxresdefault.jpg",
            "width": 1280,
            "height": 720
          }
        },
        "channelTitle": "YRF",
        "tags": [
          "katrina kaif",
          "emraan hashmi",
          "tiger 3",
          "tiger 3 trailer",
          "tiger 3 ka trailer",
          "tiger trailer",
          "salman khan trailer",
          "katrina kaif trailer",
          "emraan hashmi trailer",
          "salman khan new trailer",
          "salman khan tiger 3 trailer",
          "tiger 3 trailer teaser",
          "tiger3 trailer",
          "tiger 3 movie ka trailer",
          "new movie trailer",
          "new trailers",
          "trailers 2023",
          "new movie trailers 2023",
          "bollywood movies trailer",
          "सलमान ख़ान",
          "टाइगर 3 ट्रेलर",
          "indian movie trailers",
          "katrina kaif movie trailer",
          "hindi movie trailer"
        ],
        "categoryId": "1",
        "liveBroadcastContent": "none",
        "defaultLanguage": "en-GB",
        "localized": {
          "title": "Tiger 3 Trailer | Salman Khan, Katrina Kaif, Emraan Hashmi | Maneesh Sharma | YRF Spy Universe",
          "description": "Tiger and Zoya are back - to save the country and their family. This time it’s personal! #Tiger3 arriving in cinemas on 12th November. Releasing in Hindi, Tamil & Telugu.\nPre-book your BMS voucher now: https://bit.ly/Tiger3BMSoffer\n\n► Subscribe Now: https://goo.gl/xs3mrY 🔔 Stay updated!\n► YRF New Releases: https://www.youtube.com/playlist?list=PLCB05E03DA939D484\n\nStay in the filmy loop:\n► Like us on Facebook: Facebook/yrf\n► Follow us on Twitter: Twitter/yrf\n► Follow us on Instagram: Instagram/yrf\n► Visit us on: yashrajfilms.com\n\n🎬 Movie Credits:\nStarring: Salman Khan, Katrina Kaif, Emraan Hashmi \nDirector: Maneesh Sharma\nProducer: Aditya Chopra\nCo-Producer: Akshaye Widhani\nScreenplay: Shridhar Raghavan\nDirector of Photography: Anay Om Goswamy (ISC)\nMusic: Pritam\nLyrics: Irshad Kamil, Amitabh Bhattacharya \nDialogues: Anckur Chaudhry \nStory: Aditya Chopra\nAssociate Producer: Rishabh Chopra\nExecutive Producers: Sudhanshu Kumar, Sanjay Shivalkar\nProduction Designer: Mayur Sharma  \nEditor: Rameshwar S. Bhagat\nDirector of Choreography: Vaibhavi Merchant\nSound: Pritam Das, Ganesh Gangadharan\nAction Directors: Franz Spilhaus, Oh Sea Young, Sunil Rodrigues (ROD)\nBackground Music: Tanuj Tiku\nCostume Designers: Anaita Shroff Adajania, Alvira Khan Agnihotri, Ashley Rebello, Darshan Jalan \nVisual Effects Studio: yFX \nCasting Director: Shanoo Sharma \nTrailers & Promos: Mohit Sajnaney \nRelease Date: 12 November 2023\n \nTiger 3 Trailer:\nBackground Music: Tanuj Tiku \nOriginal Tiger Theme Composition: Julius Packiam\n\nAbout YRF Spy Universe:\nYRF Spy Universe is a first of its kind cinematic universe of spy thriller films in India. The first film in the universe, \"Ek Tha Tiger,\" starring Salman Khan and Katrina Kaif was released in 2012, followed by its sequel \"Tiger Zinda Hai\" in 2017. The third film in the universe, \"War,\" was released in 2019 and starred Hrithik Roshan and Tiger Shroff in pivotal roles. The recent release Pathaan (2023) starring Shah Rukh Khan, Deepika Padukone and John Abraham is the fourth instalment in the spy universe franchise.\n\nAll the films of the Spy Universe are blockbusters with Pathaan being the all-time highest grossing Hindi film ever. The YRF Spy Universe is now one of the biggest IP’s in the history of Indian cinema. The next film from this franchise is Tiger 3 releasing this Diwali!\n\nYRF Spy Universe films boast of incredible visual spectacles with high-octane action sequences, thrilling plot-lines, power-packed characters and musical chartbusters.\n\n#Tiger3Trailer #yrf50 #YRFSpyUniverse #yrfnewreleases #yrf #tiger3 #yashraj #yashrajfilms #yrfmovies #yrfmusic #yashchopra #adityachopra #salmankhan #katrinakaif #emraanhashmi #maneeshsharma #newmovie #newmovie2023 #bollywoodmovie #bollywoodmovie2023 #tiger3trailer\n\n© Yash Raj Films Pvt. Ltd."
        },
        "defaultAudioLanguage": "hi"
      },
      "contentDetails": {
        "duration": "PT2M51S",
        "dimension": "2d",
        "definition": "hd",
        "caption": "true",
        "licensedContent": true,
        "contentRating": {
          
        },
        "projection": "rectangular"
      },
      "statistics": {
        "viewCount": "53895680",
        "likeCount": "1904682",
        "favoriteCount": "0",
        "commentCount": "177012"
      }
    },
    {
      "kind": "youtube#video",
      "etag": "kAnAkXCJ6nPMej-hJZez6O1NfRw",
      "id": "KpYISJR5pqQ",
      "snippet": {
        "publishedAt": "2023-10-19T09:31:49Z",
        "channelId": "UCr8xb2866oogDXDSN5-2Mxw",
        "title": "Leo Review Malayalam | Thalapathy Vijay | Lokesh Kangaraj | Anirudh",
        "description": "",
        "thumbnails": {
          "default": {
            "url": "https://i.ytimg.com/vi/KpYISJR5pqQ/default.jpg",
            "width": 120,
            "height": 90
          },
          "medium": {
            "url": "https://i.ytimg.com/vi/KpYISJR5pqQ/mqdefault.jpg",
            "width": 320,
            "height": 180
          },
          "high": {
            "url": "https://i.ytimg.com/vi/KpYISJR5pqQ/hqdefault.jpg",
            "width": 480,
            "height": 360
          },
          "standard": {
            "url": "https://i.ytimg.com/vi/KpYISJR5pqQ/sddefault.jpg",
            "width": 640,
            "height": 480
          },
          "maxres": {
            "url": "https://i.ytimg.com/vi/KpYISJR5pqQ/maxresdefault.jpg",
            "width": 1280,
            "height": 720
          }
        },
        "channelTitle": "Aswanth Kok",
        "categoryId": "24",
        "liveBroadcastContent": "none",
        "localized": {
          "title": "Leo Review Malayalam | Thalapathy Vijay | Lokesh Kangaraj | Anirudh",
          "description": ""
        }
      },
      "contentDetails": {
        "duration": "PT6M57S",
        "dimension": "2d",
        "definition": "hd",
        "caption": "false",
        "licensedContent": true,
        "contentRating": {
          
        },
        "projection": "rectangular"
      },
      "statistics": {
        "viewCount": "493924",
        "likeCount": "27386",
        "favoriteCount": "0",
        "commentCount": "3979"
      }
    },
    {
      "kind": "youtube#video",
      "etag": "o9RTO9aSni8YKuNQKNqBatOYM00",
      "id": "y9YZReuLNdU",
      "snippet": {
        "publishedAt": "2023-10-20T04:54:27Z",
        "channelId": "UCZM82IdwJeS1As0lPZu5_Xg",
        "title": "❤️ Oct 5 Delivery Vlog | Gender Reveal |✴️BOY OR GIRL✴️ | Oct 5th Vlog |",
        "description": "Mail id:hemaskitchen74@gmail.com\n\nFacebook: https://www.facebook.com/profile.php?id=100044325975044\n\nInsta Id: my Insta account: https://www.instagram.com/hemas_kitchen_ch/?hl=en\n\nNamma Ooru \nWebsite link:\nhttps://www.nammaoorushopping.com\n\ncontact No:\n73053 73004",
        "thumbnails": {
          "default": {
            "url": "https://i.ytimg.com/vi/y9YZReuLNdU/default.jpg",
            "width": 120,
            "height": 90
          },
          "medium": {
            "url": "https://i.ytimg.com/vi/y9YZReuLNdU/mqdefault.jpg",
            "width": 320,
            "height": 180
          },
          "high": {
            "url": "https://i.ytimg.com/vi/y9YZReuLNdU/hqdefault.jpg",
            "width": 480,
            "height": 360
          },
          "standard": {
            "url": "https://i.ytimg.com/vi/y9YZReuLNdU/sddefault.jpg",
            "width": 640,
            "height": 480
          },
          "maxres": {
            "url": "https://i.ytimg.com/vi/y9YZReuLNdU/maxresdefault.jpg",
            "width": 1280,
            "height": 720
          }
        },
        "channelTitle": "Hema's Kitchen",
        "categoryId": "22",
        "liveBroadcastContent": "none",
        "localized": {
          "title": "❤️ Oct 5 Delivery Vlog | Gender Reveal |✴️BOY OR GIRL✴️ | Oct 5th Vlog |",
          "description": "Mail id:hemaskitchen74@gmail.com\n\nFacebook: https://www.facebook.com/profile.php?id=100044325975044\n\nInsta Id: my Insta account: https://www.instagram.com/hemas_kitchen_ch/?hl=en\n\nNamma Ooru \nWebsite link:\nhttps://www.nammaoorushopping.com\n\ncontact No:\n73053 73004"
        }
      },
      "contentDetails": {
        "duration": "PT9M47S",
        "dimension": "2d",
        "definition": "hd",
        "caption": "false",
        "licensedContent": true,
        "contentRating": {
          
        },
        "projection": "rectangular"
      },
      "statistics": {
        "viewCount": "474525",
        "likeCount": "10105",
        "favoriteCount": "0",
        "commentCount": "714"
      }
    },
    {
      "kind": "youtube#video",
      "etag": "_ci_fnQBQJhbfgUzzwvNLJvV4wo",
      "id": "-BXItmWzWNE",
      "snippet": {
        "publishedAt": "2023-10-19T15:00:07Z",
        "channelId": "UCsSsgPaZ2GSmO6il8Cb5iGA",
        "title": "skibidi toilet 66",
        "description": "the final battle begins?\nskibidi dop dop dop yes yes\nfull-screen version\n\nspecial thanks to @HoovyTube for additional particles\n\nContact me:\ninstagram.com/dafuqboomtv\nblugrayguy@gmail.com",
        "thumbnails": {
          "default": {
            "url": "https://i.ytimg.com/vi/-BXItmWzWNE/default.jpg",
            "width": 120,
            "height": 90
          },
          "medium": {
            "url": "https://i.ytimg.com/vi/-BXItmWzWNE/mqdefault.jpg",
            "width": 320,
            "height": 180
          },
          "high": {
            "url": "https://i.ytimg.com/vi/-BXItmWzWNE/hqdefault.jpg",
            "width": 480,
            "height": 360
          },
          "standard": {
            "url": "https://i.ytimg.com/vi/-BXItmWzWNE/sddefault.jpg",
            "width": 640,
            "height": 480
          },
          "maxres": {
            "url": "https://i.ytimg.com/vi/-BXItmWzWNE/maxresdefault.jpg",
            "width": 1280,
            "height": 720
          }
        },
        "channelTitle": "DaFuq!?Boom!",
        "tags": [
          "skibidi meme",
          "sfm animation",
          "funny animation",
          "gmod animation",
          "skibidi toilet vs cameramen",
          "titan cameraman",
          "skibidi toilet",
          "scientist skibidi",
          "gman toilet",
          "titan speakerman",
          "titan tvman",
          "tv woman",
          "speakerwoman"
        ],
        "categoryId": "24",
        "liveBroadcastContent": "none",
        "localized": {
          "title": "skibidi toilet 66",
          "description": "the final battle begins?\nskibidi dop dop dop yes yes\nfull-screen version\n\nspecial thanks to @HoovyTube for additional particles\n\nContact me:\ninstagram.com/dafuqboomtv\nblugrayguy@gmail.com"
        },
        "defaultAudioLanguage": "en"
      },
      "contentDetails": {
        "duration": "PT3M6S",
        "dimension": "2d",
        "definition": "hd",
        "caption": "false",
        "licensedContent": true,
        "contentRating": {
          
        },
        "projection": "rectangular"
      },
      "statistics": {
        "viewCount": "29205286",
        "likeCount": "1544724",
        "favoriteCount": "0",
        "commentCount": "162659"
      }
    },
    {
      "kind": "youtube#video",
      "etag": "UkC_-QmiegKio4JzpT_rI_xEuZo",
      "id": "95cjJ8bxywk",
      "snippet": {
        "publishedAt": "2023-10-18T11:30:39Z",
        "channelId": "UCbpjEr8lHlnkf1SQ5tnDEYw",
        "title": "Japan - Official Teaser (Tamil) | Karthi, Anu Emmanuel, Sunil | GV Prakash | Raju Murugan | SR Prabu",
        "description": "Presenting the Official Teaser of #Japan (Tamil). #Karthi | #AnuEmmanuel | #Sunil | #RajuMurugan | #GVPrakash | #Ravivarman | #AnlArasu | #Philominraj | #Banglan | #SRPrabhu | #DreamWarriorPictures | #Karthi25 | #JapanFromDiwali | #JapanTheMovie \n\nDWP WhatsApp Channel - https://whatsapp.com/channel/0029Va5ZKejJ3jux9Tvxr22j\n\nJapan Cast and Crew:\nStarring Karthi, Anu Emmanuel, Sunil, Vijay Milton & others.\nDirected by: Rajumurugan \nProduction House: Dream Warrior Pictures \nProducers: S R Prakash Babu, S R Prabu \nCreative Producer: Thangaprabaharan R\nExecutive Producer: Aravendraj Baskaran \nDOP: S. Ravi Varman\nMusic: GV Prakash Kumar \nEditor: Philomin Raj \nStunts: Anl Arasu\nLyrics: Yugabharathi, Arunraja Kamaraj\nDialogues : Raju Murugan, C. Murugesh babu\nProduction Designer: Banglan \nProduction Controller: Rajendran PS\nCostume Designer: Praveen Raja \nArt Director: Mahendran\nCostumes: Mohammed Subier\nSound Design : Tapas Nayak\nColorist : Ken Metzker\nDI : Red Chillies.Color\nVFX : Bhishma Studio\nMake up: Surya Prakash\nChoreography: Sandy, Jani\nEP Associate: Allaudin Hussain, Sathappa S\nPromotions: Esakki Muthu K\nPRO: Johnson\n\nFollow us on, \nDWP FB - https://www.fb.com/dreamwarriorpictures \nDWP Twitter - https://twitter.com/DreamWarriorpic \nDWP YouTube - http://bit.ly/DWP-YT \nDWP Instagram - https://www.instagram.com/dreamwarriorpictures\nDWP LinkedIn - https://www.linkedin.com/company/13251738",
        "thumbnails": {
          "default": {
            "url": "https://i.ytimg.com/vi/95cjJ8bxywk/default.jpg",
            "width": 120,
            "height": 90
          },
          "medium": {
            "url": "https://i.ytimg.com/vi/95cjJ8bxywk/mqdefault.jpg",
            "width": 320,
            "height": 180
          },
          "high": {
            "url": "https://i.ytimg.com/vi/95cjJ8bxywk/hqdefault.jpg",
            "width": 480,
            "height": 360
          },
          "standard": {
            "url": "https://i.ytimg.com/vi/95cjJ8bxywk/sddefault.jpg",
            "width": 640,
            "height": 480
          },
          "maxres": {
            "url": "https://i.ytimg.com/vi/95cjJ8bxywk/maxresdefault.jpg",
            "width": 1280,
            "height": 720
          }
        },
        "channelTitle": "Dream Warrior Pictures",
        "tags": [
          "karthi",
          "happy birthday karthi",
          "#karthi",
          "happy birthday karthik",
          "karthi movies",
          "karthi sivakumar",
          "hbd karthi",
          "karthik surya",
          "kaithi karthi movie",
          "happy bday karthik",
          "kaithi",
          "hero karthi",
          "karthi film",
          "actor karthi",
          "birthday wishes karthi",
          "karthi birthday mashup",
          "japanese movie",
          "japan tamil movie",
          "japan movie updates",
          "japan movie karthi",
          "japan karthi movie",
          "japan movie update",
          "japan karthi",
          "karthi japan movie poojai",
          "karthik japan movie update",
          "whos japan",
          "Japan karthi"
        ],
        "categoryId": "1",
        "liveBroadcastContent": "none",
        "localized": {
          "title": "Japan - Official Teaser (Tamil) | Karthi, Anu Emmanuel, Sunil | GV Prakash | Raju Murugan | SR Prabu",
          "description": "Presenting the Official Teaser of #Japan (Tamil). #Karthi | #AnuEmmanuel | #Sunil | #RajuMurugan | #GVPrakash | #Ravivarman | #AnlArasu | #Philominraj | #Banglan | #SRPrabhu | #DreamWarriorPictures | #Karthi25 | #JapanFromDiwali | #JapanTheMovie \n\nDWP WhatsApp Channel - https://whatsapp.com/channel/0029Va5ZKejJ3jux9Tvxr22j\n\nJapan Cast and Crew:\nStarring Karthi, Anu Emmanuel, Sunil, Vijay Milton & others.\nDirected by: Rajumurugan \nProduction House: Dream Warrior Pictures \nProducers: S R Prakash Babu, S R Prabu \nCreative Producer: Thangaprabaharan R\nExecutive Producer: Aravendraj Baskaran \nDOP: S. Ravi Varman\nMusic: GV Prakash Kumar \nEditor: Philomin Raj \nStunts: Anl Arasu\nLyrics: Yugabharathi, Arunraja Kamaraj\nDialogues : Raju Murugan, C. Murugesh babu\nProduction Designer: Banglan \nProduction Controller: Rajendran PS\nCostume Designer: Praveen Raja \nArt Director: Mahendran\nCostumes: Mohammed Subier\nSound Design : Tapas Nayak\nColorist : Ken Metzker\nDI : Red Chillies.Color\nVFX : Bhishma Studio\nMake up: Surya Prakash\nChoreography: Sandy, Jani\nEP Associate: Allaudin Hussain, Sathappa S\nPromotions: Esakki Muthu K\nPRO: Johnson\n\nFollow us on, \nDWP FB - https://www.fb.com/dreamwarriorpictures \nDWP Twitter - https://twitter.com/DreamWarriorpic \nDWP YouTube - http://bit.ly/DWP-YT \nDWP Instagram - https://www.instagram.com/dreamwarriorpictures\nDWP LinkedIn - https://www.linkedin.com/company/13251738"
        },
        "defaultAudioLanguage": "ta"
      },
      "contentDetails": {
        "duration": "PT1M25S",
        "dimension": "2d",
        "definition": "hd",
        "caption": "true",
        "licensedContent": true,
        "contentRating": {
          
        },
        "projection": "rectangular"
      },
      "statistics": {
        "viewCount": "3099153",
        "likeCount": "152831",
        "favoriteCount": "0",
        "commentCount": "1856"
      }
    },
    {
      "kind": "youtube#video",
      "etag": "xctXs-7ExkpWL__WQPIHp2Y4tec",
      "id": "EAMJPhgsmmE",
      "snippet": {
        "publishedAt": "2023-10-19T00:28:00Z",
        "channelId": "UC-qQac_ZLmIPV4q8zdPBGvw",
        "title": "Leo Public Review | Leo Movie Review | Leo review | leo | Thalapathy vijay",
        "description": "#leo#leoreview#thalapathyvijay#thalapathy \nLeo Public Review | Leo Movie Review | Leo review | leo | Thalapathy vijay \n\n\n#leo #leoreview #leomoviereview #lokeshkanagaraj #thalapathy #thalapathyvijay #leomovie #leofdfs #vijay #leosongs #leopublicreview \n\nLEO, leo, leo review, leo movie, leo movie review, leo public review, leo public reaction, leo movie reaction, leo public opinion, leo meme review, bingo box, tamil cinima review, tamil talkies, leo blue sattai, leo its prashanth, leo its prashanth review, tamil movie review, leo public respons, leo fdfs, leo blue sattai review, leo celebration, thalapathy vijay, thalapathy, vijay, thalapathy vijay leo, na ready song, leo fdfs review, Leo review, Leo public review, Leo movie review, Leo fans review, Leo fdfs, Leo fdfs review, Leo movie, Leo public opinion, Leo theater response, Leo response, Leo boxoffice, Leo fdfs show, Leo response, leo fdfs, leo fdfs review, leo response, leo theatre response, leo response, leo review, leo fdfs review, leo fdfs response, Thalapathy vijay, thalapathy video, thalapathy leo interview, thalapathy vijay comedy, thalapathy vijay speech, thalapathy vijay video , leo tamil tube, first junction, tamil news, LEO, leo Review, leo fans celebration, leo review tamil, leo tamil review, leo tamil, leo tamil review, tamil leo review, leo tamil movie review, vijay leo, thalapathy leo review, lokesh kanagaraj interview, thalapathy vijay theatre, thalapathy vijay review, thalapathy about leo, chennai day, cineulagam, chennai times, Bingoobox, Bingoo box, tamil review, tamil movie review, tamil cinema, tamil fdfs review, Leo fdfs, leo fdfs response, leo response, லியோ, leo boxoffice, leo fdfs boxoffice, leo interview, leo success meet, leo press meet, leo pressmeet, leo full movie, Leo movie, leo full online movie, leo full movie download, leo movie download, leo movie scene, leo movie scenes, leo movie comedy, leo comedy, Thalapathy vijay about leo, leo full movie online, leo fdfs video, leo opening scene, leo thalapthy entry, leo thalapathy vijay entry, leo lcu entry, leo lcu scene, leo scenes, leo scene, leo spoof, leo sneak peak, leo full movie, Leo full movie, Leo full movie download, Leo review, Leo review, Leo movie review, Leo public review, Leo public opinion, Leo fans review, Leo actors review, leo celebration, Leo celebrity review, Leo celebrities review, Leo fdfs review, Leo fdfs celebration, rohini silver screen, Leo Kamala theater, leo kasi theater, leo vetri theater, Leo audience review, Leo response, leo fans response, LEO LCU, leo lcu, leo story, leo opening, leo opening scene, leo thalapathy entry scene, leo songs, blue sattai leo review, leo blue sattai review , leo blue sattai , leo tamil takies, leo tamil takies review, leo its prashanth review, leo prashanth review, leo family audience, leo news, leo tamil review, leo Malayalam review, leo telugu review, leo kannada review, telugu leo review, leo review tamil, leo review malayalam, leo review kannada, leo review telugu, leo download, leo Arjun, leo badass, leo glimpse, leo reaction, leo reaction by foreigners, leo foreigners review, leo foreign leo, leo foreigners review, Leo review tamil, leo review hindi, leo hindi review, leo review tamil public, Leo thalapathy vijay, vijay leo, thalapathy vijay leo, Leo full scene, leo video songs, leo fight scene, leo mass scenes, leo bgm, lokesh kanagaraj, leo box office collection, leo sanjay dutt, leo trisha, leo arjun, leo mysskin, Mansoor Ali Khan, leo sandy master, leo sandy master video, leo video, Gautham Vasudev Menon, thalapthy , vijay, Thalapathy vijay, Thalapathy vijay video, Sangeetha vijay, Jason Sanjay , Divya Saasha, Sangeetha Sornalingam, Sangeetha vijay, Leo tamil review, leo memes, leo world wide box office collection, Leo box office, Leo box office collection, Leo collection, leo total collection, leo blue sattai maran review, Leo blue sattai review, Leo prashanth review, leo mass celebration, Leo issue, Leo news, Leo theater, Leo theater response, Leo theater review, Leo theater celebration, Leo rajini review, Leo rajinikanth review, thalapathy vijay angry, thalapathy vijay fans, superstar vijay, Leo rajini reaction, Leo rajinikanth reaction, thalapathy fans angry, thalapathy video, vijay video, Leo thalapathy vijay, leo live video, leo live movie, Leo live news, Leo reaction, Leo rajini fans review, leo Ajith fans review, leo Kamal fans review l, LCU, lokesh kanagaraj review, lokesh kanagaraj interview, anirudh bgm, anirudh interview, anirudh ravichandran, Leo whatsApp status, leo public talk, leo troll, leo public talk, Leo status, leo movie scenes, leo movie online, leo movie live, leo fans celebration, leo vijay speech, thalapathy vijay speech, thalapathy vijay audio launch, suriya in leo, Kamal in leo, Rolex, Rolex in leo, lcu rolex in leo, leo fdfs tamil review, leo tamilnadu collection, leo worldwide boxoffice collection, lcu in leo, Rolex bgm, leo bgm download, leo songs, leo fight, leo mass scene",
        "thumbnails": {
          "default": {
            "url": "https://i.ytimg.com/vi/EAMJPhgsmmE/default.jpg",
            "width": 120,
            "height": 90
          },
          "medium": {
            "url": "https://i.ytimg.com/vi/EAMJPhgsmmE/mqdefault.jpg",
            "width": 320,
            "height": 180
          },
          "high": {
            "url": "https://i.ytimg.com/vi/EAMJPhgsmmE/hqdefault.jpg",
            "width": 480,
            "height": 360
          },
          "standard": {
            "url": "https://i.ytimg.com/vi/EAMJPhgsmmE/sddefault.jpg",
            "width": 640,
            "height": 480
          },
          "maxres": {
            "url": "https://i.ytimg.com/vi/EAMJPhgsmmE/maxresdefault.jpg",
            "width": 1280,
            "height": 720
          }
        },
        "channelTitle": "Tamil 360",
        "tags": [
          "leo",
          "leo review",
          "leo movie review",
          "leo public review",
          "leo public opinion",
          "leo review tamil",
          "leo review Hindi",
          "leo review malayalam",
          "leo review kannada",
          "thalapathy vijay",
          "lokesh kanagaraj",
          "leo full movie",
          "leo scene",
          "leo fdfs",
          "leo fdfs review",
          "leo reaction",
          "leo celebrities review",
          "leo lcu",
          "leo blue sattai review",
          "leo Prashanth review",
          "blue sattai review by leo",
          "blue sattai leo review",
          "bingoo box",
          "tamil tube",
          "first junction",
          "leo thi cinemas",
          "its prashant leo review"
        ],
        "categoryId": "24",
        "liveBroadcastContent": "none",
        "localized": {
          "title": "Leo Public Review | Leo Movie Review | Leo review | leo | Thalapathy vijay",
          "description": "#leo#leoreview#thalapathyvijay#thalapathy \nLeo Public Review | Leo Movie Review | Leo review | leo | Thalapathy vijay \n\n\n#leo #leoreview #leomoviereview #lokeshkanagaraj #thalapathy #thalapathyvijay #leomovie #leofdfs #vijay #leosongs #leopublicreview \n\nLEO, leo, leo review, leo movie, leo movie review, leo public review, leo public reaction, leo movie reaction, leo public opinion, leo meme review, bingo box, tamil cinima review, tamil talkies, leo blue sattai, leo its prashanth, leo its prashanth review, tamil movie review, leo public respons, leo fdfs, leo blue sattai review, leo celebration, thalapathy vijay, thalapathy, vijay, thalapathy vijay leo, na ready song, leo fdfs review, Leo review, Leo public review, Leo movie review, Leo fans review, Leo fdfs, Leo fdfs review, Leo movie, Leo public opinion, Leo theater response, Leo response, Leo boxoffice, Leo fdfs show, Leo response, leo fdfs, leo fdfs review, leo response, leo theatre response, leo response, leo review, leo fdfs review, leo fdfs response, Thalapathy vijay, thalapathy video, thalapathy leo interview, thalapathy vijay comedy, thalapathy vijay speech, thalapathy vijay video , leo tamil tube, first junction, tamil news, LEO, leo Review, leo fans celebration, leo review tamil, leo tamil review, leo tamil, leo tamil review, tamil leo review, leo tamil movie review, vijay leo, thalapathy leo review, lokesh kanagaraj interview, thalapathy vijay theatre, thalapathy vijay review, thalapathy about leo, chennai day, cineulagam, chennai times, Bingoobox, Bingoo box, tamil review, tamil movie review, tamil cinema, tamil fdfs review, Leo fdfs, leo fdfs response, leo response, லியோ, leo boxoffice, leo fdfs boxoffice, leo interview, leo success meet, leo press meet, leo pressmeet, leo full movie, Leo movie, leo full online movie, leo full movie download, leo movie download, leo movie scene, leo movie scenes, leo movie comedy, leo comedy, Thalapathy vijay about leo, leo full movie online, leo fdfs video, leo opening scene, leo thalapthy entry, leo thalapathy vijay entry, leo lcu entry, leo lcu scene, leo scenes, leo scene, leo spoof, leo sneak peak, leo full movie, Leo full movie, Leo full movie download, Leo review, Leo review, Leo movie review, Leo public review, Leo public opinion, Leo fans review, Leo actors review, leo celebration, Leo celebrity review, Leo celebrities review, Leo fdfs review, Leo fdfs celebration, rohini silver screen, Leo Kamala theater, leo kasi theater, leo vetri theater, Leo audience review, Leo response, leo fans response, LEO LCU, leo lcu, leo story, leo opening, leo opening scene, leo thalapathy entry scene, leo songs, blue sattai leo review, leo blue sattai review , leo blue sattai , leo tamil takies, leo tamil takies review, leo its prashanth review, leo prashanth review, leo family audience, leo news, leo tamil review, leo Malayalam review, leo telugu review, leo kannada review, telugu leo review, leo review tamil, leo review malayalam, leo review kannada, leo review telugu, leo download, leo Arjun, leo badass, leo glimpse, leo reaction, leo reaction by foreigners, leo foreigners review, leo foreign leo, leo foreigners review, Leo review tamil, leo review hindi, leo hindi review, leo review tamil public, Leo thalapathy vijay, vijay leo, thalapathy vijay leo, Leo full scene, leo video songs, leo fight scene, leo mass scenes, leo bgm, lokesh kanagaraj, leo box office collection, leo sanjay dutt, leo trisha, leo arjun, leo mysskin, Mansoor Ali Khan, leo sandy master, leo sandy master video, leo video, Gautham Vasudev Menon, thalapthy , vijay, Thalapathy vijay, Thalapathy vijay video, Sangeetha vijay, Jason Sanjay , Divya Saasha, Sangeetha Sornalingam, Sangeetha vijay, Leo tamil review, leo memes, leo world wide box office collection, Leo box office, Leo box office collection, Leo collection, leo total collection, leo blue sattai maran review, Leo blue sattai review, Leo prashanth review, leo mass celebration, Leo issue, Leo news, Leo theater, Leo theater response, Leo theater review, Leo theater celebration, Leo rajini review, Leo rajinikanth review, thalapathy vijay angry, thalapathy vijay fans, superstar vijay, Leo rajini reaction, Leo rajinikanth reaction, thalapathy fans angry, thalapathy video, vijay video, Leo thalapathy vijay, leo live video, leo live movie, Leo live news, Leo reaction, Leo rajini fans review, leo Ajith fans review, leo Kamal fans review l, LCU, lokesh kanagaraj review, lokesh kanagaraj interview, anirudh bgm, anirudh interview, anirudh ravichandran, Leo whatsApp status, leo public talk, leo troll, leo public talk, Leo status, leo movie scenes, leo movie online, leo movie live, leo fans celebration, leo vijay speech, thalapathy vijay speech, thalapathy vijay audio launch, suriya in leo, Kamal in leo, Rolex, Rolex in leo, lcu rolex in leo, leo fdfs tamil review, leo tamilnadu collection, leo worldwide boxoffice collection, lcu in leo, Rolex bgm, leo bgm download, leo songs, leo fight, leo mass scene"
        },
        "defaultAudioLanguage": "zxx"
      },
      "contentDetails": {
        "duration": "PT2M38S",
        "dimension": "2d",
        "definition": "hd",
        "caption": "false",
        "licensedContent": true,
        "contentRating": {
          
        },
        "projection": "rectangular"
      },
      "statistics": {
        "viewCount": "1378605",
        "likeCount": "29740",
        "favoriteCount": "0",
        "commentCount": "926"
      }
    },
    {
      "kind": "youtube#video",
      "etag": "OpQY9h0ctdWRkmTY7CWvrgpKLCs",
      "id": "GgktZNb6XAE",
      "snippet": {
        "publishedAt": "2023-10-20T03:30:04Z",
        "channelId": "UCX8pnu3DYUnx8qy8V_c6oHg",
        "title": "FINALLY I BOUGHT A GTR",
        "description": "FINALLY I BOUGHT A GTR | CAR FOR SALE\n#technogamerz \n\nSubscribe to our Second YouTube Channel: https://www.youtube.com/c/UjjwalGamer\n\n\nShare, Support, Subscribe!!!\nSubscribe: http://bit.ly/technogamerz\nDiscord : https://bit.ly/ujjwaldiscord\nYoutube: https://www.youtube.com/c/TechnoGamerzOfficial\nTwitter:  https://www.twitter.com/ujjwalgamer\nFacebook: https://www.facebook.com/technogamerz\nFacebook Myself: https://www.facebook.com/ujjwalgamer\nInstagram: https://instagram.com/ujjwalgamer\nGoogle Plus: https://plus.google.com/+TechnoGamerzOfficial\nWebsite: https://technogamerz.in/\nMerchandise: https://shop.technogamerz.in/\n\n\nBusiness Email : technogamerzofficial@gmail.com\n\n\nAbout : Techno Gamerz is a YouTube Channel, where you will find gaming videos in Hindi, I hope this video was Useful and you liked it, if you did press the thumbs up button.",
        "thumbnails": {
          "default": {
            "url": "https://i.ytimg.com/vi/GgktZNb6XAE/default.jpg",
            "width": 120,
            "height": 90
          },
          "medium": {
            "url": "https://i.ytimg.com/vi/GgktZNb6XAE/mqdefault.jpg",
            "width": 320,
            "height": 180
          },
          "high": {
            "url": "https://i.ytimg.com/vi/GgktZNb6XAE/hqdefault.jpg",
            "width": 480,
            "height": 360
          },
          "standard": {
            "url": "https://i.ytimg.com/vi/GgktZNb6XAE/sddefault.jpg",
            "width": 640,
            "height": 480
          },
          "maxres": {
            "url": "https://i.ytimg.com/vi/GgktZNb6XAE/maxresdefault.jpg",
            "width": 1280,
            "height": 720
          }
        },
        "channelTitle": "Techno Gamerz",
        "tags": [
          "car for sale",
          "car showroom",
          "dealership",
          "supercar",
          "lamborghini",
          "simulator",
          "funny",
          "ujjwal",
          "techno gamerz"
        ],
        "categoryId": "20",
        "liveBroadcastContent": "none",
        "localized": {
          "title": "FINALLY I BOUGHT A GTR",
          "description": "FINALLY I BOUGHT A GTR | CAR FOR SALE\n#technogamerz \n\nSubscribe to our Second YouTube Channel: https://www.youtube.com/c/UjjwalGamer\n\n\nShare, Support, Subscribe!!!\nSubscribe: http://bit.ly/technogamerz\nDiscord : https://bit.ly/ujjwaldiscord\nYoutube: https://www.youtube.com/c/TechnoGamerzOfficial\nTwitter:  https://www.twitter.com/ujjwalgamer\nFacebook: https://www.facebook.com/technogamerz\nFacebook Myself: https://www.facebook.com/ujjwalgamer\nInstagram: https://instagram.com/ujjwalgamer\nGoogle Plus: https://plus.google.com/+TechnoGamerzOfficial\nWebsite: https://technogamerz.in/\nMerchandise: https://shop.technogamerz.in/\n\n\nBusiness Email : technogamerzofficial@gmail.com\n\n\nAbout : Techno Gamerz is a YouTube Channel, where you will find gaming videos in Hindi, I hope this video was Useful and you liked it, if you did press the thumbs up button."
        },
        "defaultAudioLanguage": "en-IN"
      },
      "contentDetails": {
        "duration": "PT24M49S",
        "dimension": "2d",
        "definition": "hd",
        "caption": "false",
        "licensedContent": true,
        "contentRating": {
          
        },
        "projection": "rectangular"
      },
      "statistics": {
        "viewCount": "4435220",
        "likeCount": "354841",
        "favoriteCount": "0",
        "commentCount": "24439"
      }
    },
    {
      "kind": "youtube#video",
      "etag": "Q3XnDL5gBbouQ4KiGjn80tHMdhE",
      "id": "LWPXkRNK8SM",
      "snippet": {
        "publishedAt": "2023-10-19T12:32:50Z",
        "channelId": "UCNJcSUSzUeFm8W9P7UUlSeQ",
        "title": "TVF Aspirants - Season 2 | Official Trailer | Streaming from 25 Oct On Amazon Prime Video",
        "description": "Get ready for the highly anticipated return of Aspirants as they continue to take us on a rollercoaster ride of friendship, dreams, and dilemmas. As we witness the mentorship dynamic between Sandeep Bhaiya and Abhilash evolve, we're left with questions about how they'll manage their professional responsibilities alongside their deep friendship. \n\nFrom Rajinder Nagar to Rampur, this season takes our aspirants into the world of adulthood, testing their decisions in the face of life's challenges. Drama, laughter, and a whirlwind of emotions await you in this season.\n\n#AspirantsOnPrime , new season 25th October!\n\nRecap Aspirants Season 1 here: https://youtube.com/playlist?list=PLTB0eCoUXErY_KvRNKOERQtYSDPjOb8jw&si=TaG8xWK8ZrQEEjFD\n\nA TVF Creation\nDirector: Apoorv Singh Karki\nWriters: Deepesh Sumitra Jagdish, Ashutosh Chaturvedi, Pankaj Mavchi\nProducer: Arunabh Kumar\nExecutive Producers: Vijay Koshy, Shreyansh Pandey\nCast: Naveen Kasturia, Sunny Hinduja, Abhilash Thapliyal, Shivankit Parihar, Namita Dubey\n\n#TVF #Aspirants #UPSC \n\n---\nThis channel is owned, operated, and managed by, Contagious Online Media Network Private Limited.",
        "thumbnails": {
          "default": {
            "url": "https://i.ytimg.com/vi/LWPXkRNK8SM/default.jpg",
            "width": 120,
            "height": 90
          },
          "medium": {
            "url": "https://i.ytimg.com/vi/LWPXkRNK8SM/mqdefault.jpg",
            "width": 320,
            "height": 180
          },
          "high": {
            "url": "https://i.ytimg.com/vi/LWPXkRNK8SM/hqdefault.jpg",
            "width": 480,
            "height": 360
          },
          "standard": {
            "url": "https://i.ytimg.com/vi/LWPXkRNK8SM/sddefault.jpg",
            "width": 640,
            "height": 480
          },
          "maxres": {
            "url": "https://i.ytimg.com/vi/LWPXkRNK8SM/maxresdefault.jpg",
            "width": 1280,
            "height": 720
          }
        },
        "channelTitle": "The Viral Fever",
        "tags": [
          "the viral fever",
          "tvf",
          "tvf aspirants",
          "tvf aspirants season 2",
          "tvf aspirants trailer",
          "tvf aspirants season 2 trailer",
          "aspirants new season",
          "aspirants season 2 trailer",
          "tvf naveen kasturia",
          "tvf web series",
          "abhilash sharma aspirants",
          "sandeep bhaiya",
          "sk sir ki class",
          "sk sir motivation",
          "aspirants season 1",
          "amazon prime video",
          "tvf sunny hinduja",
          "tvf shivankit parihar",
          "tvf namita dubey",
          "upsc",
          "ias",
          "upsc motivation",
          "upsc aspirants",
          "old rajendra nagar",
          "tvf new video"
        ],
        "categoryId": "24",
        "liveBroadcastContent": "none",
        "defaultLanguage": "en",
        "localized": {
          "title": "TVF Aspirants - Season 2 | Official Trailer | Streaming from 25 Oct On Amazon Prime Video",
          "description": "Get ready for the highly anticipated return of Aspirants as they continue to take us on a rollercoaster ride of friendship, dreams, and dilemmas. As we witness the mentorship dynamic between Sandeep Bhaiya and Abhilash evolve, we're left with questions about how they'll manage their professional responsibilities alongside their deep friendship. \n\nFrom Rajinder Nagar to Rampur, this season takes our aspirants into the world of adulthood, testing their decisions in the face of life's challenges. Drama, laughter, and a whirlwind of emotions await you in this season.\n\n#AspirantsOnPrime , new season 25th October!\n\nRecap Aspirants Season 1 here: https://youtube.com/playlist?list=PLTB0eCoUXErY_KvRNKOERQtYSDPjOb8jw&si=TaG8xWK8ZrQEEjFD\n\nA TVF Creation\nDirector: Apoorv Singh Karki\nWriters: Deepesh Sumitra Jagdish, Ashutosh Chaturvedi, Pankaj Mavchi\nProducer: Arunabh Kumar\nExecutive Producers: Vijay Koshy, Shreyansh Pandey\nCast: Naveen Kasturia, Sunny Hinduja, Abhilash Thapliyal, Shivankit Parihar, Namita Dubey\n\n#TVF #Aspirants #UPSC \n\n---\nThis channel is owned, operated, and managed by, Contagious Online Media Network Private Limited."
        },
        "defaultAudioLanguage": "hi"
      },
      "contentDetails": {
        "duration": "PT2M30S",
        "dimension": "2d",
        "definition": "hd",
        "caption": "true",
        "licensedContent": true,
        "contentRating": {
          
        },
        "projection": "rectangular"
      },
      "statistics": {
        "viewCount": "920596",
        "likeCount": "55636",
        "favoriteCount": "0",
        "commentCount": "2417"
      }
    },
    {
      "kind": "youtube#video",
      "etag": "cMn7Tb0OmLMJX--nZFX-VI06hUM",
      "id": "jrJOK5tZbLU",
      "snippet": {
        "publishedAt": "2023-10-17T12:30:13Z",
        "channelId": "UCjbBFvK04b-O3foSNabdrOA",
        "title": "Student Web Series || Episode - 5 || Shanmukh Jaswanth || Subbu K || Infinitum Media",
        "description": "💰 Claim 150% Welcome Bonus with Parimatch: https://cutt.ly/Parimatch_Student \n\nDisclaimer: We do not intend to promote investment/gambling of any kind.  Viewer discretion is advised. If your current residence is from Andhra, Assam, Odisha, Telangana, Nagaland, and Sikkim, you are advised to not participate.\n\nFor Brand Inquiries & Collaborations \nEmail us at brands@infinitumnetwork.in\n\nTo all the students out there!!!!!!!\nHere's the most related tale that'll make you laugh and cry at the same time. Episode 4 is out now.\n\n\"Student\" is Telugu's biggest and most ambitious web series featuring Shanmukh Jaswanth as a lead.\n\nCast: Shanmukh Jaswanth, Don Pruthvi, Pruthvi Jhakaas, Neha Pathan, Tanuja Madhurapantula, Tejaswini Naidu, Sathwik Somalanka, Naga Vedith, Devesh, Vijay Arun Cr, Pranaya Vamsi, Madhu Nekkalapudi, Pranaya Vamsy Rambhatla(PVR).\n\nProduced by Infinitum​ Network Solutions.\nCo-Producer: Shanmukh Jaswanth\n\nWritten by  Subbu. K \n\nDirected by Avinash \n\nCinematography: Vamsi Srinivas \n\nMusic: Anivee\nAdditional programming - Ashok Sridharan\nFlute - Sanjay Balajee\n\nAdditional Programming: Ashok Sridharan\n\nEditing: Krishna Karthik Vunnava\n\nDI: Kumba Shiva Kumar\n\nBrands Manager: Bhargav.T\n\nSfx and Mixing - Marcus\n\nPoster Designer: Nikhil Chotu, Shiva Krishna.\n\nSubtitles - M.L. Prabhakaran\n\nSound Engineer: Dasari Kesava Naidu, Kanukuntla Bhaskar.\n\nCostume Designer: Sriya Patel\n\nCostume Courtesy: Priyanshi Collections\n( https://instagram.com/priyanshi_collections?igshid=MzRlODBiNWFlZA== )\n\nLine Producer: Siva Geddam, Mohan Reddy.\n\nExecutive Producer: Rahul Raghavendra \n\n#StudentWebSeries #ShanmukhJaswanth #InfinitumMedia #TeluguWebSeries2023 \n\nFollow Infinitum Originals on \n\nFacebook: https://www.facebook.com/InfinitumOriginals\nInstagram: https://www.instagram.com/infinitum_originals/",
        "thumbnails": {
          "default": {
            "url": "https://i.ytimg.com/vi/jrJOK5tZbLU/default.jpg",
            "width": 120,
            "height": 90
          },
          "medium": {
            "url": "https://i.ytimg.com/vi/jrJOK5tZbLU/mqdefault.jpg",
            "width": 320,
            "height": 180
          },
          "high": {
            "url": "https://i.ytimg.com/vi/jrJOK5tZbLU/hqdefault.jpg",
            "width": 480,
            "height": 360
          },
          "standard": {
            "url": "https://i.ytimg.com/vi/jrJOK5tZbLU/sddefault.jpg",
            "width": 640,
            "height": 480
          },
          "maxres": {
            "url": "https://i.ytimg.com/vi/jrJOK5tZbLU/maxresdefault.jpg",
            "width": 1280,
            "height": 720
          }
        },
        "channelTitle": "Shanmukh Jaswanth",
        "tags": [
          "student",
          "student web series",
          "shanmukh jaswanth",
          "shanmukh jaswanth student web series",
          "shannu student web series",
          "shanmukh jaswanth web series",
          "shanmukh jaswanth latest",
          "shannu short films",
          "shannu",
          "shanmukh jaswanth new",
          "telugu web series",
          "telugu short films",
          "telugu short films 2023",
          "college web series",
          "student episode shanmukh jaswanth",
          "neha pathan",
          "don pruthvi",
          "student shanmukh jaswanth",
          "student latest video",
          "infinitum media",
          "student episode 5",
          "student web series ep 5"
        ],
        "categoryId": "24",
        "liveBroadcastContent": "none",
        "localized": {
          "title": "Student Web Series || Episode - 5 || Shanmukh Jaswanth || Subbu K || Infinitum Media",
          "description": "💰 Claim 150% Welcome Bonus with Parimatch: https://cutt.ly/Parimatch_Student \n\nDisclaimer: We do not intend to promote investment/gambling of any kind.  Viewer discretion is advised. If your current residence is from Andhra, Assam, Odisha, Telangana, Nagaland, and Sikkim, you are advised to not participate.\n\nFor Brand Inquiries & Collaborations \nEmail us at brands@infinitumnetwork.in\n\nTo all the students out there!!!!!!!\nHere's the most related tale that'll make you laugh and cry at the same time. Episode 4 is out now.\n\n\"Student\" is Telugu's biggest and most ambitious web series featuring Shanmukh Jaswanth as a lead.\n\nCast: Shanmukh Jaswanth, Don Pruthvi, Pruthvi Jhakaas, Neha Pathan, Tanuja Madhurapantula, Tejaswini Naidu, Sathwik Somalanka, Naga Vedith, Devesh, Vijay Arun Cr, Pranaya Vamsi, Madhu Nekkalapudi, Pranaya Vamsy Rambhatla(PVR).\n\nProduced by Infinitum​ Network Solutions.\nCo-Producer: Shanmukh Jaswanth\n\nWritten by  Subbu. K \n\nDirected by Avinash \n\nCinematography: Vamsi Srinivas \n\nMusic: Anivee\nAdditional programming - Ashok Sridharan\nFlute - Sanjay Balajee\n\nAdditional Programming: Ashok Sridharan\n\nEditing: Krishna Karthik Vunnava\n\nDI: Kumba Shiva Kumar\n\nBrands Manager: Bhargav.T\n\nSfx and Mixing - Marcus\n\nPoster Designer: Nikhil Chotu, Shiva Krishna.\n\nSubtitles - M.L. Prabhakaran\n\nSound Engineer: Dasari Kesava Naidu, Kanukuntla Bhaskar.\n\nCostume Designer: Sriya Patel\n\nCostume Courtesy: Priyanshi Collections\n( https://instagram.com/priyanshi_collections?igshid=MzRlODBiNWFlZA== )\n\nLine Producer: Siva Geddam, Mohan Reddy.\n\nExecutive Producer: Rahul Raghavendra \n\n#StudentWebSeries #ShanmukhJaswanth #InfinitumMedia #TeluguWebSeries2023 \n\nFollow Infinitum Originals on \n\nFacebook: https://www.facebook.com/InfinitumOriginals\nInstagram: https://www.instagram.com/infinitum_originals/"
        },
        "defaultAudioLanguage": "te"
      },
      "contentDetails": {
        "duration": "PT35M46S",
        "dimension": "2d",
        "definition": "hd",
        "caption": "true",
        "licensedContent": true,
        "contentRating": {
          
        },
        "projection": "rectangular"
      },
      "statistics": {
        "viewCount": "4740663",
        "likeCount": "297903",
        "favoriteCount": "0",
        "commentCount": "7852"
      }
    },
    {
      "kind": "youtube#video",
      "etag": "YXkw9extWXmDftcrrF48jdDIddo",
      "id": "Zl8alBdIfpg",
      "snippet": {
        "publishedAt": "2023-10-19T15:00:33Z",
        "channelId": "UCpEhnqL0y41EpW2TvWAHD7Q",
        "title": "NEW! Barsatein - Mausam Pyar Ka - Ep 74 | 19 Oct 2023 | Teaser",
        "description": "Click here to Subscribe to SET India: https://www.youtube.com/channel/UCpEhnqL0y41EpW2TvWAHD7Q?sub_confirmation=1\n\nEpisode 74: सगाई की खुशियाँ \n -----------------------------------------------------------------\nAradhana is ready to accept Reyansh's hand in engagement. Meanwhile, Jai thinks that he is the one getting engaged to Aradhna. Meanwhile, Malini and her husband discuss the things related to their daughters' happiness. Will the engagement ceremony go smoothly? or any major twist waiting for Aradhana? What will happen now? Watch the episode to learn more. \n\nShow Name: Barsatein - Mausam Pyaar Ka\nCast: Shivangi Joshi, Kushal Tandon\nEpisode: 74\nDirector: Atif Khan\nProducer: Ekta Kapoor\n\n#barsateinmausampyaarka #setindia #बरसातेंमौसमप्यारका #kushaltandon #shivangijoshi \n\nAbout Barsatein - Mausam Pyaar Kaa:\n------------------------------------------------------------\nA sensible and ambitious journalist joins a media company run by a suave maverick man. While united in their passion for honest and ground-breaking journalism, their contrasting characters immediately put them at loggerheads. What will happen when she starts falling in love with him despite the red flags? 'Barsatein - Mausam Pyaar Ka' stars Shivangi Joshi and Kushal Tandon in lead roles.\n\nClick here to watch the full episode of Barsatein - Mausam Pyaar Ka:\nhttps://www.sonyliv.com/dplnk?schema=sony://asset/1000247365\n\nNEW! Barsatein - Mausam Pyar Ka - Ep 74 | 19 Oct 2023 | Teaser",
        "thumbnails": {
          "default": {
            "url": "https://i.ytimg.com/vi/Zl8alBdIfpg/default.jpg",
            "width": 120,
            "height": 90
          },
          "medium": {
            "url": "https://i.ytimg.com/vi/Zl8alBdIfpg/mqdefault.jpg",
            "width": 320,
            "height": 180
          },
          "high": {
            "url": "https://i.ytimg.com/vi/Zl8alBdIfpg/hqdefault.jpg",
            "width": 480,
            "height": 360
          },
          "standard": {
            "url": "https://i.ytimg.com/vi/Zl8alBdIfpg/sddefault.jpg",
            "width": 640,
            "height": 480
          },
          "maxres": {
            "url": "https://i.ytimg.com/vi/Zl8alBdIfpg/maxresdefault.jpg",
            "width": 1280,
            "height": 720
          }
        },
        "channelTitle": "SET India",
        "tags": [
          "Shivangi Joshi",
          "Barsatein serial",
          "hindi tv show",
          "बरसातें",
          "Barsatein story",
          "new story",
          "set india",
          "hindi tv serials",
          "Barsatein new",
          "barsatein",
          "barsatein serial",
          "barsatein shivangi joshi",
          "barsatein serial new",
          "barsaatein new show online",
          "barsaatein",
          "barsatein new",
          "barsaatein story",
          "barsatein star cast",
          "barsatein new show",
          "ekta kapoor barsatein",
          "sony tv show barsaatein",
          "Barsatein kushal tandon",
          "barsatein today episode",
          "barsatein teaser today episode",
          "barsatein teaser ep 74"
        ],
        "categoryId": "24",
        "liveBroadcastContent": "none",
        "localized": {
          "title": "NEW! Barsatein - Mausam Pyar Ka - Ep 74 | 19 Oct 2023 | Teaser",
          "description": "Click here to Subscribe to SET India: https://www.youtube.com/channel/UCpEhnqL0y41EpW2TvWAHD7Q?sub_confirmation=1\n\nEpisode 74: सगाई की खुशियाँ \n -----------------------------------------------------------------\nAradhana is ready to accept Reyansh's hand in engagement. Meanwhile, Jai thinks that he is the one getting engaged to Aradhna. Meanwhile, Malini and her husband discuss the things related to their daughters' happiness. Will the engagement ceremony go smoothly? or any major twist waiting for Aradhana? What will happen now? Watch the episode to learn more. \n\nShow Name: Barsatein - Mausam Pyaar Ka\nCast: Shivangi Joshi, Kushal Tandon\nEpisode: 74\nDirector: Atif Khan\nProducer: Ekta Kapoor\n\n#barsateinmausampyaarka #setindia #बरसातेंमौसमप्यारका #kushaltandon #shivangijoshi \n\nAbout Barsatein - Mausam Pyaar Kaa:\n------------------------------------------------------------\nA sensible and ambitious journalist joins a media company run by a suave maverick man. While united in their passion for honest and ground-breaking journalism, their contrasting characters immediately put them at loggerheads. What will happen when she starts falling in love with him despite the red flags? 'Barsatein - Mausam Pyaar Ka' stars Shivangi Joshi and Kushal Tandon in lead roles.\n\nClick here to watch the full episode of Barsatein - Mausam Pyaar Ka:\nhttps://www.sonyliv.com/dplnk?schema=sony://asset/1000247365\n\nNEW! Barsatein - Mausam Pyar Ka - Ep 74 | 19 Oct 2023 | Teaser"
        },
        "defaultAudioLanguage": "hi"
      },
      "contentDetails": {
        "duration": "PT10M30S",
        "dimension": "2d",
        "definition": "hd",
        "caption": "false",
        "licensedContent": true,
        "regionRestriction": {
          "allowed": [
            "IN",
            "PK"
          ]
        },
        "contentRating": {
          
        },
        "projection": "rectangular"
      },
      "statistics": {
        "viewCount": "1193421",
        "likeCount": "18911",
        "favoriteCount": "0",
        "commentCount": "354"
      }
    },
    {
      "kind": "youtube#video",
      "etag": "Dm7eaNS2HXp1K_g_UxxWE2USeKo",
      "id": "OlxOyDQxqpM",
      "snippet": {
        "publishedAt": "2023-10-18T09:13:42Z",
        "channelId": "UCebC4x5l2-PQxg46Ucv9CsA",
        "title": "New 2023 Diwali Stash Worth ₹500000 Testing | 5 लाख रूपये के पटाखे🔥🔥",
        "description": "Hello guys, is video me humne humara aaj tak ka most expensive new diwali stash dikhaya hai jiski keemat 500000 rupees hai.\n\nOur Unboxing Channel- https://www.youtube.com/channel/UCIcKN-VXhkZNpf5DRdHp9JA\nOur Shorts Channel- https://www.youtube.com/channel/UC7bZ8U3-WqDzHiyz6Hc6TmA\nFollow Me on Instagram- https://www.instagram.com/amit.yt/\nFollow Us On Facebook- https://www.facebook.com/CrazyXYZfb/",
        "thumbnails": {
          "default": {
            "url": "https://i.ytimg.com/vi/OlxOyDQxqpM/default.jpg",
            "width": 120,
            "height": 90
          },
          "medium": {
            "url": "https://i.ytimg.com/vi/OlxOyDQxqpM/mqdefault.jpg",
            "width": 320,
            "height": 180
          },
          "high": {
            "url": "https://i.ytimg.com/vi/OlxOyDQxqpM/hqdefault.jpg",
            "width": 480,
            "height": 360
          },
          "standard": {
            "url": "https://i.ytimg.com/vi/OlxOyDQxqpM/sddefault.jpg",
            "width": 640,
            "height": 480
          },
          "maxres": {
            "url": "https://i.ytimg.com/vi/OlxOyDQxqpM/maxresdefault.jpg",
            "width": 1280,
            "height": 720
          }
        },
        "channelTitle": "Crazy XYZ",
        "tags": [
          "crazy xyz diwali stash",
          "diwali stash crazy xyz",
          "crazy xyz",
          "diwali stash",
          "crazy",
          "xyz",
          "2023 diwali stash",
          "crazy xyz 2023 diwali stash",
          "crazy xyz diwali video",
          "diwali crackers unboxing",
          "diwali pataka",
          "best diwali pataka",
          "diwali skyshot",
          "diwali anaar",
          "diwali chakri",
          "diwali sutli",
          "mirchi patakha",
          "the indian unboxer",
          "happy diwali",
          "diwali celebration",
          "best diwali celebration",
          "crazy xyz stash",
          "new stash",
          "rupees 5 lakh",
          "rupees 500000",
          "500000 diwali stash",
          "most expensive diwali"
        ],
        "categoryId": "28",
        "liveBroadcastContent": "none",
        "localized": {
          "title": "New 2023 Diwali Stash Worth ₹500000 Testing | 5 लाख रूपये के पटाखे🔥🔥",
          "description": "Hello guys, is video me humne humara aaj tak ka most expensive new diwali stash dikhaya hai jiski keemat 500000 rupees hai.\n\nOur Unboxing Channel- https://www.youtube.com/channel/UCIcKN-VXhkZNpf5DRdHp9JA\nOur Shorts Channel- https://www.youtube.com/channel/UC7bZ8U3-WqDzHiyz6Hc6TmA\nFollow Me on Instagram- https://www.instagram.com/amit.yt/\nFollow Us On Facebook- https://www.facebook.com/CrazyXYZfb/"
        },
        "defaultAudioLanguage": "hi"
      },
      "contentDetails": {
        "duration": "PT19M53S",
        "dimension": "2d",
        "definition": "hd",
        "caption": "false",
        "licensedContent": true,
        "contentRating": {
          
        },
        "projection": "rectangular"
      },
      "statistics": {
        "viewCount": "5289475",
        "likeCount": "494652",
        "favoriteCount": "0",
        "commentCount": "21267"
      }
    },
    {
      "kind": "youtube#video",
      "etag": "B-UKwiqjB_nOo5GNbUTNc2LGfWw",
      "id": "iKpfLiOjKDI",
      "snippet": {
        "publishedAt": "2023-10-19T13:30:26Z",
        "channelId": "UCSfxFZFzcpYMbOB3A1rWHAg",
        "title": "India vs Pakistan Battle - Playing World Cup 2023 | SlayyPop",
        "description": "Get smooth hairfree skin with makeO Laser hair reduction treatment. Book a FREE Laser trial at their experience centre now: https://skinnsi.makeo.app/402wi0N\nDiscount code: SLY23SN\n\nYou can find the nearest makeO experience centre here: https://skinnsi.makeo.app/3M8WS2R\n\nIndia vs Pakistan. Game me kuch bhi ho, real result sabko pata hai. ICC Cricket World Cup 2023 highlights. Rohit Sharma vs Babar Azam. Virat Kohli vs Rizwan, etc\nIndia played Bangladesh today.\n\nInstagram -  @Abhyudaya_Mohan & @GautamiKawale\nhttps://www.instagram.com/abhyudaya_mohan/\nhttps://www.instagram.com/gautamikawale/\n\nSlayyPop videos edited by - Kshitij\n\n#makeO #makeOskin #skinnsiisnowmakeO #makeOlaserhairreduction #laserhairreduction #laserhairremoval #makeOExperienceCentre #nohairhassles #smoothskin #hairfreeskin #ad",
        "thumbnails": {
          "default": {
            "url": "https://i.ytimg.com/vi/iKpfLiOjKDI/default.jpg",
            "width": 120,
            "height": 90
          },
          "medium": {
            "url": "https://i.ytimg.com/vi/iKpfLiOjKDI/mqdefault.jpg",
            "width": 320,
            "height": 180
          },
          "high": {
            "url": "https://i.ytimg.com/vi/iKpfLiOjKDI/hqdefault.jpg",
            "width": 480,
            "height": 360
          },
          "standard": {
            "url": "https://i.ytimg.com/vi/iKpfLiOjKDI/sddefault.jpg",
            "width": 640,
            "height": 480
          },
          "maxres": {
            "url": "https://i.ytimg.com/vi/iKpfLiOjKDI/maxresdefault.jpg",
            "width": 1280,
            "height": 720
          }
        },
        "channelTitle": "SlayyPop",
        "tags": [
          "slayy point",
          "slayypop",
          "abhyudaya",
          "gautami",
          "india",
          "pakistan",
          "india vs pakistan",
          "Virat Kohli",
          "Virat century",
          "India match",
          "World Cup",
          "Cricket",
          "Cricket India",
          "Match highlights",
          "Cricket latest",
          "Match today",
          "India game",
          "Kohli",
          "Rohit Sharma"
        ],
        "categoryId": "20",
        "liveBroadcastContent": "none",
        "localized": {
          "title": "India vs Pakistan Battle - Playing World Cup 2023 | SlayyPop",
          "description": "Get smooth hairfree skin with makeO Laser hair reduction treatment. Book a FREE Laser trial at their experience centre now: https://skinnsi.makeo.app/402wi0N\nDiscount code: SLY23SN\n\nYou can find the nearest makeO experience centre here: https://skinnsi.makeo.app/3M8WS2R\n\nIndia vs Pakistan. Game me kuch bhi ho, real result sabko pata hai. ICC Cricket World Cup 2023 highlights. Rohit Sharma vs Babar Azam. Virat Kohli vs Rizwan, etc\nIndia played Bangladesh today.\n\nInstagram -  @Abhyudaya_Mohan & @GautamiKawale\nhttps://www.instagram.com/abhyudaya_mohan/\nhttps://www.instagram.com/gautamikawale/\n\nSlayyPop videos edited by - Kshitij\n\n#makeO #makeOskin #skinnsiisnowmakeO #makeOlaserhairreduction #laserhairreduction #laserhairremoval #makeOExperienceCentre #nohairhassles #smoothskin #hairfreeskin #ad"
        },
        "defaultAudioLanguage": "en-IN"
      },
      "contentDetails": {
        "duration": "PT14M55S",
        "dimension": "2d",
        "definition": "hd",
        "caption": "false",
        "licensedContent": true,
        "contentRating": {
          
        },
        "projection": "rectangular"
      },
      "statistics": {
        "viewCount": "626862",
        "likeCount": "50675",
        "favoriteCount": "0",
        "commentCount": "1315"
      }
    },
    {
      "kind": "youtube#video",
      "etag": "lBn9fFCHTomFGachISk364hn1Po",
      "id": "SJHRCWj_XOQ",
      "snippet": {
        "publishedAt": "2023-10-19T03:54:19Z",
        "channelId": "UC-qTldS8DNIGOfIVc0G8t-w",
        "title": "Leo Movie Review | Vijay Thalapathy , Trisha , Arjun | Lokesh Kanagaraj | Tamil Movies | Thyview",
        "description": "Written By Pavan\nVoiced By Sai Charan Varma\n\nHave you Watched our video on ChatGPT Story Of LEO  https://youtu.be/gdgerXwhDWg?si=U80gG6Bx6xzBibyw \n\n\nThyview Shorts : https://www.youtube.com/watch?v=N3W8odHEtgI&list=PLDDTQpF8LWaVN17jmf9BSRrnr68sepGJS\n\nHave u subscribed to Thyview yet ? Join us here : https://bit.ly/2JgQQwk\n\nSubscribe to Thyview Reviews : https://youtube.com/channel/UCTmCilqEPbAVKKU50wJ1apw\n\nSubscribe to Cinema Kathalu : https://youtube.com/channel/UC-6SVStIAhh4enuGbBHhAqw\n\n\nFollow us on :\n\nhttps://www.facebook.com/thyview\nhttps://www.twitter.com/thyview\nhttps://instagram.com/thyview\n\nTelegram : http://t.me/gaaliseenu\n\n#Vijay #Leo #thyview #thyviewreviews #LokeshKanagaraj #lcu #Trisha #Arjun #Mysskin #gowthammenon #SanjayDutt #Anirudh #MathewThomas #Kollywood #Thyviewreview #ChatGpt  #PriyaAnand",
        "thumbnails": {
          "default": {
            "url": "https://i.ytimg.com/vi/SJHRCWj_XOQ/default.jpg",
            "width": 120,
            "height": 90
          },
          "medium": {
            "url": "https://i.ytimg.com/vi/SJHRCWj_XOQ/mqdefault.jpg",
            "width": 320,
            "height": 180
          },
          "high": {
            "url": "https://i.ytimg.com/vi/SJHRCWj_XOQ/hqdefault.jpg",
            "width": 480,
            "height": 360
          },
          "standard": {
            "url": "https://i.ytimg.com/vi/SJHRCWj_XOQ/sddefault.jpg",
            "width": 640,
            "height": 480
          },
          "maxres": {
            "url": "https://i.ytimg.com/vi/SJHRCWj_XOQ/maxresdefault.jpg",
            "width": 1280,
            "height": 720
          }
        },
        "channelTitle": "Thyview",
        "tags": [
          "Leo story",
          "chatgpt wrote story of Leo",
          "Leo promo",
          "thyview",
          "Vijay",
          "lokesh kanagaraj",
          "Trisha",
          "arjun",
          "Mathew Thomas",
          "gvm",
          "Gowtham Menon",
          "mysskin",
          "Sanjay dutt",
          "lokesh kanagaraj cinematic universe",
          "Rolex",
          "suriya",
          "Mansoor Ali",
          "anirudh",
          "Vikram",
          "Vijay thalapathy",
          "varisu",
          "kaithi",
          "Kamal haasan",
          "history of violence",
          "Rolex entry",
          "thyview chat gpt",
          "Vijay movies",
          "Leo announcement",
          "Leo breakdown",
          "Leo trailer",
          "Anirudh Ravichander",
          "thyview leo",
          "thyview videos",
          "thyview leo trailer review",
          "2023",
          "dasra",
          "leo"
        ],
        "categoryId": "24",
        "liveBroadcastContent": "none",
        "localized": {
          "title": "Leo Movie Review | Vijay Thalapathy , Trisha , Arjun | Lokesh Kanagaraj | Tamil Movies | Thyview",
          "description": "Written By Pavan\nVoiced By Sai Charan Varma\n\nHave you Watched our video on ChatGPT Story Of LEO  https://youtu.be/gdgerXwhDWg?si=U80gG6Bx6xzBibyw \n\n\nThyview Shorts : https://www.youtube.com/watch?v=N3W8odHEtgI&list=PLDDTQpF8LWaVN17jmf9BSRrnr68sepGJS\n\nHave u subscribed to Thyview yet ? Join us here : https://bit.ly/2JgQQwk\n\nSubscribe to Thyview Reviews : https://youtube.com/channel/UCTmCilqEPbAVKKU50wJ1apw\n\nSubscribe to Cinema Kathalu : https://youtube.com/channel/UC-6SVStIAhh4enuGbBHhAqw\n\n\nFollow us on :\n\nhttps://www.facebook.com/thyview\nhttps://www.twitter.com/thyview\nhttps://instagram.com/thyview\n\nTelegram : http://t.me/gaaliseenu\n\n#Vijay #Leo #thyview #thyviewreviews #LokeshKanagaraj #lcu #Trisha #Arjun #Mysskin #gowthammenon #SanjayDutt #Anirudh #MathewThomas #Kollywood #Thyviewreview #ChatGpt  #PriyaAnand"
        },
        "defaultAudioLanguage": "en-US"
      },
      "contentDetails": {
        "duration": "PT4M12S",
        "dimension": "2d",
        "definition": "hd",
        "caption": "false",
        "licensedContent": true,
        "contentRating": {
          
        },
        "projection": "rectangular"
      },
      "statistics": {
        "viewCount": "552056",
        "likeCount": "32071",
        "favoriteCount": "0",
        "commentCount": "2059"
      }
    },
    {
      "kind": "youtube#video",
      "etag": "8-vP3SZLv9hNYF3fj41ZJrU7yEE",
      "id": "64-j4INDwVM",
      "snippet": {
        "publishedAt": "2023-10-19T01:38:12Z",
        "channelId": "UC22cpNxti7TfrYzcPVsiJOA",
        "title": "Leo Public Review | Thalapathy Vijay | Lokesh Kanagaraj | Leo Review | #LeoReview | LCU | Anirudh",
        "description": "Watch Leo Public Review\n\nMovie: Leo\nStarring : Thalapathy Vijay, Sanjay Dutt, Trisha, Arjun, Gautham Vasudev Menon, Mysskin, Mansoor Ali Khan, Priya Anand\n\nWritten & Directed by Lokesh Kanagaraj\nMusic : Anirudh Ravichander\nProducer: Lalit Kumar\nCo Producer : Jagadish Palanisamy\nBanner : Seven Screen Studio\nDirector of Photography : Manoj Paramahamsa\nAction : Anbariv \nEditor : Philomin Raj \nArt Direction : N. Sathees Kumar \nChoreography : Dinesh\nCostume designers - Pallavi Singh, Eka Lakhani, Praveen Raja\nDialogue Writer : Lokesh Kanagaraj, Rathna Kumar, Deeraj Vaidy\n\n\n\n#LeoReview #ThalapathyVijay #LokeshKanagaraj #Anirudh #sanjaydutt #arjunsarja #trisha #trishakrishnan  #LeoTrailer #mysskin #gouthammenon #priyaanand \n\nShruti.TV\nConnect us -\n\nMail id      : contact@shruti.tv\n\nTwitter id : www.twitter.com/shrutitv\nWebsite   : www.shruti.tv\nFollow us : www.facebook.com/shrutiwebtv\n\n3\n\n\n4\n\nTamil Cinema, Kollywood Updates, tamil cinema, tamil movies, tamil, tamil cinema (film genre), latest tamil movies, new tamil movies,  tamil movie, cinema, tamil cinema troll, tamil cinema review, tamil new movies, tamil new movies online,  latest tamil movie, tamil talkies.net, tamil cinema latest news, tamil cinema review latest, tamil new movies review, Movie Public Reviews,\n\nLeo Public Review, Leo Review, Leo Vijay movie, Leo Vijay, Leo Thalapathy, Thalapathy Vijay, Lokesh Kanagaraj, lcu, lokesh cinematic universe, Anirudh, Leo Public Reaction, Leo Public Talk,\nleo, leo fdfs, leo fdfs time, leo update, leo movie, leo trailer, leo fdfs celebration, leo promo, leo fdfs review, leo fdfs timing, leo fdfs tickets, leo song, leo fdfs cancelled, leo songs, leo fdfs permission, leo bgm, leo lcu, leo movie trailer, leo fdfs promo, leo fdfs kerala,leo review, leo latest update, leo booking, leo glimpse,leo latest updates, leo fdfs news tamil, leo tn fdfs time, leo today update, leo special show, leo trailer review, leoLCU, leo trailer, leo trailer review, leo trailer reaction, leo movie,leo hindi trailer,leo movie trailer, leo official trailer, leo trailer tamil, leo review, leo teaser,  leo trailer hindi, leo reaction, leo thalapathy vijay, leo das, leo hindi, leo story, leo update, leo anirudh, leo glimpse, leo trailer decoding, leo das movie, leo tamil movie, leo vijay movie, leo das glimpse, vijay movie leo, leo movie glimpse, leo trailer suntv, Leo Vijay Movie, leo movie review, leo trailer, leo vijay movie, thalapathy vijay, vijay, leo thalapathy vijay, leo vijay, leo update, badass leo, leo tamil movie, vijay movie leo, leo movie trailer,actor vijay movie, leo das movie, leo badass, leo audio launch, leo second single, leo tamil movie trailer, thalapathy vijay movie, leo movie glimpse, thalapathy vijay movie trailer, leo official trailer reaction, leo teaser, leo das, leo glimpse, leo movie, leo das glimpse, leo anirudh, leo lokesh kanagaraj, lokesh leo interview ,lokesh kanagaraj, lokesh interview, lokesh kanagaraj movie, lokesh kanagaraj interview, lokesh leo glimpse,  leo anirudh, lokesh kanagaraj about leo, lokesh latest interview, leo tamil movie, leo vijay movie, leo official trailer,leo tamil movie trailer, leo movie tamil reivew, leo movie glimpse, leo lcu, Lio Review, Lio Public Review, leeo review,",
        "thumbnails": {
          "default": {
            "url": "https://i.ytimg.com/vi/64-j4INDwVM/default.jpg",
            "width": 120,
            "height": 90
          },
          "medium": {
            "url": "https://i.ytimg.com/vi/64-j4INDwVM/mqdefault.jpg",
            "width": 320,
            "height": 180
          },
          "high": {
            "url": "https://i.ytimg.com/vi/64-j4INDwVM/hqdefault.jpg",
            "width": 480,
            "height": 360
          },
          "standard": {
            "url": "https://i.ytimg.com/vi/64-j4INDwVM/sddefault.jpg",
            "width": 640,
            "height": 480
          },
          "maxres": {
            "url": "https://i.ytimg.com/vi/64-j4INDwVM/maxresdefault.jpg",
            "width": 1280,
            "height": 720
          }
        },
        "channelTitle": "Shruti TV",
        "tags": [
          "Leo Public Review",
          "Leo Review",
          "Leo Vijay movie",
          "Leo Vijay",
          "Leo Thalapathy",
          "Thalapathy Vijay",
          "Lokesh Kanagaraj",
          "lcu",
          "lokesh cinematic universe",
          "Anirudh",
          "Leo Public Reaction",
          "Leo Public Talk",
          "thalapathy vijay movie",
          "leo lcu",
          "Lio Review",
          "Lio Public Review",
          "leeo review",
          "lokesh kanagaraj movie",
          "lokesh kanagaraj interview",
          "LCU",
          "leo tamil movie",
          "leo vijay movie",
          "leo das",
          "public review",
          "public reation",
          "theatre response",
          "leo reaction",
          "leo meme review",
          "leo memes",
          "blue sattai maran"
        ],
        "categoryId": "24",
        "liveBroadcastContent": "none",
        "localized": {
          "title": "Leo Public Review | Thalapathy Vijay | Lokesh Kanagaraj | Leo Review | #LeoReview | LCU | Anirudh",
          "description": "Watch Leo Public Review\n\nMovie: Leo\nStarring : Thalapathy Vijay, Sanjay Dutt, Trisha, Arjun, Gautham Vasudev Menon, Mysskin, Mansoor Ali Khan, Priya Anand\n\nWritten & Directed by Lokesh Kanagaraj\nMusic : Anirudh Ravichander\nProducer: Lalit Kumar\nCo Producer : Jagadish Palanisamy\nBanner : Seven Screen Studio\nDirector of Photography : Manoj Paramahamsa\nAction : Anbariv \nEditor : Philomin Raj \nArt Direction : N. Sathees Kumar \nChoreography : Dinesh\nCostume designers - Pallavi Singh, Eka Lakhani, Praveen Raja\nDialogue Writer : Lokesh Kanagaraj, Rathna Kumar, Deeraj Vaidy\n\n\n\n#LeoReview #ThalapathyVijay #LokeshKanagaraj #Anirudh #sanjaydutt #arjunsarja #trisha #trishakrishnan  #LeoTrailer #mysskin #gouthammenon #priyaanand \n\nShruti.TV\nConnect us -\n\nMail id      : contact@shruti.tv\n\nTwitter id : www.twitter.com/shrutitv\nWebsite   : www.shruti.tv\nFollow us : www.facebook.com/shrutiwebtv\n\n3\n\n\n4\n\nTamil Cinema, Kollywood Updates, tamil cinema, tamil movies, tamil, tamil cinema (film genre), latest tamil movies, new tamil movies,  tamil movie, cinema, tamil cinema troll, tamil cinema review, tamil new movies, tamil new movies online,  latest tamil movie, tamil talkies.net, tamil cinema latest news, tamil cinema review latest, tamil new movies review, Movie Public Reviews,\n\nLeo Public Review, Leo Review, Leo Vijay movie, Leo Vijay, Leo Thalapathy, Thalapathy Vijay, Lokesh Kanagaraj, lcu, lokesh cinematic universe, Anirudh, Leo Public Reaction, Leo Public Talk,\nleo, leo fdfs, leo fdfs time, leo update, leo movie, leo trailer, leo fdfs celebration, leo promo, leo fdfs review, leo fdfs timing, leo fdfs tickets, leo song, leo fdfs cancelled, leo songs, leo fdfs permission, leo bgm, leo lcu, leo movie trailer, leo fdfs promo, leo fdfs kerala,leo review, leo latest update, leo booking, leo glimpse,leo latest updates, leo fdfs news tamil, leo tn fdfs time, leo today update, leo special show, leo trailer review, leoLCU, leo trailer, leo trailer review, leo trailer reaction, leo movie,leo hindi trailer,leo movie trailer, leo official trailer, leo trailer tamil, leo review, leo teaser,  leo trailer hindi, leo reaction, leo thalapathy vijay, leo das, leo hindi, leo story, leo update, leo anirudh, leo glimpse, leo trailer decoding, leo das movie, leo tamil movie, leo vijay movie, leo das glimpse, vijay movie leo, leo movie glimpse, leo trailer suntv, Leo Vijay Movie, leo movie review, leo trailer, leo vijay movie, thalapathy vijay, vijay, leo thalapathy vijay, leo vijay, leo update, badass leo, leo tamil movie, vijay movie leo, leo movie trailer,actor vijay movie, leo das movie, leo badass, leo audio launch, leo second single, leo tamil movie trailer, thalapathy vijay movie, leo movie glimpse, thalapathy vijay movie trailer, leo official trailer reaction, leo teaser, leo das, leo glimpse, leo movie, leo das glimpse, leo anirudh, leo lokesh kanagaraj, lokesh leo interview ,lokesh kanagaraj, lokesh interview, lokesh kanagaraj movie, lokesh kanagaraj interview, lokesh leo glimpse,  leo anirudh, lokesh kanagaraj about leo, lokesh latest interview, leo tamil movie, leo vijay movie, leo official trailer,leo tamil movie trailer, leo movie tamil reivew, leo movie glimpse, leo lcu, Lio Review, Lio Public Review, leeo review,"
        },
        "defaultAudioLanguage": "en"
      },
      "contentDetails": {
        "duration": "PT9M29S",
        "dimension": "2d",
        "definition": "hd",
        "caption": "false",
        "licensedContent": true,
        "contentRating": {
          
        },
        "projection": "rectangular"
      },
      "statistics": {
        "viewCount": "1137219",
        "likeCount": "22766",
        "favoriteCount": "0",
        "commentCount": "805"
      }
    },
    {
      "kind": "youtube#video",
      "etag": "tV1EkdfwYuNBzyB-5hDf6AFUx6I",
      "id": "q6H__-s4gAU",
      "snippet": {
        "publishedAt": "2023-10-18T05:30:12Z",
        "channelId": "UCSM54qcBP60U61HOMm_SUqA",
        "title": "BOLERO Teaser - Elvish Yadav & Manisha Rani | Preetinder | Asees Kaur | Rajat N | Babbu |Anshul Garg",
        "description": "Anshul Garg presents teaser of Bolero featuring Elvish Yadav & Manisha Rani \n\nAudio credits \nSinger : Preetinder & Asees Kaur\nLyrics : Babbu\nMusic : Rajat Nagpal\n\nVideo credits\nFeaturing : Elvish Yadav & Manisha Rani \nDirector : Nitish Raizada\n\nPlayDMF Team\nFounder & CEO : Anshul Garg\nPlayDMF Project Head : Raghav Sharma \nPlayDMF Project Manager : Sankalp Garg\nPlayDMF Team : Gaurav Arora, Ashima Chauhan & Akshay Mahadik\nSpecial Thanks : Ingrooves Team \n\nhttps://www.ingrooves.com/\n\nIngrooves Team \nHead : Amit Sharma \nTeam : Nagesh Jadhav, Kajal Israni, Amol Suryavanshi, Lavanya Das, Nishtha Sikroria\n\nTravel and hospitality partner : PRM Hospitality",
        "thumbnails": {
          "default": {
            "url": "https://i.ytimg.com/vi/q6H__-s4gAU/default.jpg",
            "width": 120,
            "height": 90
          },
          "medium": {
            "url": "https://i.ytimg.com/vi/q6H__-s4gAU/mqdefault.jpg",
            "width": 320,
            "height": 180
          },
          "high": {
            "url": "https://i.ytimg.com/vi/q6H__-s4gAU/hqdefault.jpg",
            "width": 480,
            "height": 360
          },
          "standard": {
            "url": "https://i.ytimg.com/vi/q6H__-s4gAU/sddefault.jpg",
            "width": 640,
            "height": 480
          },
          "maxres": {
            "url": "https://i.ytimg.com/vi/q6H__-s4gAU/maxresdefault.jpg",
            "width": 1280,
            "height": 720
          }
        },
        "channelTitle": "Play DMF",
        "tags": [
          "Desi Music Factory",
          "bollywood",
          "Latest Hindi Songs'",
          "New Songs",
          "Viral Song",
          "Trending",
          "latest punjabi songs",
          "official video",
          "most watched",
          "New Hindi Song",
          "elvishyadav",
          "manisharani",
          "elvishmanish",
          "elvisha",
          "elvishmanisharani",
          "elvish yadav latest song",
          "latest haryanvi song 2023",
          "chore haryane aale",
          "big boss elvish yadav",
          "big boss manisha rani",
          "manisha rani song",
          "latest song 2023",
          "play dmf",
          "play dmf haryanvi",
          "elvish yadav vlogs",
          "manisha latest song",
          "elvish manisha latest song",
          "shorts"
        ],
        "categoryId": "10",
        "liveBroadcastContent": "none",
        "localized": {
          "title": "BOLERO Teaser - Elvish Yadav & Manisha Rani | Preetinder | Asees Kaur | Rajat N | Babbu |Anshul Garg",
          "description": "Anshul Garg presents teaser of Bolero featuring Elvish Yadav & Manisha Rani \n\nAudio credits \nSinger : Preetinder & Asees Kaur\nLyrics : Babbu\nMusic : Rajat Nagpal\n\nVideo credits\nFeaturing : Elvish Yadav & Manisha Rani \nDirector : Nitish Raizada\n\nPlayDMF Team\nFounder & CEO : Anshul Garg\nPlayDMF Project Head : Raghav Sharma \nPlayDMF Project Manager : Sankalp Garg\nPlayDMF Team : Gaurav Arora, Ashima Chauhan & Akshay Mahadik\nSpecial Thanks : Ingrooves Team \n\nhttps://www.ingrooves.com/\n\nIngrooves Team \nHead : Amit Sharma \nTeam : Nagesh Jadhav, Kajal Israni, Amol Suryavanshi, Lavanya Das, Nishtha Sikroria\n\nTravel and hospitality partner : PRM Hospitality"
        },
        "defaultAudioLanguage": "en"
      },
      "contentDetails": {
        "duration": "PT29S",
        "dimension": "2d",
        "definition": "hd",
        "caption": "false",
        "licensedContent": true,
        "contentRating": {
          
        },
        "projection": "rectangular"
      },
      "statistics": {
        "viewCount": "2920451",
        "likeCount": "204587",
        "favoriteCount": "0",
        "commentCount": "45425"
      }
    },
    {
      "kind": "youtube#video",
      "etag": "xhvGcQ5P7VQ8br_TBgVItkZ-BCI",
      "id": "qf3BxwtPS_E",
      "snippet": {
        "publishedAt": "2023-10-18T14:32:28Z",
        "channelId": "UCPtPyb4VvaNqjkbL_tSVFVA",
        "title": "FLYING BEAST & RITU RATHEE ROAST ON THE THUGESH SHOW | S01E09 | @FlyingBeast320",
        "description": "GET YOUR LAYERS SKIN HERE\nhttps://www.layers.shop/?utm_source=GauravTaneja&utm_medium=referral&utm_campaign=GauravTaneja_Thugesh\n\n#thugesh #flyingbeast #gauravtaneja \n\nWatch Desh Ka Dhoni Here!\nhttps://www.youtube.com/watch?v=0uqNK_gAkVg\n\nWelcome to Episode 9 of the thugesh show season 1 today we have with us flying beast & ritu rathee we talk about desh ka dhoni, funny flight stories from gaurav and reetu, and much more on this episode!\n\n▶️ Main Channel:  @Thugesh \n🎙️Asli Thugesh : @AsliThugesh \n👀Reaction Channel @UnfilteredThugesh \n🤏 Shorts Channel: @realthugesh \n\nTHINGS I USE!\nFlip glasses I use https://amzn.to/443ufv5\nSword I use- https://amzn.to/40B0z5B \nBest Camera I use - https://amzn.to/40AYFlt\nBest Lens I use- https://amzn.to/41LCFp8\n                             https://amzn.to/3L5aPgN\nbest Lights I use - https://amzn.to/42d6VcT\nBest tube lights I use- https://amzn.to/41yYqZB\nBest Mic I use- https://amzn.to/41VcGvr\nBest Tripod I use https://amzn.to/3V5ev71\nMy Watch https://amzn.to/3HacqRl\n\n\nFOLLOW ME ON:\n\n📸 Instagram: https://www.instagram.com/maheshkeshwala/\n🐦  Twitter: https://twitter.com/RealThugesh\n📖 Facebook: https://www.facebook.com/thugesh\n\n►DISCLAIMER\nCopyright Disclaimer under section 107 of the Copyright Act of 1976, allowance is made for “fair use” for purposes such as criticism, comment, news reporting, teaching, scholarship, education and research. Fair use is a use permitted by copyright statute that might otherwise be infringing.\n\nNote- all the comments and jokes made in the video are for the content and the clips and not on the person himself!! thank you :)",
        "thumbnails": {
          "default": {
            "url": "https://i.ytimg.com/vi/qf3BxwtPS_E/default.jpg",
            "width": 120,
            "height": 90
          },
          "medium": {
            "url": "https://i.ytimg.com/vi/qf3BxwtPS_E/mqdefault.jpg",
            "width": 320,
            "height": 180
          },
          "high": {
            "url": "https://i.ytimg.com/vi/qf3BxwtPS_E/hqdefault.jpg",
            "width": 480,
            "height": 360
          },
          "standard": {
            "url": "https://i.ytimg.com/vi/qf3BxwtPS_E/sddefault.jpg",
            "width": 640,
            "height": 480
          },
          "maxres": {
            "url": "https://i.ytimg.com/vi/qf3BxwtPS_E/maxresdefault.jpg",
            "width": 1280,
            "height": 720
          }
        },
        "channelTitle": "Thugesh",
        "tags": [
          "thugesh",
          "thugesh thug life",
          "thugesh funny",
          "thugesh latest video",
          "thugesh new video",
          "thugesh roast",
          "roast video",
          "late night show",
          "khabresh",
          "funny"
        ],
        "categoryId": "24",
        "liveBroadcastContent": "none",
        "localized": {
          "title": "FLYING BEAST & RITU RATHEE ROAST ON THE THUGESH SHOW | S01E09 | @FlyingBeast320",
          "description": "GET YOUR LAYERS SKIN HERE\nhttps://www.layers.shop/?utm_source=GauravTaneja&utm_medium=referral&utm_campaign=GauravTaneja_Thugesh\n\n#thugesh #flyingbeast #gauravtaneja \n\nWatch Desh Ka Dhoni Here!\nhttps://www.youtube.com/watch?v=0uqNK_gAkVg\n\nWelcome to Episode 9 of the thugesh show season 1 today we have with us flying beast & ritu rathee we talk about desh ka dhoni, funny flight stories from gaurav and reetu, and much more on this episode!\n\n▶️ Main Channel:  @Thugesh \n🎙️Asli Thugesh : @AsliThugesh \n👀Reaction Channel @UnfilteredThugesh \n🤏 Shorts Channel: @realthugesh \n\nTHINGS I USE!\nFlip glasses I use https://amzn.to/443ufv5\nSword I use- https://amzn.to/40B0z5B \nBest Camera I use - https://amzn.to/40AYFlt\nBest Lens I use- https://amzn.to/41LCFp8\n                             https://amzn.to/3L5aPgN\nbest Lights I use - https://amzn.to/42d6VcT\nBest tube lights I use- https://amzn.to/41yYqZB\nBest Mic I use- https://amzn.to/41VcGvr\nBest Tripod I use https://amzn.to/3V5ev71\nMy Watch https://amzn.to/3HacqRl\n\n\nFOLLOW ME ON:\n\n📸 Instagram: https://www.instagram.com/maheshkeshwala/\n🐦  Twitter: https://twitter.com/RealThugesh\n📖 Facebook: https://www.facebook.com/thugesh\n\n►DISCLAIMER\nCopyright Disclaimer under section 107 of the Copyright Act of 1976, allowance is made for “fair use” for purposes such as criticism, comment, news reporting, teaching, scholarship, education and research. Fair use is a use permitted by copyright statute that might otherwise be infringing.\n\nNote- all the comments and jokes made in the video are for the content and the clips and not on the person himself!! thank you :)"
        },
        "defaultAudioLanguage": "en"
      },
      "contentDetails": {
        "duration": "PT39M45S",
        "dimension": "2d",
        "definition": "hd",
        "caption": "false",
        "licensedContent": true,
        "contentRating": {
          
        },
        "projection": "rectangular"
      },
      "statistics": {
        "viewCount": "2168638",
        "likeCount": "191510",
        "favoriteCount": "0",
        "commentCount": "7014"
      }
    },
    {
      "kind": "youtube#video",
      "etag": "XGWY2iHMRGk04kD3HkffFiSFeJU",
      "id": "UcmgJAQ-Ibc",
      "snippet": {
        "publishedAt": "2023-10-18T13:58:56Z",
        "channelId": "UCR-uD130PlXKww_J2Q63CMg",
        "title": "Family Star Glimpse - Vijay Deverakonda, Mrunal Thakur | Parasuram | Dil Raju | Sankrathi 2024",
        "description": "Presenting #FamilyStar ft Vijay Deverakonda, Mrunal Thakur. Directed by Parasuram. Sankrathi 2024 Release. \n\nCast : Vijay Deverakonda, Mrunal Thakur \nDirector & Writer - Parasuram\nDOP : KU Mohanan \nMusic : Gopisundar\nArt Director: AS Prakash\nEditor : Marthand K Venkatesh \nCreative Producer : Vasu Varma\nProducers : Raju - Shirish\n\n——————————\n\nFull Telugu Movies - https://goo.gl/buaJpf\n\nFollow us on: \nTwitter: https://twitter.com/SVC_official\nFacebook: https://www.facebook.com/DilRajuOfficial\nFacebook: https://www.facebook.com/SriVenkateswaraCreations\nYouTube: http://goo.gl/dwcKmr\nInstagram: https://www.instagram.com/srivenkateswaracreations\nTelegram: https://t.me/SVC_Official",
        "thumbnails": {
          "default": {
            "url": "https://i.ytimg.com/vi/UcmgJAQ-Ibc/default.jpg",
            "width": 120,
            "height": 90
          },
          "medium": {
            "url": "https://i.ytimg.com/vi/UcmgJAQ-Ibc/mqdefault.jpg",
            "width": 320,
            "height": 180
          },
          "high": {
            "url": "https://i.ytimg.com/vi/UcmgJAQ-Ibc/hqdefault.jpg",
            "width": 480,
            "height": 360
          },
          "standard": {
            "url": "https://i.ytimg.com/vi/UcmgJAQ-Ibc/sddefault.jpg",
            "width": 640,
            "height": 480
          }
        },
        "channelTitle": "Dil Raju",
        "tags": [
          "Family star",
          "family star glimpse",
          "family star teaser",
          "family star trailer",
          "family star theatrical trailer",
          "family star songs",
          "family song promos",
          "vijay deverakonda family star",
          "vijay deverakonda latest movie trailer",
          "vijay deverakonda 2024 movie",
          "mrunal thakur in family star",
          "gopisundar",
          "dil raju movies",
          "parasuram movies"
        ],
        "categoryId": "24",
        "liveBroadcastContent": "none",
        "localized": {
          "title": "Family Star Glimpse - Vijay Deverakonda, Mrunal Thakur | Parasuram | Dil Raju | Sankrathi 2024",
          "description": "Presenting #FamilyStar ft Vijay Deverakonda, Mrunal Thakur. Directed by Parasuram. Sankrathi 2024 Release. \n\nCast : Vijay Deverakonda, Mrunal Thakur \nDirector & Writer - Parasuram\nDOP : KU Mohanan \nMusic : Gopisundar\nArt Director: AS Prakash\nEditor : Marthand K Venkatesh \nCreative Producer : Vasu Varma\nProducers : Raju - Shirish\n\n——————————\n\nFull Telugu Movies - https://goo.gl/buaJpf\n\nFollow us on: \nTwitter: https://twitter.com/SVC_official\nFacebook: https://www.facebook.com/DilRajuOfficial\nFacebook: https://www.facebook.com/SriVenkateswaraCreations\nYouTube: http://goo.gl/dwcKmr\nInstagram: https://www.instagram.com/srivenkateswaracreations\nTelegram: https://t.me/SVC_Official"
        },
        "defaultAudioLanguage": "te"
      },
      "contentDetails": {
        "duration": "PT1M10S",
        "dimension": "2d",
        "definition": "hd",
        "caption": "true",
        "licensedContent": true,
        "contentRating": {
          
        },
        "projection": "rectangular"
      },
      "statistics": {
        "viewCount": "7736429",
        "likeCount": "74276",
        "favoriteCount": "0",
        "commentCount": "1867"
      }
    },
    {
      "kind": "youtube#video",
      "etag": "Lu2Aq85I0eZFqm35WcEqftdtfqE",
      "id": "O0BaVz0e0_k",
      "snippet": {
        "publishedAt": "2023-10-19T16:58:03Z",
        "channelId": "UCyEnhHynhlQX-ReSHe7j3ow",
        "title": "PAK 🇵🇰 Fans Reaction on VIRAT KOHLI 100 🛑 | The Moment Kohli Score 100 vs BANGLADESH",
        "description": "Hello This is Waleed Rauf \nIn this Video you’ll see my analysis \nVirat Kohli 100\n\nMy Second Channel link\nhttps://youtube.com/channel/UCbCHvlm2kUhGfr211KXFjBw\n\nFollow me Instagram: https://instagram.com/chwaleedrauf\n\nFollow me on Facebook: https://www.facebook.com/chwaleedrauf/\n\nFollow me on Twitter: https://twitter.com/WaleedRauf20\n\nFollow me on TikTok: https://www.tiktok.com/@chwaleedrauf\n\nOther Channels ⬇️ \n•Nouman Rauf: https://youtube.com/@miannoumanrauf2851\n•Shameer: https://youtube.com/@ranashahmeerkhan\n•Rubina: https://youtube.com/@cookingwithrubinasheraz8283\n\nFor Urgent Contact:\nEmail me on\nbusinesswithwaleed28@gmail.com\n\nDisclaimer:\nThe video is made on fan base we are not intentionally targeting anyone if someone has any issue related to this video kindly dm us on Insta and email us your we’ll try to resolve the issue Asap! \n\n#viratkohli #pakistanireactions #iccworldcup2023",
        "thumbnails": {
          "default": {
            "url": "https://i.ytimg.com/vi/O0BaVz0e0_k/default.jpg",
            "width": 120,
            "height": 90
          },
          "medium": {
            "url": "https://i.ytimg.com/vi/O0BaVz0e0_k/mqdefault.jpg",
            "width": 320,
            "height": 180
          },
          "high": {
            "url": "https://i.ytimg.com/vi/O0BaVz0e0_k/hqdefault.jpg",
            "width": 480,
            "height": 360
          },
          "standard": {
            "url": "https://i.ytimg.com/vi/O0BaVz0e0_k/sddefault.jpg",
            "width": 640,
            "height": 480
          },
          "maxres": {
            "url": "https://i.ytimg.com/vi/O0BaVz0e0_k/maxresdefault.jpg",
            "width": 1280,
            "height": 720
          }
        },
        "channelTitle": "CH WALEED RAUF",
        "tags": [
          "Virat kohli 100",
          "The moment virat kohli scored 100",
          "Pakistan reaction on virat kohli 100",
          "Virat kohli batting vs Bangladesh",
          "Pakistan",
          "India vs Pakistan",
          "India vs Bangladesh match",
          "Virat kohli 100 Pakistan reaction",
          "Pak fans reaction on virat kohli 100",
          "Ind vs pak",
          "Ind vs ban Worldcup match",
          "Cricket",
          "Ch waleed rauf",
          "Waleed rauf latest video"
        ],
        "categoryId": "22",
        "liveBroadcastContent": "none",
        "localized": {
          "title": "PAK 🇵🇰 Fans Reaction on VIRAT KOHLI 100 🛑 | The Moment Kohli Score 100 vs BANGLADESH",
          "description": "Hello This is Waleed Rauf \nIn this Video you’ll see my analysis \nVirat Kohli 100\n\nMy Second Channel link\nhttps://youtube.com/channel/UCbCHvlm2kUhGfr211KXFjBw\n\nFollow me Instagram: https://instagram.com/chwaleedrauf\n\nFollow me on Facebook: https://www.facebook.com/chwaleedrauf/\n\nFollow me on Twitter: https://twitter.com/WaleedRauf20\n\nFollow me on TikTok: https://www.tiktok.com/@chwaleedrauf\n\nOther Channels ⬇️ \n•Nouman Rauf: https://youtube.com/@miannoumanrauf2851\n•Shameer: https://youtube.com/@ranashahmeerkhan\n•Rubina: https://youtube.com/@cookingwithrubinasheraz8283\n\nFor Urgent Contact:\nEmail me on\nbusinesswithwaleed28@gmail.com\n\nDisclaimer:\nThe video is made on fan base we are not intentionally targeting anyone if someone has any issue related to this video kindly dm us on Insta and email us your we’ll try to resolve the issue Asap! \n\n#viratkohli #pakistanireactions #iccworldcup2023"
        },
        "defaultAudioLanguage": "ur"
      },
      "contentDetails": {
        "duration": "PT3M21S",
        "dimension": "2d",
        "definition": "hd",
        "caption": "false",
        "licensedContent": true,
        "contentRating": {
          
        },
        "projection": "rectangular"
      },
      "statistics": {
        "viewCount": "247402",
        "likeCount": "14542",
        "favoriteCount": "0",
        "commentCount": "704"
      }
    },
    {
      "kind": "youtube#video",
      "etag": "Sk14i1GfroghQJzAXB6YUi-_8Ww",
      "id": "RbGQ70Vs6As",
      "snippet": {
        "publishedAt": "2023-10-20T06:26:00Z",
        "channelId": "UCvrhwpnp2DHYQ1CbXby9ypQ",
        "title": "Baakiyalakshmi | 20th & 21st October 2023 - Promo",
        "description": "பாக்கியலட்சுமி - திங்கள் முதல் சனி இரவு 8:30 மணிக்கு நம்ம விஜய் டிவில.. Click here https://www.hotstar.com/in/tv/baakiyalakshmi/s-2560 to watch the show on hotstar.        #Baakiyalakshmi #VijayTV #VijayTelevision #RedefiningEntertainment #StarVijayTV #StarVijay #TamilTV #Bhagyalakshmi",
        "thumbnails": {
          "default": {
            "url": "https://i.ytimg.com/vi/RbGQ70Vs6As/default.jpg",
            "width": 120,
            "height": 90
          },
          "medium": {
            "url": "https://i.ytimg.com/vi/RbGQ70Vs6As/mqdefault.jpg",
            "width": 320,
            "height": 180
          },
          "high": {
            "url": "https://i.ytimg.com/vi/RbGQ70Vs6As/hqdefault.jpg",
            "width": 480,
            "height": 360
          },
          "standard": {
            "url": "https://i.ytimg.com/vi/RbGQ70Vs6As/sddefault.jpg",
            "width": 640,
            "height": 480
          },
          "maxres": {
            "url": "https://i.ytimg.com/vi/RbGQ70Vs6As/maxresdefault.jpg",
            "width": 1280,
            "height": 720
          }
        },
        "channelTitle": "Vijay Television",
        "tags": [
          "Baakiyalakshmi",
          "New Fiction",
          "New Serial",
          "Fiction",
          "தமிழ்",
          "விஜய்",
          "டிவி",
          "தொலைக்காட்சி",
          "Vijay",
          "Star",
          "Vijay TV",
          "Star Vijay",
          "Star Vijay TV",
          "தொலைகாட்சி",
          "Tamil TV",
          "Tamil Shows"
        ],
        "categoryId": "24",
        "liveBroadcastContent": "none",
        "localized": {
          "title": "Baakiyalakshmi | 20th & 21st October 2023 - Promo",
          "description": "பாக்கியலட்சுமி - திங்கள் முதல் சனி இரவு 8:30 மணிக்கு நம்ம விஜய் டிவில.. Click here https://www.hotstar.com/in/tv/baakiyalakshmi/s-2560 to watch the show on hotstar.        #Baakiyalakshmi #VijayTV #VijayTelevision #RedefiningEntertainment #StarVijayTV #StarVijay #TamilTV #Bhagyalakshmi"
        },
        "defaultAudioLanguage": "en"
      },
      "contentDetails": {
        "duration": "PT41S",
        "dimension": "2d",
        "definition": "hd",
        "caption": "false",
        "licensedContent": true,
        "contentRating": {
          
        },
        "projection": "rectangular"
      },
      "statistics": {
        "viewCount": "1449381",
        "likeCount": "25056",
        "favoriteCount": "0",
        "commentCount": "523"
      }
    },
    {
      "kind": "youtube#video",
      "etag": "MSRfa5FYHyU8sA-yR0CCj12n5G0",
      "id": "jWUQ2A-LxNo",
      "snippet": {
        "publishedAt": "2023-10-19T06:30:16Z",
        "channelId": "UC4zWG9LccdWGUlF77LZ8toA",
        "title": "Aspirants Season 2 - Official Trailer | Prime Video India",
        "description": "Prime Video Presents \nAspirants Season 2 - Official Trailer\nDirected by Apoorv Singh Karki\nStarring Naveen Kasturia, Sunny Hinduja, Shivankit Singh Parihar, Abhilash Thapliyal, Namita Dubey\n\nRajinder Nagar to Rampur, the next journey of our Aspirants begin 🫰🏻\n#AspirantsOnPrime , new season 25th October!\n\nAbout:\nIt is the story of the journey of three UPSC Aspirants and their friendship against all odds.\n\nAbout Prime Video: Prime Video is a premium streaming service that offers Prime members a collection of award-winning Amazon Original series, thousands of movies & TV shows—all with the ease of finding what they love to watch in one place. Prime Video is just one of the many benefits of a Prime membership, available for just ₹1499/ year. \nIncluded with Prime Video: Thousands of acclaimed TV shows & movies across languages & geographies, including Indian films such as Shershaah, Soorarai Pottru, Sardar Udham, Gehraiyaan, Jai Bhim, Jalsa, Shakuntala Devi, Sherni, Narappa, Sarpatta Parambarai, Kuruthi, Joji, Malik, and HOME, along with Indian-produced Amazon Original series like Farzi, Jubilee, Dahaad, The Family Man, Mirzapur, Made in Heaven, Four More Shots Please!, Mumbai Diaries 26/11, Suzhal – The Vortex, Modern Love, Paatal Lok, Bandish Bandits, Guilty Minds, Cinema Marte Dum Tak, and Amazon Original movies like Maja Ma & Ammu. Also included are popular global Amazon Originals like Citadel, The Lord of The Rings: The Rings of Power, Reacher, Tom Clancy's Jack Ryan, The Boys, Hunters, Fleabag, The Marvelous Mrs. Maisel, & many more, available for unlimited streaming as part of a Prime membership. Prime Video includes content across Hindi, Marathi, Gujarati, Tamil, Telugu, Kannada, Malayalam, Punjabi, & Bengali. \nPrime Video Mobile Edition: Consumers can also enjoy Prime Video’s exclusive content library with Prime Video Mobile Edition at ₹599 per year. This single-user, mobile-only annual video plan offers everyone access to high-quality entertainment exclusively on their mobile devices. Users can sign-up for this plan via the Prime Video app (on Android) or website. \nInstant Access: Prime Members can watch anywhere, anytime on the Prime Video app for smart TVs, mobile devices, Fire TV, Fire TV stick, Fire tablets, Apple TV, & multiple gaming devices. Prime Video is also available to consumers through Airtel and Vodafone pre-paid & post-paid subscription plans. In the Prime Video app, Prime members can download episodes on their mobile devices & tablets & watch anywhere offline at no additional cost.\nEnhanced experiences: Make the most of every viewing with 4K Ultra HD- & High Dynamic Range (HDR)-compatible content. Go behind the scenes of your favourite movies & TV shows with exclusive X-Ray access, powered by IMDb. Save it for later with select mobile downloads for offline viewing. \nVideo Entertainment Marketplace: In addition to a Prime Video subscription, customers can also purchase add-on subscriptions to other streaming services, as well as, get rental access to movies on Prime Video. Prime Video Channels: Prime Video Channels offers friction-free & convenient access to a wide range of premium content from multiple video streaming services all available at a single destination – Prime Video website & apps. Prime Members can buy add-on subscriptions & enjoy a hassle-free entertainment experience, simplified discovery, frictionless payments, & more. Rent: Consumers can enjoy even more movies from new releases to classic favourites, available to rent – no Prime membership required. View titles available by visiting primevideo.com/store. The rental destination can be accessed via the STORE tab on primevideo.com & the Prime Video app on Android smart phones, smart-TVs, connected STBs, & Fire TV stick.",
        "thumbnails": {
          "default": {
            "url": "https://i.ytimg.com/vi/jWUQ2A-LxNo/default.jpg",
            "width": 120,
            "height": 90
          },
          "medium": {
            "url": "https://i.ytimg.com/vi/jWUQ2A-LxNo/mqdefault.jpg",
            "width": 320,
            "height": 180
          },
          "high": {
            "url": "https://i.ytimg.com/vi/jWUQ2A-LxNo/hqdefault.jpg",
            "width": 480,
            "height": 360
          },
          "standard": {
            "url": "https://i.ytimg.com/vi/jWUQ2A-LxNo/sddefault.jpg",
            "width": 640,
            "height": 480
          },
          "maxres": {
            "url": "https://i.ytimg.com/vi/jWUQ2A-LxNo/maxresdefault.jpg",
            "width": 1280,
            "height": 720
          }
        },
        "channelTitle": "Prime Video India",
        "tags": [
          "aspirants season 2",
          "aspirants season 2 kab aayega",
          "aspirants tvf season 2",
          "aspirants season 2 update",
          "aspirants season 2 tvf",
          "aspirants season 2 trailer tvf",
          "aspirants season 2 announcement",
          "aspirants season 2 episode 1",
          "aspirants season 2 will come or not",
          "aspirants web series season 2 release date",
          "aspirants season 2 shooting scene",
          "tvf aspirants season 2",
          "aspirants",
          "aspirants 2 release date",
          "aspirants 2 shooting",
          "aspirants 2",
          "tvf aspirants",
          "official trailer",
          "prime video",
          "new"
        ],
        "categoryId": "24",
        "liveBroadcastContent": "none",
        "localized": {
          "title": "Aspirants Season 2 - Official Trailer | Prime Video India",
          "description": "Prime Video Presents \nAspirants Season 2 - Official Trailer\nDirected by Apoorv Singh Karki\nStarring Naveen Kasturia, Sunny Hinduja, Shivankit Singh Parihar, Abhilash Thapliyal, Namita Dubey\n\nRajinder Nagar to Rampur, the next journey of our Aspirants begin 🫰🏻\n#AspirantsOnPrime , new season 25th October!\n\nAbout:\nIt is the story of the journey of three UPSC Aspirants and their friendship against all odds.\n\nAbout Prime Video: Prime Video is a premium streaming service that offers Prime members a collection of award-winning Amazon Original series, thousands of movies & TV shows—all with the ease of finding what they love to watch in one place. Prime Video is just one of the many benefits of a Prime membership, available for just ₹1499/ year. \nIncluded with Prime Video: Thousands of acclaimed TV shows & movies across languages & geographies, including Indian films such as Shershaah, Soorarai Pottru, Sardar Udham, Gehraiyaan, Jai Bhim, Jalsa, Shakuntala Devi, Sherni, Narappa, Sarpatta Parambarai, Kuruthi, Joji, Malik, and HOME, along with Indian-produced Amazon Original series like Farzi, Jubilee, Dahaad, The Family Man, Mirzapur, Made in Heaven, Four More Shots Please!, Mumbai Diaries 26/11, Suzhal – The Vortex, Modern Love, Paatal Lok, Bandish Bandits, Guilty Minds, Cinema Marte Dum Tak, and Amazon Original movies like Maja Ma & Ammu. Also included are popular global Amazon Originals like Citadel, The Lord of The Rings: The Rings of Power, Reacher, Tom Clancy's Jack Ryan, The Boys, Hunters, Fleabag, The Marvelous Mrs. Maisel, & many more, available for unlimited streaming as part of a Prime membership. Prime Video includes content across Hindi, Marathi, Gujarati, Tamil, Telugu, Kannada, Malayalam, Punjabi, & Bengali. \nPrime Video Mobile Edition: Consumers can also enjoy Prime Video’s exclusive content library with Prime Video Mobile Edition at ₹599 per year. This single-user, mobile-only annual video plan offers everyone access to high-quality entertainment exclusively on their mobile devices. Users can sign-up for this plan via the Prime Video app (on Android) or website. \nInstant Access: Prime Members can watch anywhere, anytime on the Prime Video app for smart TVs, mobile devices, Fire TV, Fire TV stick, Fire tablets, Apple TV, & multiple gaming devices. Prime Video is also available to consumers through Airtel and Vodafone pre-paid & post-paid subscription plans. In the Prime Video app, Prime members can download episodes on their mobile devices & tablets & watch anywhere offline at no additional cost.\nEnhanced experiences: Make the most of every viewing with 4K Ultra HD- & High Dynamic Range (HDR)-compatible content. Go behind the scenes of your favourite movies & TV shows with exclusive X-Ray access, powered by IMDb. Save it for later with select mobile downloads for offline viewing. \nVideo Entertainment Marketplace: In addition to a Prime Video subscription, customers can also purchase add-on subscriptions to other streaming services, as well as, get rental access to movies on Prime Video. Prime Video Channels: Prime Video Channels offers friction-free & convenient access to a wide range of premium content from multiple video streaming services all available at a single destination – Prime Video website & apps. Prime Members can buy add-on subscriptions & enjoy a hassle-free entertainment experience, simplified discovery, frictionless payments, & more. Rent: Consumers can enjoy even more movies from new releases to classic favourites, available to rent – no Prime membership required. View titles available by visiting primevideo.com/store. The rental destination can be accessed via the STORE tab on primevideo.com & the Prime Video app on Android smart phones, smart-TVs, connected STBs, & Fire TV stick."
        },
        "defaultAudioLanguage": "en"
      },
      "contentDetails": {
        "duration": "PT2M47S",
        "dimension": "2d",
        "definition": "hd",
        "caption": "true",
        "licensedContent": true,
        "contentRating": {
          
        },
        "projection": "rectangular"
      },
      "statistics": {
        "viewCount": "8898428",
        "likeCount": "94522",
        "favoriteCount": "0",
        "commentCount": "4097"
      }
    },
    {
      "kind": "youtube#video",
      "etag": "H7w1HDjdP9EUJYBWOup3Dzde_AU",
      "id": "9EEsbTllICY",
      "snippet": {
        "publishedAt": "2023-10-18T16:20:08Z",
        "channelId": "UC1EuA9aHCO81CRoJiAW5L2A",
        "title": "ମାଲ୍ୟଗିରି | Malyagiri | Official Trailer | Odia Movie | Babushaan | Amlan | Sivani | Suryamayee",
        "description": "#AmaraMuzikOdia #ମାଲ୍ୟଗିରି #Malyagiri #OdiaMovie #BabushaanMohanty #AmlanDas #MalyagiriTrailer \n\nEnter the jungle at your own risk. The lion and the tiger just got unleashed. Malyagiri stars Babushaan Mohanty, Amlan Das, Sivani Sangita and Suryamayee. Malyagiri is directed by Prithvi Raj Pattnaik and Produced by Rinku Rinu Jena.\nAmara Muzik is the official music label of Malyagiri.\n\nCredits \nMovie Name : Malyagiri \nStarring : Babushaan Mohanty, Amlan Das, Sivani Sangita and Suryamayee\nDirector : Prithvi Raj Pattnaik\nMusic : Gaurav Anand \nStory : Amit Kumar Das \nAssistant writer : kiran mishra\nMovie Background Score : Nabs and Saroj \nAdr Engineer : Chandra Sekhar Sharma\nAdr studio : Maestro audio lab\nKeys : Amit Mohapatra\nRhythm : Anil Das\nGuitar : Anup Garuda\nFlute : Rudra Prasad \nSolo violin : Jyoti prakash\nStrings section : Prasanna, Dilip, Jaga, Ashish, Chandan, Pintu & Debasis\nVocal - Gaurav\nRecording Studio : Somesh Studio\nGuitar : Anup Garuda\nViolin : Jyoti\nVocal : Gaurav Anand\nChoreographer : Amit Nayak\nDirector Of Photography : Rudrakanta Singh\nSound Design : Abhishek Tripathy\nEditor : Manas Kumar Sahoo\nEditing Studio : Pupul Films\nColorist: Biswajit Swain (Gugu)\nDI Studio: FilmX\nADR Engineer : Chandra Sekhar Sharma\nADR studio : Maestro Audio Lab\nRhythm programming : Anil Das\nMotion Gfx: Biswanath Padhi\nRe-recording and mixing : R.R Dash, Milan Studio\nFoley and Sound Design : Abhishek Tripathy\nProducer : Rinku Rinu Jena \nCO - Producer : Pranati Gochhayat, Niranjan Nayak and Babushaan Mohanty\nProduction House : Raindrop Pictures, Keeves Entertainment Tathya Production & Babushaan Films\nPresented by : Amara Studios\nMusic Label : Amara Muzik \nSpecial Thanks : Aparajita Mohanty \nChild Voice Over : Master Rudra \n\n🔔 Get alerts when we release any new video. TURN ON THE BELL ICON on the channel! 🔔\n\nSUBSCRIBE to Amara Muzik channel for Odia Songs and movie videos\nhttp://bit.ly/2am9M9E\n\nContact Us:\ninfo@amaramuzik.in\n\nConnect with us on \n♦ Facebook: https://www.facebook.com/AmaraMuzik\n♦ Instagram: https://www.instagram.com/amaramuzik\n♦ Twitter: https://twitter.com/AmaraMuzik​\n\n© Amara Muzik 2023\n\n* ANTI-PIRACY WARNING *\nThis content is Copyright to Amara Muzik. Any unauthorized reproduction, redistribution or re-upload is strictly prohibited of this material. Legal action will be taken against those who violate the copyright of the following material presented!\n\nAmara Odisha | Amara Odia | Odia | Odia Movie | Ollywood | Odisha | Amara Muzik Odia | Amara Muzik | Odia Film | ମାଲ୍ୟଗିରି | Malyagiri | Odia Movie Malyagiri | Malyagiri Odia Movie | Malyagiri Babushaan Mohanty | Babushaan Mohanty New Movie | Amlan Das New Movie | Sivani Sangita New Movie | Babushaan Mohanty Odia Movie | Malyagiri New Odia Movie | Malyagiri Trailer | Odia Movie Trailer | Babushaan Mohanty | Malyagiri Teaser | Malaygiri Official Teaser | Lion Vs Tiger | Odia Movie Trailer",
        "thumbnails": {
          "default": {
            "url": "https://i.ytimg.com/vi/9EEsbTllICY/default.jpg",
            "width": 120,
            "height": 90
          },
          "medium": {
            "url": "https://i.ytimg.com/vi/9EEsbTllICY/mqdefault.jpg",
            "width": 320,
            "height": 180
          },
          "high": {
            "url": "https://i.ytimg.com/vi/9EEsbTllICY/hqdefault.jpg",
            "width": 480,
            "height": 360
          },
          "standard": {
            "url": "https://i.ytimg.com/vi/9EEsbTllICY/sddefault.jpg",
            "width": 640,
            "height": 480
          },
          "maxres": {
            "url": "https://i.ytimg.com/vi/9EEsbTllICY/maxresdefault.jpg",
            "width": 1280,
            "height": 720
          }
        },
        "channelTitle": "Amara Muzik Odia",
        "tags": [
          "Amara Muzik",
          "odia music",
          "amara music",
          "odia song 2023",
          "amara odia",
          "Amara Odisha",
          "ମାଲ୍ୟଗିରି",
          "Malyagiri odia movie",
          "Malyagiri movie",
          "odia movie malyagiri",
          "malyagiri babushaan mohanty",
          "malyagiri trailer",
          "new odia movie malyagiri",
          "Malyagiri odia film",
          "malyagiri",
          "babushan mohanty upcoming movie",
          "malyagiri official trailer",
          "malyagiri odia movie trailer",
          "odia movie trailer",
          "odia movie malyagiri trailer",
          "latest odia movie malyagiri",
          "malyagiri odia movie",
          "malyagiri movie"
        ],
        "categoryId": "10",
        "liveBroadcastContent": "none",
        "defaultLanguage": "en",
        "localized": {
          "title": "ମାଲ୍ୟଗିରି | Malyagiri | Official Trailer | Odia Movie | Babushaan | Amlan | Sivani | Suryamayee",
          "description": "#AmaraMuzikOdia #ମାଲ୍ୟଗିରି #Malyagiri #OdiaMovie #BabushaanMohanty #AmlanDas #MalyagiriTrailer \n\nEnter the jungle at your own risk. The lion and the tiger just got unleashed. Malyagiri stars Babushaan Mohanty, Amlan Das, Sivani Sangita and Suryamayee. Malyagiri is directed by Prithvi Raj Pattnaik and Produced by Rinku Rinu Jena.\nAmara Muzik is the official music label of Malyagiri.\n\nCredits \nMovie Name : Malyagiri \nStarring : Babushaan Mohanty, Amlan Das, Sivani Sangita and Suryamayee\nDirector : Prithvi Raj Pattnaik\nMusic : Gaurav Anand \nStory : Amit Kumar Das \nAssistant writer : kiran mishra\nMovie Background Score : Nabs and Saroj \nAdr Engineer : Chandra Sekhar Sharma\nAdr studio : Maestro audio lab\nKeys : Amit Mohapatra\nRhythm : Anil Das\nGuitar : Anup Garuda\nFlute : Rudra Prasad \nSolo violin : Jyoti prakash\nStrings section : Prasanna, Dilip, Jaga, Ashish, Chandan, Pintu & Debasis\nVocal - Gaurav\nRecording Studio : Somesh Studio\nGuitar : Anup Garuda\nViolin : Jyoti\nVocal : Gaurav Anand\nChoreographer : Amit Nayak\nDirector Of Photography : Rudrakanta Singh\nSound Design : Abhishek Tripathy\nEditor : Manas Kumar Sahoo\nEditing Studio : Pupul Films\nColorist: Biswajit Swain (Gugu)\nDI Studio: FilmX\nADR Engineer : Chandra Sekhar Sharma\nADR studio : Maestro Audio Lab\nRhythm programming : Anil Das\nMotion Gfx: Biswanath Padhi\nRe-recording and mixing : R.R Dash, Milan Studio\nFoley and Sound Design : Abhishek Tripathy\nProducer : Rinku Rinu Jena \nCO - Producer : Pranati Gochhayat, Niranjan Nayak and Babushaan Mohanty\nProduction House : Raindrop Pictures, Keeves Entertainment Tathya Production & Babushaan Films\nPresented by : Amara Studios\nMusic Label : Amara Muzik \nSpecial Thanks : Aparajita Mohanty \nChild Voice Over : Master Rudra \n\n🔔 Get alerts when we release any new video. TURN ON THE BELL ICON on the channel! 🔔\n\nSUBSCRIBE to Amara Muzik channel for Odia Songs and movie videos\nhttp://bit.ly/2am9M9E\n\nContact Us:\ninfo@amaramuzik.in\n\nConnect with us on \n♦ Facebook: https://www.facebook.com/AmaraMuzik\n♦ Instagram: https://www.instagram.com/amaramuzik\n♦ Twitter: https://twitter.com/AmaraMuzik​\n\n© Amara Muzik 2023\n\n* ANTI-PIRACY WARNING *\nThis content is Copyright to Amara Muzik. Any unauthorized reproduction, redistribution or re-upload is strictly prohibited of this material. Legal action will be taken against those who violate the copyright of the following material presented!\n\nAmara Odisha | Amara Odia | Odia | Odia Movie | Ollywood | Odisha | Amara Muzik Odia | Amara Muzik | Odia Film | ମାଲ୍ୟଗିରି | Malyagiri | Odia Movie Malyagiri | Malyagiri Odia Movie | Malyagiri Babushaan Mohanty | Babushaan Mohanty New Movie | Amlan Das New Movie | Sivani Sangita New Movie | Babushaan Mohanty Odia Movie | Malyagiri New Odia Movie | Malyagiri Trailer | Odia Movie Trailer | Babushaan Mohanty | Malyagiri Teaser | Malaygiri Official Teaser | Lion Vs Tiger | Odia Movie Trailer"
        },
        "defaultAudioLanguage": "or"
      },
      "contentDetails": {
        "duration": "PT2M57S",
        "dimension": "2d",
        "definition": "hd",
        "caption": "true",
        "licensedContent": true,
        "contentRating": {
          
        },
        "projection": "rectangular"
      },
      "statistics": {
        "viewCount": "538941",
        "likeCount": "40431",
        "favoriteCount": "0",
        "commentCount": "3355"
      }
    },
    {
      "kind": "youtube#video",
      "etag": "6R3MS-ZARh9GwNmv7vEkPkC0hDM",
      "id": "Yn6bkToLhJ8",
      "snippet": {
        "publishedAt": "2023-10-19T01:38:00Z",
        "channelId": "UCFZqtti2VoNdgeLklh48Liw",
        "title": "LEO MOVIE REVIEW FDFS | LEO MOVIE THEATRE RESPONSE KERALA | MALAYALAM | VIJAY | VARIETY MEDIA",
        "description": "LEO MOVIE REVIEW FDFS| LEO MOVIE THEATRE RESPONSE KERALA | MALAYALAM | VARIETY MEDIA\n\nLEO REVIEW VIJAY\nLEO REVIEW KERALA\nLEO MOVIE THEATRE RESPONSE\nLEO MOVIE THETRE REVIEW\nLeo movie\nLeo movie review\nLeo movie theatre response\nLeo movie vijay\nLeo Vijay entry\nLeo malayalam review\nLeo kerala review\nLeo tamil review\nVijay fans kerala\nVijay fans tamilnadu\nVijay fans latest\nVijay fans kollam\nKollam nanbans\nKollam nanbans review\nLeo trailer\nLeo song\nLeo fight\nVijay latest moie\nLeo fdfs\nLokesh kanagarajan\nLokesh kanagarajan interview\nLeo updates\nLeo variety media review\nLeo variety media updates\n\n#LEO #Review #fdfs #kerala",
        "thumbnails": {
          "default": {
            "url": "https://i.ytimg.com/vi/Yn6bkToLhJ8/default.jpg",
            "width": 120,
            "height": 90
          },
          "medium": {
            "url": "https://i.ytimg.com/vi/Yn6bkToLhJ8/mqdefault.jpg",
            "width": 320,
            "height": 180
          },
          "high": {
            "url": "https://i.ytimg.com/vi/Yn6bkToLhJ8/hqdefault.jpg",
            "width": 480,
            "height": 360
          },
          "standard": {
            "url": "https://i.ytimg.com/vi/Yn6bkToLhJ8/sddefault.jpg",
            "width": 640,
            "height": 480
          },
          "maxres": {
            "url": "https://i.ytimg.com/vi/Yn6bkToLhJ8/maxresdefault.jpg",
            "width": 1280,
            "height": 720
          }
        },
        "channelTitle": "Variety Media",
        "tags": [
          "Leo movie",
          "Leo movie theatre response",
          "Leo movie review",
          "Leo Vijay entry",
          "Leo movie vijay",
          "Leo malayalam review",
          "Vijay fans kerala",
          "Leo kerala review",
          "Leo tamil review",
          "Vijay fans latest",
          "Vijay fans tamilnadu",
          "Vijay fans kollam",
          "Leo updates",
          "Lokesh kanagarajan",
          "Leo fdfs",
          "Vijay latest movie",
          "Leo fight",
          "Leo variety media updates",
          "Leo variety media review",
          "Kollam nanbans",
          "Kollam nanbans review",
          "leo vijay dance"
        ],
        "categoryId": "24",
        "liveBroadcastContent": "none",
        "localized": {
          "title": "LEO MOVIE REVIEW FDFS | LEO MOVIE THEATRE RESPONSE KERALA | MALAYALAM | VIJAY | VARIETY MEDIA",
          "description": "LEO MOVIE REVIEW FDFS| LEO MOVIE THEATRE RESPONSE KERALA | MALAYALAM | VARIETY MEDIA\n\nLEO REVIEW VIJAY\nLEO REVIEW KERALA\nLEO MOVIE THEATRE RESPONSE\nLEO MOVIE THETRE REVIEW\nLeo movie\nLeo movie review\nLeo movie theatre response\nLeo movie vijay\nLeo Vijay entry\nLeo malayalam review\nLeo kerala review\nLeo tamil review\nVijay fans kerala\nVijay fans tamilnadu\nVijay fans latest\nVijay fans kollam\nKollam nanbans\nKollam nanbans review\nLeo trailer\nLeo song\nLeo fight\nVijay latest moie\nLeo fdfs\nLokesh kanagarajan\nLokesh kanagarajan interview\nLeo updates\nLeo variety media review\nLeo variety media updates\n\n#LEO #Review #fdfs #kerala"
        }
      },
      "contentDetails": {
        "duration": "PT5M31S",
        "dimension": "2d",
        "definition": "hd",
        "caption": "false",
        "licensedContent": true,
        "contentRating": {
          
        },
        "projection": "rectangular"
      },
      "statistics": {
        "viewCount": "896986",
        "likeCount": "38158",
        "favoriteCount": "0",
        "commentCount": "1551"
      }
    },
    {
      "kind": "youtube#video",
      "etag": "wFuY0hCUL6lUJ0zYQ3FcKXsj9v0",
      "id": "4v3jie85wTI",
      "snippet": {
        "publishedAt": "2023-10-19T09:41:19Z",
        "channelId": "UC1lj6vxt1OEFZ4icxmBBJKA",
        "title": "Santhwanam Serial സംവിധായകനെ അവസാനമായി കണ്ട് വിങ്ങിപ്പൊട്ടി സീരിയൽ താരങ്ങൾ 😪  Adithyan News",
        "description": "Santhwanam serial director adithyan\nActress Chippy\nMridula Vijay\nSanthwanam latest episode\nSanthwanam actors\nSanthwanam devi\nSanthwanam appu \n\n#Santhwanam #chippy #adithyan\n\nMridula vijay\nYuva krishna\nSeema\nRajeev parameswaran\nSajin\nRaksha raju\nAchu sugath\n\n\nDevi\nAppu\nHari\nShivan",
        "thumbnails": {
          "default": {
            "url": "https://i.ytimg.com/vi/4v3jie85wTI/default.jpg",
            "width": 120,
            "height": 90
          },
          "medium": {
            "url": "https://i.ytimg.com/vi/4v3jie85wTI/mqdefault.jpg",
            "width": 320,
            "height": 180
          },
          "high": {
            "url": "https://i.ytimg.com/vi/4v3jie85wTI/hqdefault.jpg",
            "width": 480,
            "height": 360
          },
          "standard": {
            "url": "https://i.ytimg.com/vi/4v3jie85wTI/sddefault.jpg",
            "width": 640,
            "height": 480
          },
          "maxres": {
            "url": "https://i.ytimg.com/vi/4v3jie85wTI/maxresdefault.jpg",
            "width": 1280,
            "height": 720
          }
        },
        "channelTitle": "Variety Media Live",
        "tags": [
          "swanthanam serial",
          "chippy swanthanam",
          "aparna swanthanam",
          "hari swanthanam serial",
          "swanthanam serial asianet",
          "swanthanam serial promo",
          "swanthanam today",
          "swanthanam tomorrow promo",
          "swanthanam director adhithyan",
          "swanthanam director"
        ],
        "categoryId": "24",
        "liveBroadcastContent": "none",
        "localized": {
          "title": "Santhwanam Serial സംവിധായകനെ അവസാനമായി കണ്ട് വിങ്ങിപ്പൊട്ടി സീരിയൽ താരങ്ങൾ 😪  Adithyan News",
          "description": "Santhwanam serial director adithyan\nActress Chippy\nMridula Vijay\nSanthwanam latest episode\nSanthwanam actors\nSanthwanam devi\nSanthwanam appu \n\n#Santhwanam #chippy #adithyan\n\nMridula vijay\nYuva krishna\nSeema\nRajeev parameswaran\nSajin\nRaksha raju\nAchu sugath\n\n\nDevi\nAppu\nHari\nShivan"
        }
      },
      "contentDetails": {
        "duration": "PT6M",
        "dimension": "2d",
        "definition": "hd",
        "caption": "false",
        "licensedContent": true,
        "contentRating": {
          
        },
        "projection": "rectangular"
      },
      "statistics": {
        "viewCount": "346162",
        "likeCount": "1906",
        "favoriteCount": "0",
        "commentCount": "74"
      }
    },
    {
      "kind": "youtube#video",
      "etag": "1vkeYengflt_itc16TD8093XN0k",
      "id": "sFlRVNxv4PE",
      "snippet": {
        "publishedAt": "2023-10-19T10:50:07Z",
        "channelId": "UCeiAKuJGZrIjYvaq0nMwbJg",
        "title": "Leo Movie REVIEW | Deeksha Sharma",
        "description": "Leo Movie Review In Hindi By Deeksha Sharma. Leo Featuring Thalapathy Vijay Directed by Lokesh Kanagaraj is the Best Mass with Class Action Suspense Story Telling Experience with a Secret Connection with LCU Lokesh Cinematic Universe which will challenge Marvel & Dc from Hollywood with Solid Fan Following! Leo Full Movie Hindi Dubbed Story Outline Explained & Positives Negatives would be shared in this Video. Leo vs Tiger Shroff Ganapath - Who will score big at Box Office? Do leave your Public Review in the Comments Section.\n\n\n➤ Follow Me on Instagram-\n     https://www.instagram.com/thefilmiindian\n\n➤ Follow Me on Twitter-\n     https://twitter.com/thefilmiindian\n\n#Leo #LeoReview #LeoMovie",
        "thumbnails": {
          "default": {
            "url": "https://i.ytimg.com/vi/sFlRVNxv4PE/default.jpg",
            "width": 120,
            "height": 90
          },
          "medium": {
            "url": "https://i.ytimg.com/vi/sFlRVNxv4PE/mqdefault.jpg",
            "width": 320,
            "height": 180
          },
          "high": {
            "url": "https://i.ytimg.com/vi/sFlRVNxv4PE/hqdefault.jpg",
            "width": 480,
            "height": 360
          },
          "standard": {
            "url": "https://i.ytimg.com/vi/sFlRVNxv4PE/sddefault.jpg",
            "width": 640,
            "height": 480
          },
          "maxres": {
            "url": "https://i.ytimg.com/vi/sFlRVNxv4PE/maxresdefault.jpg",
            "width": 1280,
            "height": 720
          }
        },
        "channelTitle": "Filmi Indian",
        "tags": [
          "leo",
          "leo review",
          "leo movie",
          "leo trailer",
          "hindi",
          "leo full movie",
          "leo movie review",
          "Thalapathy Vijay",
          "Lokesh Kanagaraj",
          "movie",
          "trailer",
          "review",
          "reaction",
          "lcu",
          "lokesh cinematic universe",
          "vikram",
          "hindi dubbed",
          "full movie",
          "tiger shroff",
          "ganapath",
          "movie review",
          "filmi indian",
          "leo hindi dubbed",
          "leo songs",
          "Sun TV",
          "Goldmines",
          "leo hindi",
          "leo hindi review"
        ],
        "categoryId": "24",
        "liveBroadcastContent": "none",
        "localized": {
          "title": "Leo Movie REVIEW | Deeksha Sharma",
          "description": "Leo Movie Review In Hindi By Deeksha Sharma. Leo Featuring Thalapathy Vijay Directed by Lokesh Kanagaraj is the Best Mass with Class Action Suspense Story Telling Experience with a Secret Connection with LCU Lokesh Cinematic Universe which will challenge Marvel & Dc from Hollywood with Solid Fan Following! Leo Full Movie Hindi Dubbed Story Outline Explained & Positives Negatives would be shared in this Video. Leo vs Tiger Shroff Ganapath - Who will score big at Box Office? Do leave your Public Review in the Comments Section.\n\n\n➤ Follow Me on Instagram-\n     https://www.instagram.com/thefilmiindian\n\n➤ Follow Me on Twitter-\n     https://twitter.com/thefilmiindian\n\n#Leo #LeoReview #LeoMovie"
        }
      },
      "contentDetails": {
        "duration": "PT5M42S",
        "dimension": "2d",
        "definition": "hd",
        "caption": "false",
        "licensedContent": true,
        "contentRating": {
          
        },
        "projection": "rectangular"
      },
      "statistics": {
        "viewCount": "816884",
        "likeCount": "47328",
        "favoriteCount": "0",
        "commentCount": "3401"
      }
    },
    {
      "kind": "youtube#video",
      "etag": "8Y6iv7ylABLkS63vxXkoWyjs2MA",
      "id": "nefPHHlt2TA",
      "snippet": {
        "publishedAt": "2023-10-20T04:00:32Z",
        "channelId": "UCppHT7SZKKvar4Oc9J4oljQ",
        "title": "Kundali Bhagya | Ep 1677 | Preview | Oct, 20 2023 | Shakti, Shraddha | Zee TV",
        "description": "Watch Full Episode click here ►\nhttps://zee5.onelink.me/RlQq/51595e1e\nClick Here to Subscribe Channel : https://bit.ly/SubscribetoZeetv \nGet notified about our Latest update by Clicking the Bell Icon 🔔\n\nKaran marries Preeta out of spite owing to a misunderstanding. Preeta tries to clear the air and wins him over whilst dealing with Sherlyn, Prithvi, and Mahira, a trio that becomes a thorn in her side.\n\nTo Free Download ZEE5 Mobile app click the link below\nhttps://zee5.onelink.me/RlQq/be0f8316\n\nConnect with Zee TV on Social Media\nFacebook - http://bit.ly/ZeeTvFB\nInstagram - http://bit.ly/ZeeTvInsta\nTwitter  - http://bit.ly/ZeeTVtwitter\n\nConnect with Zee5 on Social Media\nFacebook : http://bit.ly/Zee5FB\nInstagram : http://bit.ly/Zee5HindiInsta\nTwitter : http://bit.ly/Zee5twitter",
        "thumbnails": {
          "default": {
            "url": "https://i.ytimg.com/vi/nefPHHlt2TA/default.jpg",
            "width": 120,
            "height": 90
          },
          "medium": {
            "url": "https://i.ytimg.com/vi/nefPHHlt2TA/mqdefault.jpg",
            "width": 320,
            "height": 180
          },
          "high": {
            "url": "https://i.ytimg.com/vi/nefPHHlt2TA/hqdefault.jpg",
            "width": 480,
            "height": 360
          },
          "standard": {
            "url": "https://i.ytimg.com/vi/nefPHHlt2TA/sddefault.jpg",
            "width": 640,
            "height": 480
          },
          "maxres": {
            "url": "https://i.ytimg.com/vi/nefPHHlt2TA/maxresdefault.jpg",
            "width": 1280,
            "height": 720
          }
        },
        "channelTitle": "Zee TV",
        "tags": [
          "Kundali Bhagya",
          "Shraddha Arya",
          "Dheeraj Dhoopar",
          "Shakti Arora",
          "Anjum Fakih",
          "Zee TV",
          "ज़ी टीवी",
          "हिन्दी चैनल",
          "Hindi GEC TV channel",
          "hindi tv serial",
          "zeetv",
          "hindi serial",
          "show",
          "entertainment",
          "daily soaps",
          "family",
          "drama",
          "comedy",
          "horror",
          "thriller",
          "romance",
          "romantic",
          "hindi",
          "free",
          "download",
          "mobile",
          "story",
          "episode",
          "latest",
          "scene",
          "full episode",
          "best scene",
          "webisode",
          "precap",
          "preview",
          "promo",
          "complete series",
          "video",
          "youtube",
          "tv",
          "zee popular shows",
          "zee5"
        ],
        "categoryId": "24",
        "liveBroadcastContent": "none",
        "defaultLanguage": "en",
        "localized": {
          "title": "Kundali Bhagya | Ep 1677 | Preview | Oct, 20 2023 | Shakti, Shraddha | Zee TV",
          "description": "Watch Full Episode click here ►\nhttps://zee5.onelink.me/RlQq/51595e1e\nClick Here to Subscribe Channel : https://bit.ly/SubscribetoZeetv \nGet notified about our Latest update by Clicking the Bell Icon 🔔\n\nKaran marries Preeta out of spite owing to a misunderstanding. Preeta tries to clear the air and wins him over whilst dealing with Sherlyn, Prithvi, and Mahira, a trio that becomes a thorn in her side.\n\nTo Free Download ZEE5 Mobile app click the link below\nhttps://zee5.onelink.me/RlQq/be0f8316\n\nConnect with Zee TV on Social Media\nFacebook - http://bit.ly/ZeeTvFB\nInstagram - http://bit.ly/ZeeTvInsta\nTwitter  - http://bit.ly/ZeeTVtwitter\n\nConnect with Zee5 on Social Media\nFacebook : http://bit.ly/Zee5FB\nInstagram : http://bit.ly/Zee5HindiInsta\nTwitter : http://bit.ly/Zee5twitter"
        },
        "defaultAudioLanguage": "hi"
      },
      "contentDetails": {
        "duration": "PT36S",
        "dimension": "2d",
        "definition": "hd",
        "caption": "false",
        "licensedContent": true,
        "contentRating": {
          
        },
        "projection": "rectangular"
      },
      "statistics": {
        "viewCount": "670548",
        "likeCount": "7428",
        "favoriteCount": "0",
        "commentCount": "37"
      }
    },
    {
      "kind": "youtube#video",
      "etag": "jf5oBwpmjSxt5HB97jsLUQwxcSg",
      "id": "GX3qvFwwjFE",
      "snippet": {
        "publishedAt": "2023-10-19T10:03:30Z",
        "channelId": "UClF9UTljviumfJf7t-VR5tg",
        "title": "Leo Movie Review | Leo Review by Filmi craft Arun | Vijay | Trisha | Lokesh Kanagaraj",
        "description": "#LeoReview\n#LeoMovieReview\n#Leo\n#LeoFDFS\n#LeoReaction\n#LeOLCU\n#Leo\n#லியோவிமர்சனம்\n#லியோரிவியூ\n#லியோ\n#LeoBloodySweet\n\nGarden Snacks,\n67/26, Varathan street, Gobichettipalayam, Erode district - 638452\nEmail ID - sales@gardensnacks.in\nContact Phone and Whats app No.- +919865859086\nOrder Booking Link - https://gardensnacks.in\nDiscount Code - FILMICRAFT20\n\n\n\nLeo – Bloody Sweet is a 2023 Indian Tamil-language gangster film written and directed by Lokesh Kanagaraj, who co-wrote the script with Rathna Kumar and Deeraj Vaidy.It is produced by S. S. Lalit Kumar, under Seven Screen Studio, and co-produced by Jagadish Palanisamy. It stars Vijay and Trisha, along with an ensemble cast of Sanjay Dutt, Arjun Sarja, Priya Anand, Mansoor Ali Khan, Mysskin and Gautham Vasudev Menon.\n\nTo support our Channel        -       Click \"Join\" Button near \"Subscribe\" Button to become a Member of Filmi craft Family, if you wish. \nTo know more about \"Join Button\", pls. click the following link - https://youtu.be/nlRf0wpQcnQ.\n\nSubscribe our New channel \"Filmi Craft Corner\" for interesting and infotainment videos using the link - https://youtube.com/channel/UCYwZ32wCr7grmXst_-3pBZA\n\nContact me at : myfilmicraft@gmail.com\n\nOn Facebook  -   https://www.facebook.com/filmi.craft.7\n\nOn Twitter  -  https://twitter.com/filmicraft\n\nOn Instagram -   https://www.instagram.com/filmicraft/\n\nTo download Movie Subtitles, pls. refer the video - https://youtu.be/j06Ug59ajO4",
        "thumbnails": {
          "default": {
            "url": "https://i.ytimg.com/vi/GX3qvFwwjFE/default.jpg",
            "width": 120,
            "height": 90
          },
          "medium": {
            "url": "https://i.ytimg.com/vi/GX3qvFwwjFE/mqdefault.jpg",
            "width": 320,
            "height": 180
          },
          "high": {
            "url": "https://i.ytimg.com/vi/GX3qvFwwjFE/hqdefault.jpg",
            "width": 480,
            "height": 360
          },
          "standard": {
            "url": "https://i.ytimg.com/vi/GX3qvFwwjFE/sddefault.jpg",
            "width": 640,
            "height": 480
          },
          "maxres": {
            "url": "https://i.ytimg.com/vi/GX3qvFwwjFE/maxresdefault.jpg",
            "width": 1280,
            "height": 720
          }
        },
        "channelTitle": "Filmi craft",
        "tags": [
          "Leo review",
          "Leo movie review",
          "Leo review tamil",
          "Leo tamil review",
          "Leo tamil movie",
          "Leo movie tamil meme review",
          "Leo movie review tamil",
          "Leo 2023 tamil movie review",
          "Leo public review tamil",
          "Leo audience review tamil",
          "Leo",
          "Leo theatre celebration",
          "Leo full movie",
          "லியோ விமர்சனம்",
          "லியோ ரிவியூ",
          "லியோ",
          "Vijay",
          "Trisha",
          "Leo Lcu",
          "Leo remake",
          "lokesh kanagaraj"
        ],
        "categoryId": "24",
        "liveBroadcastContent": "none",
        "defaultLanguage": "en",
        "localized": {
          "title": "Leo Movie Review | Leo Review by Filmi craft Arun | Vijay | Trisha | Lokesh Kanagaraj",
          "description": "#LeoReview\n#LeoMovieReview\n#Leo\n#LeoFDFS\n#LeoReaction\n#LeOLCU\n#Leo\n#லியோவிமர்சனம்\n#லியோரிவியூ\n#லியோ\n#LeoBloodySweet\n\nGarden Snacks,\n67/26, Varathan street, Gobichettipalayam, Erode district - 638452\nEmail ID - sales@gardensnacks.in\nContact Phone and Whats app No.- +919865859086\nOrder Booking Link - https://gardensnacks.in\nDiscount Code - FILMICRAFT20\n\n\n\nLeo – Bloody Sweet is a 2023 Indian Tamil-language gangster film written and directed by Lokesh Kanagaraj, who co-wrote the script with Rathna Kumar and Deeraj Vaidy.It is produced by S. S. Lalit Kumar, under Seven Screen Studio, and co-produced by Jagadish Palanisamy. It stars Vijay and Trisha, along with an ensemble cast of Sanjay Dutt, Arjun Sarja, Priya Anand, Mansoor Ali Khan, Mysskin and Gautham Vasudev Menon.\n\nTo support our Channel        -       Click \"Join\" Button near \"Subscribe\" Button to become a Member of Filmi craft Family, if you wish. \nTo know more about \"Join Button\", pls. click the following link - https://youtu.be/nlRf0wpQcnQ.\n\nSubscribe our New channel \"Filmi Craft Corner\" for interesting and infotainment videos using the link - https://youtube.com/channel/UCYwZ32wCr7grmXst_-3pBZA\n\nContact me at : myfilmicraft@gmail.com\n\nOn Facebook  -   https://www.facebook.com/filmi.craft.7\n\nOn Twitter  -  https://twitter.com/filmicraft\n\nOn Instagram -   https://www.instagram.com/filmicraft/\n\nTo download Movie Subtitles, pls. refer the video - https://youtu.be/j06Ug59ajO4"
        },
        "defaultAudioLanguage": "ta"
      },
      "contentDetails": {
        "duration": "PT12M2S",
        "dimension": "2d",
        "definition": "hd",
        "caption": "false",
        "licensedContent": true,
        "contentRating": {
          
        },
        "projection": "rectangular"
      },
      "statistics": {
        "viewCount": "191932",
        "likeCount": "9290",
        "favoriteCount": "0",
        "commentCount": "1700"
      }
    },
    {
      "kind": "youtube#video",
      "etag": "F6CLXtzksmdG0GzUrhWDd3cGGew",
      "id": "OKzvVmX7naI",
      "snippet": {
        "publishedAt": "2023-10-17T08:00:08Z",
        "channelId": "UC_vcKmg67vjMP7ciLnSxSHQ",
        "title": "SSC | EP 02: मुखर्जी नगर | Amit Bhadana",
        "description": "Watch Episode 01- https://youtu.be/AlAJ3Ykst7E?si=ph-KCKhEg5qwpuur\n\nDownload Adda247 App:  https://adda247.app.link/Amit_Bhadana_E2\n\nAdda247, India's largest vernacular Exam preparation company founded in 2010. Adda247 provides well curated course content & teaching by top faculties of industry for all types of Exam preparations, i.e., Govt jobs, IIT, Medical, State Exams, etc.\n\nRate Us On IMDB: https://www.imdb.com/title/tt29424187/\n\nKisi bhi ladai mein insaan ki aadhi jeet tabhi ho jati hai jab vo ladne ki himmat juta le. Student Shiv ko uske papa ne ghar se nikaal diya hai aur ab vo aa gaya hai Mukherjee Nagar ke warzone mein, jahan sapne bante bhi hai aur bigadte bhi. Dosari taraf SSC sir ke best teacher ko Khanna hijack kar leta hai aur us par ilzaam bhi lagata hai. Nayi nayi problems sar utha rahi hain lekin hope ki ungali thame Shiv aur SSC badh rahe hain kadam dar kadam.\n\nCreated And Directed By - Amit Bhadana\nWritten By - Amit Bhadana, Adheesh Verma, Swapnil Narendra \nCo Director - Vishal Kumar \nDirector Of Photography - Arvind Yadav \nCreative Director - Dhruv Behl\nEditor - Mohd Firoj Aalam\nMusic Director - Lovepreet Singh\nHead Of Production - Avinash Choudhary \nExecutive Producer - Avinash Choudhary \nProduction House - Mavericks Film Productions \nLine Producer - Mandeep Verma\n\nDirecton Team \n\n1st AD - Rishabh Bhagat \n2nd AD - Sanskriti Singh\n2nd 2nd AD - Yashita Verma\n3rd AD - Dev Verma \nScript Supervisor - Saurabh Kumar \nIntern AD - Chandan Paswan \nIntern AD - Riddhi Sharma\n\nProduction Team \n\nAssociate Line Producer - Amit Pradhan \nAssociate Line Producer - Anupam Sharma \nProduction Controller - Sahil Pal\nProduction Manager - Harsh Sharma\nProduction Team - Kanika Krishnanni , Monu Ali , Bhoomi Khandelwal, Shubham Senger, Tushar\n\nLocation Manager\n\nGreater Noida - Avdesh Yadav\nU.P. Mukherjee Nagar , Delhi - Amit Dedha & Team \n\nFood - Kuldeep Gupta \nTransportation Support - JS Travel\nSpot Team - Radhe & Team\nFacilities - Mavericksfilmproductions\n\nCamera and Electrical Department\n\n2nd Dop - Sachin Gupta, Don Jordz,Priyanshu Vats\n1st Ac - Deepanshu Sharma \n1st Focus Puller - Chandan Singh\n2nd Focus Puller - Anshul ,Mahesh Kumar, Sumit\nIntern - Himanshi Bansal\nGaffer -  Gaurav\nLighting Incharge - Satya\nElectrician - Rajesh\nCamera - Ekta Vision\nStedicam - Ankit Sharma\nDolly - Montu and Team , Nitesh Kumar\nDrone -  Anil\nCamera Attendant - Praphull Kumar, Nitesh Kumar,Vishal Kumar,Jitendra Kumar\n\nCasting Director - Sanjay Wadhwa (Citric Media House)\nCasting Director - Aarti Sharma (Citric Media House) \nJunior Artist Coordinator - Rahul\n\nArt Direction Team\n\nArt Director -  Abdul Fayyaz \nAssistant Art Director - Amaan Alam \nSet Dresser - Sneha \nProp Master - Saurabh \nForward Art - Sharukh\nCarpenter - Salman\nSetting Boy 1 - Nitin\nSetting Boy 2 - Suraj\nSetting Boy 3 - Kanhaiya\nSetting Boy 4 & Painter - Sushik\n\nCostume Team \n\nCostume Stylist - Tamanna Chhabra \nCostume Assitant - Anjali Dua\nDressman 1 - Riazuddin\nDressman 2 - Irfan\nTailor - Tanveer Aalam\n\nHair And Makeup Team - \n\nMakeup H.O.D - Govind Shankhla\nMakeup Artist - Archana Singh\nHairstylist - Kamal Chopra\nHairstylist - Amit Kashyap\nHmu Artist - Sapna Soni\n\nSound Recordist - Shiv Mishra\n\nSound Post Production Team \n\nSound Designer - Karan Arjun Singh \nDialogue editor - Sanjay Mishra\nSound Fx editor -  Sanjay Mishra\n\nFoley recording studio - Just Foley Art \nFoley Recordist - Sujit Luhar\nFoley Editor - Ram Kishan Nath\nFoley Artist - Karan Arjun Singh,Anil Pawar,\nHarish Nath,Preetha Nayak\nRe-recording Studio - Kiraat Entertainment\nRe-recording Mixer - Sanjay Mishra\n\n\nDI - Afterplay Studios (Maddy)\nMd & Founder - Madan Choudhary \nAdministration - Ganesh Choudhary\nDI Head - Ganapathy Subramanian\nAssistant DI Head - Ramesh Choudhary\nBuisness Head - Swati S. Shinde\nDI Colorist - Manoj Singh\nDI Line Producer - Rakesh Choudhary\nDI Conformist - Ajay Parshuram , Saurabh Singh ,Mandar Prabhu\nDCP Mastering Team  - Tushar Namdeo Wadhe , Anup Jaiswar\nData Team - Mahesh Tanaji Jagadale ,Sanket H Pawar ,Deepak Kohli, Siddharth Pawar\nOffice Boy - Jantu Biswas,Sanjay Biswas,Birbal Biswas,Ranjeet Kumar,Umesh Kumar,Ranjit Namosudra,Vivek Kohli\n\nVfx And Graphics - VFX Guy Shrinay\nAsst. Editor - Karan Kumar\nMaking - Adywise\nWalkie - Ajay Kumar\nCamera Rental - Ekta Vision\nLight - Light & Solutions \nLight Mens - Kishan,Rishi,Monu,\nAkash,Ankit,Rajvir\n\n\nOrignal Songs Credits - \n\n1)Zindagi\nSinger -  Shivansh Joshi \nLyrics By - Amit Bhadana\nMusic By - Tushar Garg\nComposed By - Amit Bhadana / Tushar\nMix Mastering - Tushar Garg\n\n2) Yeh Pal\nSinger - Lovepreet Singh\nLyrics & Composed By - Amit Bhadana\nMusic & Mix Mastering - Lovepreet Singh\n\n\n#AmitBhadana #ssc #SarkariNaukari",
        "thumbnails": {
          "default": {
            "url": "https://i.ytimg.com/vi/OKzvVmX7naI/default.jpg",
            "width": 120,
            "height": 90
          },
          "medium": {
            "url": "https://i.ytimg.com/vi/OKzvVmX7naI/mqdefault.jpg",
            "width": 320,
            "height": 180
          },
          "high": {
            "url": "https://i.ytimg.com/vi/OKzvVmX7naI/hqdefault.jpg",
            "width": 480,
            "height": 360
          },
          "standard": {
            "url": "https://i.ytimg.com/vi/OKzvVmX7naI/sddefault.jpg",
            "width": 640,
            "height": 480
          },
          "maxres": {
            "url": "https://i.ytimg.com/vi/OKzvVmX7naI/maxresdefault.jpg",
            "width": 1280,
            "height": 720
          }
        },
        "channelTitle": "Amit Bhadana",
        "tags": [
          "amit bhadana",
          "amit bhadana videos",
          "amit bhadana vines",
          "amit bhadana dub",
          "amit bhadana desi videos",
          "amit bhadana series",
          "amit bhadana comedy",
          "amit bhadana new",
          "amit bhadana old",
          "amit bhadana ssc",
          "ssc",
          "shiv shankar",
          "government jobs",
          "mukhrjee nagar",
          "competitive exams",
          "students",
          "teachers",
          "adda 247",
          "result",
          "exams",
          "web series",
          "aspirants",
          "inspirations",
          "failures",
          "success",
          "dost",
          "education",
          "cricket",
          "match",
          "politics",
          "coaching",
          "offline",
          "online",
          "sarkari naukari",
          "cpo",
          "cgl",
          "mts",
          "chsl",
          "classroom",
          "vacancy",
          "jobs",
          "yaari"
        ],
        "categoryId": "24",
        "liveBroadcastContent": "none",
        "localized": {
          "title": "SSC | EP 02: मुखर्जी नगर | Amit Bhadana",
          "description": "Watch Episode 01- https://youtu.be/AlAJ3Ykst7E?si=ph-KCKhEg5qwpuur\n\nDownload Adda247 App:  https://adda247.app.link/Amit_Bhadana_E2\n\nAdda247, India's largest vernacular Exam preparation company founded in 2010. Adda247 provides well curated course content & teaching by top faculties of industry for all types of Exam preparations, i.e., Govt jobs, IIT, Medical, State Exams, etc.\n\nRate Us On IMDB: https://www.imdb.com/title/tt29424187/\n\nKisi bhi ladai mein insaan ki aadhi jeet tabhi ho jati hai jab vo ladne ki himmat juta le. Student Shiv ko uske papa ne ghar se nikaal diya hai aur ab vo aa gaya hai Mukherjee Nagar ke warzone mein, jahan sapne bante bhi hai aur bigadte bhi. Dosari taraf SSC sir ke best teacher ko Khanna hijack kar leta hai aur us par ilzaam bhi lagata hai. Nayi nayi problems sar utha rahi hain lekin hope ki ungali thame Shiv aur SSC badh rahe hain kadam dar kadam.\n\nCreated And Directed By - Amit Bhadana\nWritten By - Amit Bhadana, Adheesh Verma, Swapnil Narendra \nCo Director - Vishal Kumar \nDirector Of Photography - Arvind Yadav \nCreative Director - Dhruv Behl\nEditor - Mohd Firoj Aalam\nMusic Director - Lovepreet Singh\nHead Of Production - Avinash Choudhary \nExecutive Producer - Avinash Choudhary \nProduction House - Mavericks Film Productions \nLine Producer - Mandeep Verma\n\nDirecton Team \n\n1st AD - Rishabh Bhagat \n2nd AD - Sanskriti Singh\n2nd 2nd AD - Yashita Verma\n3rd AD - Dev Verma \nScript Supervisor - Saurabh Kumar \nIntern AD - Chandan Paswan \nIntern AD - Riddhi Sharma\n\nProduction Team \n\nAssociate Line Producer - Amit Pradhan \nAssociate Line Producer - Anupam Sharma \nProduction Controller - Sahil Pal\nProduction Manager - Harsh Sharma\nProduction Team - Kanika Krishnanni , Monu Ali , Bhoomi Khandelwal, Shubham Senger, Tushar\n\nLocation Manager\n\nGreater Noida - Avdesh Yadav\nU.P. Mukherjee Nagar , Delhi - Amit Dedha & Team \n\nFood - Kuldeep Gupta \nTransportation Support - JS Travel\nSpot Team - Radhe & Team\nFacilities - Mavericksfilmproductions\n\nCamera and Electrical Department\n\n2nd Dop - Sachin Gupta, Don Jordz,Priyanshu Vats\n1st Ac - Deepanshu Sharma \n1st Focus Puller - Chandan Singh\n2nd Focus Puller - Anshul ,Mahesh Kumar, Sumit\nIntern - Himanshi Bansal\nGaffer -  Gaurav\nLighting Incharge - Satya\nElectrician - Rajesh\nCamera - Ekta Vision\nStedicam - Ankit Sharma\nDolly - Montu and Team , Nitesh Kumar\nDrone -  Anil\nCamera Attendant - Praphull Kumar, Nitesh Kumar,Vishal Kumar,Jitendra Kumar\n\nCasting Director - Sanjay Wadhwa (Citric Media House)\nCasting Director - Aarti Sharma (Citric Media House) \nJunior Artist Coordinator - Rahul\n\nArt Direction Team\n\nArt Director -  Abdul Fayyaz \nAssistant Art Director - Amaan Alam \nSet Dresser - Sneha \nProp Master - Saurabh \nForward Art - Sharukh\nCarpenter - Salman\nSetting Boy 1 - Nitin\nSetting Boy 2 - Suraj\nSetting Boy 3 - Kanhaiya\nSetting Boy 4 & Painter - Sushik\n\nCostume Team \n\nCostume Stylist - Tamanna Chhabra \nCostume Assitant - Anjali Dua\nDressman 1 - Riazuddin\nDressman 2 - Irfan\nTailor - Tanveer Aalam\n\nHair And Makeup Team - \n\nMakeup H.O.D - Govind Shankhla\nMakeup Artist - Archana Singh\nHairstylist - Kamal Chopra\nHairstylist - Amit Kashyap\nHmu Artist - Sapna Soni\n\nSound Recordist - Shiv Mishra\n\nSound Post Production Team \n\nSound Designer - Karan Arjun Singh \nDialogue editor - Sanjay Mishra\nSound Fx editor -  Sanjay Mishra\n\nFoley recording studio - Just Foley Art \nFoley Recordist - Sujit Luhar\nFoley Editor - Ram Kishan Nath\nFoley Artist - Karan Arjun Singh,Anil Pawar,\nHarish Nath,Preetha Nayak\nRe-recording Studio - Kiraat Entertainment\nRe-recording Mixer - Sanjay Mishra\n\n\nDI - Afterplay Studios (Maddy)\nMd & Founder - Madan Choudhary \nAdministration - Ganesh Choudhary\nDI Head - Ganapathy Subramanian\nAssistant DI Head - Ramesh Choudhary\nBuisness Head - Swati S. Shinde\nDI Colorist - Manoj Singh\nDI Line Producer - Rakesh Choudhary\nDI Conformist - Ajay Parshuram , Saurabh Singh ,Mandar Prabhu\nDCP Mastering Team  - Tushar Namdeo Wadhe , Anup Jaiswar\nData Team - Mahesh Tanaji Jagadale ,Sanket H Pawar ,Deepak Kohli, Siddharth Pawar\nOffice Boy - Jantu Biswas,Sanjay Biswas,Birbal Biswas,Ranjeet Kumar,Umesh Kumar,Ranjit Namosudra,Vivek Kohli\n\nVfx And Graphics - VFX Guy Shrinay\nAsst. Editor - Karan Kumar\nMaking - Adywise\nWalkie - Ajay Kumar\nCamera Rental - Ekta Vision\nLight - Light & Solutions \nLight Mens - Kishan,Rishi,Monu,\nAkash,Ankit,Rajvir\n\n\nOrignal Songs Credits - \n\n1)Zindagi\nSinger -  Shivansh Joshi \nLyrics By - Amit Bhadana\nMusic By - Tushar Garg\nComposed By - Amit Bhadana / Tushar\nMix Mastering - Tushar Garg\n\n2) Yeh Pal\nSinger - Lovepreet Singh\nLyrics & Composed By - Amit Bhadana\nMusic & Mix Mastering - Lovepreet Singh\n\n\n#AmitBhadana #ssc #SarkariNaukari"
        },
        "defaultAudioLanguage": "en"
      },
      "contentDetails": {
        "duration": "PT37M",
        "dimension": "2d",
        "definition": "hd",
        "caption": "true",
        "licensedContent": true,
        "contentRating": {
          
        },
        "projection": "rectangular"
      },
      "statistics": {
        "viewCount": "3993766",
        "likeCount": "306746",
        "favoriteCount": "0",
        "commentCount": "13610"
      }
    },
    {
      "kind": "youtube#video",
      "etag": "QTbQDKyzfEgmcTFm5tsCQXJ1WfQ",
      "id": "84LPjMCILNc",
      "snippet": {
        "publishedAt": "2023-10-19T06:41:41Z",
        "channelId": "UCKLN9wGq6WfD2JgJk6P7ODQ",
        "title": "LEO Tamil Movie Review By Sudhish Payyanur @monsoon-media​",
        "description": "LEO Full Movie Review: Watch the video review of the Tamil film LEO directed by Lokesh Kanagaraj starring Thalapathy Vijay, Sanjay Dutt, Trisha, Arjun, Gautham Vasudev Menon, Mysskin, Mansoor Ali Khan, Priya Anand in the lead roles.\n\nSubscribe To Monsoon Media\nhttps://www.youtube.com/monsoonmediain\n\nFOLLOW us on Instagram\nhttps://www.instagram.com/monsoonmedia\n\nLIKE us on Facebook\nhttps://www.facebook.com/monsoonmedia\n\nWe’re on WhatsApp!\nSay Hello! on 9947989025\n\nJoin Our Telegram Channel\nhttps://t.me/monsoonmediain\n\nEmail: come2mm@gmail.com\n\nPlease support our crowdfunding campaign:\nhttps://www.patreon.com/monsoonmedia\n\nOur Backup Channel:\nhttps://www.youtube.com/moviebitein\n\nDon't forget to Comment, Like and Share!!!! \n\n#MonsoonMedia #MovieReview #SudhishPayyanur #leo #FilmCriticism #MalayalamMovieReview #MalayalamFilm #MalayalamMovie #MalayalamCinema #MalayalamVlog #MalayalamReview #MalayalamFilmReview\n \nMonsoon Media is a YouTube channel intended to promote Malayalam cinema through films review, interviews, discussions, video essays, and analytical compilations. It is intended primarily for the purpose of encouraging informed discussions, criticism, and review of cinema.",
        "thumbnails": {
          "default": {
            "url": "https://i.ytimg.com/vi/84LPjMCILNc/default.jpg",
            "width": 120,
            "height": 90
          },
          "medium": {
            "url": "https://i.ytimg.com/vi/84LPjMCILNc/mqdefault.jpg",
            "width": 320,
            "height": 180
          },
          "high": {
            "url": "https://i.ytimg.com/vi/84LPjMCILNc/hqdefault.jpg",
            "width": 480,
            "height": 360
          },
          "standard": {
            "url": "https://i.ytimg.com/vi/84LPjMCILNc/sddefault.jpg",
            "width": 640,
            "height": 480
          },
          "maxres": {
            "url": "https://i.ytimg.com/vi/84LPjMCILNc/maxresdefault.jpg",
            "width": 1280,
            "height": 720
          }
        },
        "channelTitle": "Monsoon Media",
        "tags": [
          "Monsoon Media",
          "Sudhish Payyanur",
          "movie",
          "review",
          "Malayalam review",
          "monsoon media",
          "film review",
          "Malayalam full movie",
          "Malayalam",
          "monsoon media reviews",
          "leo Tamil Movie",
          "leo Tamil Movie Review",
          "leo movie review",
          "leo Trailer",
          "leo review tamil",
          "leo",
          "Thalapathy Vijay",
          "Sanjay Dutt",
          "Trisha",
          "Arjun",
          "Gautham Vasudev Menon",
          "Mysskin",
          "Mansoor Ali Khan",
          "Priya Anand"
        ],
        "categoryId": "24",
        "liveBroadcastContent": "none",
        "defaultLanguage": "en",
        "localized": {
          "title": "LEO Tamil Movie Review By Sudhish Payyanur @monsoon-media​",
          "description": "LEO Full Movie Review: Watch the video review of the Tamil film LEO directed by Lokesh Kanagaraj starring Thalapathy Vijay, Sanjay Dutt, Trisha, Arjun, Gautham Vasudev Menon, Mysskin, Mansoor Ali Khan, Priya Anand in the lead roles.\n\nSubscribe To Monsoon Media\nhttps://www.youtube.com/monsoonmediain\n\nFOLLOW us on Instagram\nhttps://www.instagram.com/monsoonmedia\n\nLIKE us on Facebook\nhttps://www.facebook.com/monsoonmedia\n\nWe’re on WhatsApp!\nSay Hello! on 9947989025\n\nJoin Our Telegram Channel\nhttps://t.me/monsoonmediain\n\nEmail: come2mm@gmail.com\n\nPlease support our crowdfunding campaign:\nhttps://www.patreon.com/monsoonmedia\n\nOur Backup Channel:\nhttps://www.youtube.com/moviebitein\n\nDon't forget to Comment, Like and Share!!!! \n\n#MonsoonMedia #MovieReview #SudhishPayyanur #leo #FilmCriticism #MalayalamMovieReview #MalayalamFilm #MalayalamMovie #MalayalamCinema #MalayalamVlog #MalayalamReview #MalayalamFilmReview\n \nMonsoon Media is a YouTube channel intended to promote Malayalam cinema through films review, interviews, discussions, video essays, and analytical compilations. It is intended primarily for the purpose of encouraging informed discussions, criticism, and review of cinema."
        },
        "defaultAudioLanguage": "ml"
      },
      "contentDetails": {
        "duration": "PT7M42S",
        "dimension": "2d",
        "definition": "hd",
        "caption": "false",
        "licensedContent": true,
        "contentRating": {
          
        },
        "projection": "rectangular"
      },
      "statistics": {
        "viewCount": "186930",
        "likeCount": "7069",
        "favoriteCount": "0",
        "commentCount": "1024"
      }
    },
    {
      "kind": "youtube#video",
      "etag": "kSm1yNhHv1pPSfvZdMmyZbboQoA",
      "id": "mhFsxO9WE8c",
      "snippet": {
        "publishedAt": "2023-10-17T08:30:08Z",
        "channelId": "UCdDDWwRdgJTgpD4iPtOZRUQ",
        "title": "Meri Jaan / Ya Tuli Khanjar Maare | Bhoomi 2023 | Mithoon | Abdul Rashid Hafiz, Asees Kaur | Kashmir",
        "description": "We're back with a beautiful Sufi Hindi and Kashmiri song - #MeriJaan by #Mithoon and #AbdulRashidHafiz. It's a powerful expression of separation and talks about love in a very unique way with a very impactful sound. The Hindi part is written by A M Turaz and the Kashmiri composition is written by Abdul Ahad Nazim.\n\n#MeriJaan is the fourth song from GoDaddy India presents #Bhoomi2023, powered by Moha \n\nSubscribe to our channel for more music everyday 🔔 \n\nTo SUBSCRIBE click the link below:\nhttp://www.youtube.com/subscription_center?add_user=SalimSulaimanMusic\n\nSingers: Asees Kaur, Abdul Rashid Hafiz \nMusic: Mithoon, Abdul Rashid Hafiz\nSong created, composed and arranged by Mithoon\nLyrics: A. M. Turaz, Abdul Ahad Nazim\nCreative Head: Anugrah\nMusic Programming by Godswill Mergulhao and Bobby Shrivastava \nMusic Asst: Anugrah, Godswill Mergulhao, Eli Rodrigues & Kaushal Gohil\nLive Percussions by Bobby Shrivastava, Anugrah, Godswill Mergulhao, Eli Rodrigues, Omkar Salunkhe, Keyur Barve, Jignesh Patel & Kaushal Gohil \nWorld Winds played by Naveen Kumar\nWorld Strokes by Tapas Roy & Chintoo Singh Wasir\nBass Guitar: Akashdeep Gogoi\nKashmiri Vocals Arranged & Supervised by: Raj Pandit\nBacking Vocals: Raj Pandit, Aditya Kalway, Shivansh Jindal, Prateeksha Srivastava, Priyanshi Srivastava \nBacking Vocals recorded by: Raj Pandit at Blue Productions\nChorus: Pragati Joshi, Archana Gore, Deepti Rege, Janardan Dhatrak, Umesh Joshi, Dattatray Mistry\nRashid Hafiz Sahab’s vocals recorded by: Shahid Vaakhs at Vaakhs Studio (Srinagar, J&K, India)\nAsees Kaur Recorded at Living Water Music by Eli Rodrigues\nSong Mixed & Mastered by Eric Pillai at Future Sound Of Bombay\nMixing Asst: Michael Edwin Pillai\nDistributed by Global Music Junction, Warner Music India\n\nProject Co-ordinated (for Mithoon) by Vijay Iyer\nLegal Advisor to Mithoon: Shyam Dewani\n\nSpecial Thanks to Neerja Pandit ji, Tassaduq Hussain, Misbah Ali and Shahid Vaakhs\n\nDirector: Shakti Hasija\nProject Head: Nirav Thakar\nArtist Relations: Radhika Mistry\nPartnerships, Strategy and Marketing: Shivansh Jindal\n\nLine Production: Ashoke Pandit Productions \nAssociate Producer: Rajveer Ahuja\nProduction Manager: Rajesh Chakre\n\nDirector of Photography: Anubhav Bansal\nExecutive Video Producer: Kunjan Hasija\nProduction controller: Nidhi Oza\nAssistant Directors: Dev Byas, Sushil Gothankar, Rahul Singh Somvanshi\nPost Production: Industrywalas\nEditor: Sushil Gothankar\nOnline & Mastering: Byas Dev\nAssistant Editors: Kripamoy Das, Rahul Singh Somvanshi\nGrading: Rahul Singh Somvanshi\nDIT: Abhijeet Jondhale, Kripamoy Das\n\nSet Design: The Concert Production \nProduction Head: Zeeshan Siddiqui \nLight Designer: Sohail Mansuri \nLight Engineer: Maaz Mansuri \nLED Graphics: Rahul Nirmal\nStage Manager: Prasad Satam \nProduction Assistant: Rahul Nirmal\n\nFirst AC: David Basu\nCamera Operators: Karan M, Shubh S, Chang D, Anirudh N, Paul V\nFocus Pullers: Vishal G, Ankush, Ankul S, Maneesh K Gupta, Satyam\n\nEquipments:\nCamera & Lenses: RD Equipment’s Pvt Ltd.\nPanther: Uzair Shaikh\nTurntable Rig: Zoo Grips\nJib: Star Cine Services\nGo Pro: Accord Equips Pvt Ltd\n\nMakeup and Hair Designer: Suman Singh Chauhan \nMakeup and Hair Team: Zabi Shaikh, Asfaq Shaikh, Sunil Singh, Sandeep Kumar, Shubham Parab, Nitin Gaikar\n\nOutfit for Mithoon: Rechannel Fashion\nOutfit for Asses Kaur: Aseem Kapoor Official\nJewellery: Sangeeta Boochra and Silver Kiosk\n\nFashion Stylist: Sujata Setiya\nStyling Team: Disha Prasad, Sudha Sharma, Gauri Vidhlani, Rutuja, Shurti Apune, Sia M, Saloni Ramnani\n\nFinance Head: Anil Kajrolkar\nDigital Strategy: Bonny Gosain\nMarketing Interns: Shreya Bhagavatula, Simran Fathima\nStills: Vishal Sain, Sanket B, Aaquib Siddique\nAlbum Creatives: Dishant Mistry\n\nLyrics - \n\nCheshma wuchh wuchh chaayni wayn mye gaah soryom, donn achhan \nMyenkin wayn saarnyee, cheshma baadaam aysitan\n\nMere jeene ka saara..\nHmm.. Mere jeene ka saara..\nMere jeena ka saara samaan lete jao\nMera chaen-o-sukoon mera\nItminan lete jao\n\nJo ja rahe ho jaana x3\nMeri jaan lete jao \n\nMere jeena ka saara samaan lete jao\nMera chaen-o-sukoon mera\nItminan lete jao\n\nJo ja rahe ho jaana x3\nMeri jaan lete jao \n\nYim Zaar Vanhas Bardar\nKar Sanaa Su Yaar Bozey\n\nYa Tuli Khanjar Maarey\nNat Saayn Shabaa Rozey \n\nIss ishq mein had tak jaan-e-talak ki\nsaari wafaye meri hai\nKi tumhara ismein kuch bhi nahi\nsaari khataye meri x3\n\nDil khol ke mujhko tum..\nDil khol ke mujhko tum Ilzaam dete jao\n\nJo ja rahe ho jaana x3\nMeri jaan lete jao \n\nMaashok Kyah Goi Keenai \nAatash Mye Bortham Seenai\n\nAashak Chhu Kaym Taam Deenai\nMaaroony Ravaa Rozey\n\nYim Zaar ..\n\nMere jeena ka saara\nAatash Mye Bortham Seenai x2\nMere jeena ka saara\nAashak Chhu Kaym Taam Deenai\nMaaroony Ravaa Rozey\nMere jeena ka saara samaan lete jao\n\nFollow us on: \n\nhttps://www.facebook.com/salimsulaimanmusic\n\nFB: https://www.facebook.com/MerchantRecordsMusic\n\nIG: https://www.instagram.com/merchant_records/\n\n#HafizSahab #KashmiriFolk #Bhoomi23 #SalimSulaiman #GoDaddyIndia #Moha #MerchantRecords #Koshur #Kashmir",
        "thumbnails": {
          "default": {
            "url": "https://i.ytimg.com/vi/mhFsxO9WE8c/default.jpg",
            "width": 120,
            "height": 90
          },
          "medium": {
            "url": "https://i.ytimg.com/vi/mhFsxO9WE8c/mqdefault.jpg",
            "width": 320,
            "height": 180
          },
          "high": {
            "url": "https://i.ytimg.com/vi/mhFsxO9WE8c/hqdefault.jpg",
            "width": 480,
            "height": 360
          },
          "standard": {
            "url": "https://i.ytimg.com/vi/mhFsxO9WE8c/sddefault.jpg",
            "width": 640,
            "height": 480
          },
          "maxres": {
            "url": "https://i.ytimg.com/vi/mhFsxO9WE8c/maxresdefault.jpg",
            "width": 1280,
            "height": 720
          }
        },
        "channelTitle": "Salim Sulaiman",
        "tags": [
          "salim sulaiman",
          "salim",
          "salim sulaiman songs",
          "song collection",
          "salim merchant",
          "merchant records",
          "hindi songs",
          "salim sulaiman mtv unplugged",
          "asees kaur",
          "asis kaur",
          "asees kaur songs",
          "asees kaur new song",
          "mithoon asees kaur",
          "mithoon bhoomi 23",
          "mithun new song",
          "abdul rashid hafiz",
          "rashid hafiz",
          "ya tuli khanjar",
          "ya tuli khanjar maaray",
          "ya tuli rashid hafiz",
          "mithoon coke studio",
          "rashid hafiz kashmiri songs",
          "rashid hafiz mithoon",
          "koshur",
          "kashmiri songs",
          "rashid hafiz new song"
        ],
        "categoryId": "10",
        "liveBroadcastContent": "none",
        "defaultLanguage": "en",
        "localized": {
          "title": "Meri Jaan / Ya Tuli Khanjar Maare | Bhoomi 2023 | Mithoon | Abdul Rashid Hafiz, Asees Kaur | Kashmir",
          "description": "We're back with a beautiful Sufi Hindi and Kashmiri song - #MeriJaan by #Mithoon and #AbdulRashidHafiz. It's a powerful expression of separation and talks about love in a very unique way with a very impactful sound. The Hindi part is written by A M Turaz and the Kashmiri composition is written by Abdul Ahad Nazim.\n\n#MeriJaan is the fourth song from GoDaddy India presents #Bhoomi2023, powered by Moha \n\nSubscribe to our channel for more music everyday 🔔 \n\nTo SUBSCRIBE click the link below:\nhttp://www.youtube.com/subscription_center?add_user=SalimSulaimanMusic\n\nSingers: Asees Kaur, Abdul Rashid Hafiz \nMusic: Mithoon, Abdul Rashid Hafiz\nSong created, composed and arranged by Mithoon\nLyrics: A. M. Turaz, Abdul Ahad Nazim\nCreative Head: Anugrah\nMusic Programming by Godswill Mergulhao and Bobby Shrivastava \nMusic Asst: Anugrah, Godswill Mergulhao, Eli Rodrigues & Kaushal Gohil\nLive Percussions by Bobby Shrivastava, Anugrah, Godswill Mergulhao, Eli Rodrigues, Omkar Salunkhe, Keyur Barve, Jignesh Patel & Kaushal Gohil \nWorld Winds played by Naveen Kumar\nWorld Strokes by Tapas Roy & Chintoo Singh Wasir\nBass Guitar: Akashdeep Gogoi\nKashmiri Vocals Arranged & Supervised by: Raj Pandit\nBacking Vocals: Raj Pandit, Aditya Kalway, Shivansh Jindal, Prateeksha Srivastava, Priyanshi Srivastava \nBacking Vocals recorded by: Raj Pandit at Blue Productions\nChorus: Pragati Joshi, Archana Gore, Deepti Rege, Janardan Dhatrak, Umesh Joshi, Dattatray Mistry\nRashid Hafiz Sahab’s vocals recorded by: Shahid Vaakhs at Vaakhs Studio (Srinagar, J&K, India)\nAsees Kaur Recorded at Living Water Music by Eli Rodrigues\nSong Mixed & Mastered by Eric Pillai at Future Sound Of Bombay\nMixing Asst: Michael Edwin Pillai\nDistributed by Global Music Junction, Warner Music India\n\nProject Co-ordinated (for Mithoon) by Vijay Iyer\nLegal Advisor to Mithoon: Shyam Dewani\n\nSpecial Thanks to Neerja Pandit ji, Tassaduq Hussain, Misbah Ali and Shahid Vaakhs\n\nDirector: Shakti Hasija\nProject Head: Nirav Thakar\nArtist Relations: Radhika Mistry\nPartnerships, Strategy and Marketing: Shivansh Jindal\n\nLine Production: Ashoke Pandit Productions \nAssociate Producer: Rajveer Ahuja\nProduction Manager: Rajesh Chakre\n\nDirector of Photography: Anubhav Bansal\nExecutive Video Producer: Kunjan Hasija\nProduction controller: Nidhi Oza\nAssistant Directors: Dev Byas, Sushil Gothankar, Rahul Singh Somvanshi\nPost Production: Industrywalas\nEditor: Sushil Gothankar\nOnline & Mastering: Byas Dev\nAssistant Editors: Kripamoy Das, Rahul Singh Somvanshi\nGrading: Rahul Singh Somvanshi\nDIT: Abhijeet Jondhale, Kripamoy Das\n\nSet Design: The Concert Production \nProduction Head: Zeeshan Siddiqui \nLight Designer: Sohail Mansuri \nLight Engineer: Maaz Mansuri \nLED Graphics: Rahul Nirmal\nStage Manager: Prasad Satam \nProduction Assistant: Rahul Nirmal\n\nFirst AC: David Basu\nCamera Operators: Karan M, Shubh S, Chang D, Anirudh N, Paul V\nFocus Pullers: Vishal G, Ankush, Ankul S, Maneesh K Gupta, Satyam\n\nEquipments:\nCamera & Lenses: RD Equipment’s Pvt Ltd.\nPanther: Uzair Shaikh\nTurntable Rig: Zoo Grips\nJib: Star Cine Services\nGo Pro: Accord Equips Pvt Ltd\n\nMakeup and Hair Designer: Suman Singh Chauhan \nMakeup and Hair Team: Zabi Shaikh, Asfaq Shaikh, Sunil Singh, Sandeep Kumar, Shubham Parab, Nitin Gaikar\n\nOutfit for Mithoon: Rechannel Fashion\nOutfit for Asses Kaur: Aseem Kapoor Official\nJewellery: Sangeeta Boochra and Silver Kiosk\n\nFashion Stylist: Sujata Setiya\nStyling Team: Disha Prasad, Sudha Sharma, Gauri Vidhlani, Rutuja, Shurti Apune, Sia M, Saloni Ramnani\n\nFinance Head: Anil Kajrolkar\nDigital Strategy: Bonny Gosain\nMarketing Interns: Shreya Bhagavatula, Simran Fathima\nStills: Vishal Sain, Sanket B, Aaquib Siddique\nAlbum Creatives: Dishant Mistry\n\nLyrics - \n\nCheshma wuchh wuchh chaayni wayn mye gaah soryom, donn achhan \nMyenkin wayn saarnyee, cheshma baadaam aysitan\n\nMere jeene ka saara..\nHmm.. Mere jeene ka saara..\nMere jeena ka saara samaan lete jao\nMera chaen-o-sukoon mera\nItminan lete jao\n\nJo ja rahe ho jaana x3\nMeri jaan lete jao \n\nMere jeena ka saara samaan lete jao\nMera chaen-o-sukoon mera\nItminan lete jao\n\nJo ja rahe ho jaana x3\nMeri jaan lete jao \n\nYim Zaar Vanhas Bardar\nKar Sanaa Su Yaar Bozey\n\nYa Tuli Khanjar Maarey\nNat Saayn Shabaa Rozey \n\nIss ishq mein had tak jaan-e-talak ki\nsaari wafaye meri hai\nKi tumhara ismein kuch bhi nahi\nsaari khataye meri x3\n\nDil khol ke mujhko tum..\nDil khol ke mujhko tum Ilzaam dete jao\n\nJo ja rahe ho jaana x3\nMeri jaan lete jao \n\nMaashok Kyah Goi Keenai \nAatash Mye Bortham Seenai\n\nAashak Chhu Kaym Taam Deenai\nMaaroony Ravaa Rozey\n\nYim Zaar ..\n\nMere jeena ka saara\nAatash Mye Bortham Seenai x2\nMere jeena ka saara\nAashak Chhu Kaym Taam Deenai\nMaaroony Ravaa Rozey\nMere jeena ka saara samaan lete jao\n\nFollow us on: \n\nhttps://www.facebook.com/salimsulaimanmusic\n\nFB: https://www.facebook.com/MerchantRecordsMusic\n\nIG: https://www.instagram.com/merchant_records/\n\n#HafizSahab #KashmiriFolk #Bhoomi23 #SalimSulaiman #GoDaddyIndia #Moha #MerchantRecords #Koshur #Kashmir"
        },
        "defaultAudioLanguage": "hi"
      },
      "contentDetails": {
        "duration": "PT5M12S",
        "dimension": "2d",
        "definition": "hd",
        "caption": "false",
        "licensedContent": true,
        "contentRating": {
          
        },
        "projection": "rectangular"
      },
      "statistics": {
        "viewCount": "1846320",
        "likeCount": "92208",
        "favoriteCount": "0",
        "commentCount": "4531"
      }
    },
    {
      "kind": "youtube#video",
      "etag": "MVghydyMQvusP_E5LTBXVhx3kiY",
      "id": "RndB0KG-Lr0",
      "snippet": {
        "publishedAt": "2023-10-19T16:31:16Z",
        "channelId": "UCSRQXk5yErn4e14vN76upOw",
        "title": "Cricbuzz Live हिन्दी: #Kohli hits 48th ODI ton; #India thrash #Bangladesh by 7 wickets in World Cup",
        "description": "India को मिली तेज़ शुरुआत को Virat Kohli की शानदार पारी ने दिया अंजाम, लगातार चौथी जीत की अपने नाम। जुड़िए Virender Sehwag, Parthiv Patel और Gaurav Kapur के साथ, Cricbuzz Live हिन्दी पर\n\n#RohitSharma #ViratKohli #HardikPandya #JaspritBumrah #India #LittonDas #MustafizurRahman #MushfiqurRahim #ShakibalHasan #INDvBAN #CWC23 #WorldCup #ODIWorldCup #2023WorldCup #Cricket #CricketVideos #Videos #CricbuzzLive #CricketNews \n\nWatch more cricket videos - https://www.cricbuzz.com/cricket-videos​​ \n\nFor more cricket updates and content - https://www.cricbuzz.com\n\nFor more updates on cricket follow us on facebook - \nhttps://www.facebook.com/cricbuzz\n\nFollow us on twitter to get cricket related news - \nhttps://twitter.com/cricbuzz",
        "thumbnails": {
          "default": {
            "url": "https://i.ytimg.com/vi/RndB0KG-Lr0/default.jpg",
            "width": 120,
            "height": 90
          },
          "medium": {
            "url": "https://i.ytimg.com/vi/RndB0KG-Lr0/mqdefault.jpg",
            "width": 320,
            "height": 180
          },
          "high": {
            "url": "https://i.ytimg.com/vi/RndB0KG-Lr0/hqdefault.jpg",
            "width": 480,
            "height": 360
          },
          "standard": {
            "url": "https://i.ytimg.com/vi/RndB0KG-Lr0/sddefault.jpg",
            "width": 640,
            "height": 480
          },
          "maxres": {
            "url": "https://i.ytimg.com/vi/RndB0KG-Lr0/maxresdefault.jpg",
            "width": 1280,
            "height": 720
          }
        },
        "channelTitle": "Cricbuzz",
        "tags": [
          "Cricket",
          "Cricbuzz",
          "Sports",
          "Video",
          "Highlights",
          "IPL",
          "India",
          "World Cup",
          "Pakistan",
          "Match",
          "T20 World Cup",
          "t20",
          "news",
          "live",
          "streaming",
          "scores"
        ],
        "categoryId": "17",
        "liveBroadcastContent": "none",
        "localized": {
          "title": "Cricbuzz Live हिन्दी: #Kohli hits 48th ODI ton; #India thrash #Bangladesh by 7 wickets in World Cup",
          "description": "India को मिली तेज़ शुरुआत को Virat Kohli की शानदार पारी ने दिया अंजाम, लगातार चौथी जीत की अपने नाम। जुड़िए Virender Sehwag, Parthiv Patel और Gaurav Kapur के साथ, Cricbuzz Live हिन्दी पर\n\n#RohitSharma #ViratKohli #HardikPandya #JaspritBumrah #India #LittonDas #MustafizurRahman #MushfiqurRahim #ShakibalHasan #INDvBAN #CWC23 #WorldCup #ODIWorldCup #2023WorldCup #Cricket #CricketVideos #Videos #CricbuzzLive #CricketNews \n\nWatch more cricket videos - https://www.cricbuzz.com/cricket-videos​​ \n\nFor more cricket updates and content - https://www.cricbuzz.com\n\nFor more updates on cricket follow us on facebook - \nhttps://www.facebook.com/cricbuzz\n\nFollow us on twitter to get cricket related news - \nhttps://twitter.com/cricbuzz"
        },
        "defaultAudioLanguage": "en"
      },
      "contentDetails": {
        "duration": "PT34M5S",
        "dimension": "2d",
        "definition": "hd",
        "caption": "false",
        "licensedContent": true,
        "contentRating": {
          
        },
        "projection": "rectangular"
      },
      "statistics": {
        "viewCount": "346602",
        "likeCount": "8784",
        "favoriteCount": "0",
        "commentCount": "400"
      }
    },
    {
      "kind": "youtube#video",
      "etag": "neJQ8l5v1sc7Kb05N6FkCXIwXXA",
      "id": "e1-331BxdkM",
      "snippet": {
        "publishedAt": "2023-10-19T09:27:51Z",
        "channelId": "UCd5Os4gT74gxngzUYqGUzzg",
        "title": "Leo Movie REVIEW | Suraj Kumar",
        "description": "Hello Everyone Welcome To The New Review On LEO Movie |\nStarring: Thalapathy Vijay, Trisha Krishnan, Arjun Sarja, Sanjay Dutt |\nDirecter by Lokesh Kanagaraj |\n\nJoin me on WhatsApp 👇\nFollow the SURAJ KUMAR REVIEW channel on WhatsApp: https://whatsapp.com/channel/0029Va9PZvT89inYteh7xd0s\n\n( THIS VIDEO IS JUST FOR ENTERTAINMENT PURPOSE ONLY )\n\n\nVisit Our second Channel👇🏻\nhttps://youtube.com/channel/UCD1OW2T_f7G6UK-uceKTZwQ\n\nWatch n share this video | \n\nWatch My Kgf 2 Rap Song👇🏻\nhttps://youtu.be/N7nRGfIQZFg\n\n\nWatch our Funniest Fuski Interview With Bollywood Celebrity- Aparshakti Khurana👇🏻\nhttps://youtu.be/F_GX8Z0ISms\n\n\n\nAlso watch our latest short film and try to crack the suspense of it👇🏻\nhttps://youtu.be/e106Y_uIuaw\n\n\n\n\nWatch and enjoy the video\nkyuki film hit ho ya flop but video milega baap \n\nHope u \nLike it , \nShare it ,\nComment it \nAnd subscribe it \n\nJoin us on -\n👇🏻👇🏻👇🏻👇🏻👇🏻\n\nINSTAGRAM -\n\nhttp://Instagram.com/surajkumarreview\n\nShubham kumar insta id👇🏻\n\nhttps://instagram.com/who_is_shubham_kumar\n\n\n👇🏻👇🏻👇🏻👇🏻👇🏻👇🏻\nYOUTUBE - \nhttps://youtube.com/c/SurajKumarReview\n\n\nTwitter \nhttps://twitter.com/Surajkumarrevi1?s=08\n\n\nMail us for queries , Stage Shows , promotion, etc - Surajkumarreview@gmail.com\n\n\nDisclaimer➖Please don't go out of your way to or hate on anyone I talk about in my videos , this channel is to entertain people and i usually focus on joking about what the people are doing not the individual themselves , please don't go hate it's all for laughs \nSpread love , keep smiling and sharing n dont hate me too ! \nLots of love n respect to all my viewers !!!\n\n#leoreview \n#leomoviereview \n#leopublicreview",
        "thumbnails": {
          "default": {
            "url": "https://i.ytimg.com/vi/e1-331BxdkM/default.jpg",
            "width": 120,
            "height": 90
          },
          "medium": {
            "url": "https://i.ytimg.com/vi/e1-331BxdkM/mqdefault.jpg",
            "width": 320,
            "height": 180
          },
          "high": {
            "url": "https://i.ytimg.com/vi/e1-331BxdkM/hqdefault.jpg",
            "width": 480,
            "height": 360
          },
          "standard": {
            "url": "https://i.ytimg.com/vi/e1-331BxdkM/sddefault.jpg",
            "width": 640,
            "height": 480
          },
          "maxres": {
            "url": "https://i.ytimg.com/vi/e1-331BxdkM/maxresdefault.jpg",
            "width": 1280,
            "height": 720
          }
        },
        "channelTitle": "Suraj Kumar",
        "tags": [
          "leo",
          "leo review",
          "leo movie review",
          "leo review hindi",
          "leo review public",
          "leo public review",
          "leo review tamil",
          "leo public talk",
          "leo review telugu",
          "leo hindi review",
          "leo theatre response",
          "leo movie",
          "leo lcu connection",
          "lcu",
          "lokesh cinematic universe",
          "leo box office collection",
          "leo movie public review",
          "leo movie review tamil"
        ],
        "categoryId": "24",
        "liveBroadcastContent": "none",
        "localized": {
          "title": "Leo Movie REVIEW | Suraj Kumar",
          "description": "Hello Everyone Welcome To The New Review On LEO Movie |\nStarring: Thalapathy Vijay, Trisha Krishnan, Arjun Sarja, Sanjay Dutt |\nDirecter by Lokesh Kanagaraj |\n\nJoin me on WhatsApp 👇\nFollow the SURAJ KUMAR REVIEW channel on WhatsApp: https://whatsapp.com/channel/0029Va9PZvT89inYteh7xd0s\n\n( THIS VIDEO IS JUST FOR ENTERTAINMENT PURPOSE ONLY )\n\n\nVisit Our second Channel👇🏻\nhttps://youtube.com/channel/UCD1OW2T_f7G6UK-uceKTZwQ\n\nWatch n share this video | \n\nWatch My Kgf 2 Rap Song👇🏻\nhttps://youtu.be/N7nRGfIQZFg\n\n\nWatch our Funniest Fuski Interview With Bollywood Celebrity- Aparshakti Khurana👇🏻\nhttps://youtu.be/F_GX8Z0ISms\n\n\n\nAlso watch our latest short film and try to crack the suspense of it👇🏻\nhttps://youtu.be/e106Y_uIuaw\n\n\n\n\nWatch and enjoy the video\nkyuki film hit ho ya flop but video milega baap \n\nHope u \nLike it , \nShare it ,\nComment it \nAnd subscribe it \n\nJoin us on -\n👇🏻👇🏻👇🏻👇🏻👇🏻\n\nINSTAGRAM -\n\nhttp://Instagram.com/surajkumarreview\n\nShubham kumar insta id👇🏻\n\nhttps://instagram.com/who_is_shubham_kumar\n\n\n👇🏻👇🏻👇🏻👇🏻👇🏻👇🏻\nYOUTUBE - \nhttps://youtube.com/c/SurajKumarReview\n\n\nTwitter \nhttps://twitter.com/Surajkumarrevi1?s=08\n\n\nMail us for queries , Stage Shows , promotion, etc - Surajkumarreview@gmail.com\n\n\nDisclaimer➖Please don't go out of your way to or hate on anyone I talk about in my videos , this channel is to entertain people and i usually focus on joking about what the people are doing not the individual themselves , please don't go hate it's all for laughs \nSpread love , keep smiling and sharing n dont hate me too ! \nLots of love n respect to all my viewers !!!\n\n#leoreview \n#leomoviereview \n#leopublicreview"
        },
        "defaultAudioLanguage": "hi"
      },
      "contentDetails": {
        "duration": "PT5M22S",
        "dimension": "2d",
        "definition": "hd",
        "caption": "false",
        "licensedContent": true,
        "contentRating": {
          
        },
        "projection": "rectangular"
      },
      "statistics": {
        "viewCount": "442610",
        "likeCount": "34155",
        "favoriteCount": "0",
        "commentCount": "2907"
      }
    },
    {
      "kind": "youtube#video",
      "etag": "a2Fpt5ZbFn9ZOoy_LMzmcy0ZHSI",
      "id": "8J1sZmYKK2Q",
      "snippet": {
        "publishedAt": "2023-10-19T22:30:00Z",
        "channelId": "UC7ZivIYRB0fMSGh-THcTYbw",
        "title": "मां कात्यायनी आरती | Katyayani Mata Aarti by Anuradha Paudwal | नवरात्रि छठे दिन की आरती",
        "description": "मां कात्यायनी आरती | Katyayani Mata Aarti by Anuradha Paudwal | नवरात्रि छठे दिन की आरती\n\nजय जय अम्बे जय कात्यायनी आरती देवी कात्यायनी को समर्पित है। देवी कात्यायनी माता पार्वती के नौ अवतारों में से एक हैं और नवरात्रि के छठवें दिन उनकी पूजा की जाती है।\nAarti: Katyayani Mata Aarti\nSinger: Anuradha Paudwal\nMusic Director: Dr. Sanjayraj Gaurinandan (SRG)\nLyrics: Shivpoojan Patwa\n\n#navratriday6 #aarti #katyayanimata\n#shemaroobhakti \n\nTop Devi Bhajan, Aarti, Gatha\n\nAnuradha Paudwal Mata Ke Bhajans-    https://youtu.be/WvRjiGCPNVw\nDurga Mantra -                                           https://youtu.be/3UrBxim1KFc\nLaxmi Aarti -                                               https://youtu.be/oec7CXRAfeE\nOm Jai Laxmi Mata -                                 https://youtu.be/zdZ67AM47u8\nMahalakshmi Stotra -                                https://youtu.be/13FH5CEUL4I\n\nJoin Us On\nFaceBook :   https://www.facebook.com/ShemarooBhakti\nTwitter      :   https://twitter.com/ShemarooBhakti\nInstagram :  https://www.instagram.com/shemaroobhakti\nSharechat :  https://sharechat.com/profile/shemaroobhakti\n\nअपने दिन को सकारात्मक ऊर्जा से भरने के लिए सब्सक्राइब कीजिये और अपने मित्र परिवार के साथ शेर कीजिये\n🔔 Subscribe NOW: \nhttps://www.youtube.com/@ShemarooBhakti",
        "thumbnails": {
          "default": {
            "url": "https://i.ytimg.com/vi/8J1sZmYKK2Q/default.jpg",
            "width": 120,
            "height": 90
          },
          "medium": {
            "url": "https://i.ytimg.com/vi/8J1sZmYKK2Q/mqdefault.jpg",
            "width": 320,
            "height": 180
          },
          "high": {
            "url": "https://i.ytimg.com/vi/8J1sZmYKK2Q/hqdefault.jpg",
            "width": 480,
            "height": 360
          },
          "standard": {
            "url": "https://i.ytimg.com/vi/8J1sZmYKK2Q/sddefault.jpg",
            "width": 640,
            "height": 480
          },
          "maxres": {
            "url": "https://i.ytimg.com/vi/8J1sZmYKK2Q/maxresdefault.jpg",
            "width": 1280,
            "height": 720
          }
        },
        "channelTitle": "Shemaroo Bhakti",
        "tags": [
          "देवी कात्यायनी आरती",
          "कात्यायनी माता आरती",
          "आरती देवी कात्यायनी जी की",
          "नवरात्रि छठे दिन की आरती",
          "मां कात्यायनी आरती",
          "Katyayani Mata Aarti by Anuradha Paudwal",
          "maa katyayani aarti",
          "katyayani mata ki aarti",
          "नवरात्रि का छठा दिन",
          "navaratri songs",
          "Navratra top navratri bhajans",
          "durga puja",
          "durga pooja",
          "devi puja",
          "देवी भजन",
          "vaishno devi aarti",
          "नवरात्री स्पेशल भजन",
          "navratri bhajan",
          "navratri bhajan 2023",
          "shemaroo bhakti",
          "navratri day 6",
          "navratri 6th day aarti"
        ],
        "categoryId": "10",
        "liveBroadcastContent": "none",
        "defaultLanguage": "en",
        "localized": {
          "title": "मां कात्यायनी आरती | Katyayani Mata Aarti by Anuradha Paudwal | नवरात्रि छठे दिन की आरती",
          "description": "मां कात्यायनी आरती | Katyayani Mata Aarti by Anuradha Paudwal | नवरात्रि छठे दिन की आरती\n\nजय जय अम्बे जय कात्यायनी आरती देवी कात्यायनी को समर्पित है। देवी कात्यायनी माता पार्वती के नौ अवतारों में से एक हैं और नवरात्रि के छठवें दिन उनकी पूजा की जाती है।\nAarti: Katyayani Mata Aarti\nSinger: Anuradha Paudwal\nMusic Director: Dr. Sanjayraj Gaurinandan (SRG)\nLyrics: Shivpoojan Patwa\n\n#navratriday6 #aarti #katyayanimata\n#shemaroobhakti \n\nTop Devi Bhajan, Aarti, Gatha\n\nAnuradha Paudwal Mata Ke Bhajans-    https://youtu.be/WvRjiGCPNVw\nDurga Mantra -                                           https://youtu.be/3UrBxim1KFc\nLaxmi Aarti -                                               https://youtu.be/oec7CXRAfeE\nOm Jai Laxmi Mata -                                 https://youtu.be/zdZ67AM47u8\nMahalakshmi Stotra -                                https://youtu.be/13FH5CEUL4I\n\nJoin Us On\nFaceBook :   https://www.facebook.com/ShemarooBhakti\nTwitter      :   https://twitter.com/ShemarooBhakti\nInstagram :  https://www.instagram.com/shemaroobhakti\nSharechat :  https://sharechat.com/profile/shemaroobhakti\n\nअपने दिन को सकारात्मक ऊर्जा से भरने के लिए सब्सक्राइब कीजिये और अपने मित्र परिवार के साथ शेर कीजिये\n🔔 Subscribe NOW: \nhttps://www.youtube.com/@ShemarooBhakti"
        },
        "defaultAudioLanguage": "hi"
      },
      "contentDetails": {
        "duration": "PT5M44S",
        "dimension": "2d",
        "definition": "hd",
        "caption": "false",
        "licensedContent": true,
        "contentRating": {
          
        },
        "projection": "rectangular"
      },
      "statistics": {
        "viewCount": "208827",
        "likeCount": "3178",
        "favoriteCount": "0",
        "commentCount": "243"
      }
    },
    {
      "kind": "youtube#video",
      "etag": "4gQvW3JGNHffs_Q9ocquQXpkzxU",
      "id": "Lu1v8VFLDno",
      "snippet": {
        "publishedAt": "2023-10-18T09:15:02Z",
        "channelId": "UC5x4u6kU52hgTtLlBaHTSKg",
        "title": "खुसखुशीत कडाकणी | कडकणी मऊ व तेलकट न होण्यासाठी या 2 चुका टाळा | कुरकुरीत कडकणी Navratri Kadakani",
        "description": "सरिताज किचनची सर्व उत्पादने शुद्ध, पारंपरिक आणि केमिकल विरहित आहेत.\nसरिताज किचनचे प्रॉडक्ट्स | Saritas Kitchen Products -\n 1. सर्व प्रकारची लाकडी घाणा तेलं | All Types of Wood Pressed Oils\n 2. डंकावर कुटून केलेला कांदा लसूण मसाला | Handmade Kanda Lasun Masala\n 3. सरिताज किचन सेंद्रिय गुळ | Chemical free Jaggery cubes and powder \n 4. सेंधव मीठ | Pink Himalayan Salt\n 5. सेंद्रियहळद | Organic Turmeric\nऑर्डर करण्यासाठी | To Order -\n • Website - https://saritaskitchenofficial.com/\n • Amazon - http://bitly.ws/zDuc\n \nखुसखुशीत कडाकणी | कडकणी मऊ व तेलकट न होण्यासाठी या 2 चुका टाळा | कुरकुरीत कडकणी Navratri Kadakani\nकडाकणी \nकडाकणी रेसिपी | नवरात्र स्पेशल रेसिपी | दसरा सणानिमित्त खास रेसिपी  | सप्तमी खास कडाकणी माळ रेसिपी | खुसखुशीत व कुरकुरीत कडाकणी रेसिपी | पारंपरिक रेसिपी |  महाराष्ट्रीयन कडाकणी रेसिपी | कडाकणी रेसिपी मराठी | गोड पुरी रेसिपी | kadakani Recipe | Navratra Special Recipe | Sapatami Special Mal Recipe | Dasara Special Recipe | Crispy and Crunchy Kadakani Recipe | Tradational Recipe | Maharashtrian Kadakani Recipe | Kadakani REcipe Marathi | Sweet Puri Recipe | \nसाहित्य | Ingredients \n • मैदा २ कप | Maida 2 cup \n • बारीक रवा १/२ कप | Fine Semolina ½ cup \n • पिठी साखर ३/४ कप | Sugar Powder ¾ cup  \n • दूध ३/४ कप | Milk ½ cup \n • मीठ २ चिमूट | Salt 2 pinch \n • तेल २ मोठे चमचे | Oil 3 tbsp \n • तेल तळण्यासाठी  | Oil for frying \nKadakani Recipe \n • First add milk and sugar together. Let sugar melt. \n • In a parat take semolina, maida and salt together and mix.\n • Now add oil mohan to the maida.\n • Mix well. \n • Knead tight dough with using sugar milk. Cover and keep for 2 hours. \n • Roll to make thin layer kadakani and fry this till it gets light golden colour.   \nOther Recipes \n2 महिने टिकणारा पान मुखवास | देवीचा आवडता तांबूल / पाचक, सोपा Paan Mukhvaas\nhttps://youtu.be/Wwg8hul1UoQ?si=AX3q8BlwX84TI1dj\n\nॲसिडीटी होणार नाही अशी हलकी फुलकी उपवासाची थाळी | आलू पराठा, राजगीरा खीर Upvas Thali saritaskitchen\nhttps://youtu.be/tlYTxLqUPN0?si=mbSmD7OKH0vtANOe\n\nउपवासाला वरईची दाटसर खीर | पचायला हलकी करायला सोपी रवाळ, दाटसर उपवासाची वरी तांदळाची खीर Upvas Khir\nhttps://youtu.be/o02iLP2Huc4?si=ena__fRHib2n7kXt\n\nवरईची भाकरी करताना या 2 चुका टाळा | जास्त वेळ मऊ राहणारी भगरीची भाकरी आणि उपवासाची भेंडी Upvas Thali\nhttps://youtu.be/s6MbjAcj-d0?si=Av617p5phzdGHIkT\n\nउपवासाची कढी भजी पोटाला थंडावा देणारी कढी आणि कुरकुरीत भजी navaratri special recipe / saritaskitchen\nhttps://youtu.be/YrBUzPTtAJA?si=tZMhY1sESb268Lyp\n\nमोकळा सुटसुटीत वरई भात व चटकदार उपवासाची शेंगदाणा आमटी माझ्या खास पद्धतीने व टिप्ससहित नवरात्री थाळ\nhttps://youtu.be/D-8Fm_zzN6g?si=GxeY8Rc3UxxOy2aM\n\nउपवासाचे थालीपीठ वातड होते?अशी बनवा भाजणी व वापरा या 2 टिप्स / Upvas Bhajni Thalipith saritaskitchen\nhttps://youtu.be/hg9J2vvUQog?si=AbPR85BXWzRAAR6j\n\n#कडाकणीरेसिपी #नवरात्रस्पेशल #गोडपुरी #दसरास्पेशलरेसिपी #सरितासकिचनमराठी #Kadakani #NavratraSpecial #SweetPuri #DasaaraSpecial #SaritasKitchenMarathi\n\nSecond Channel (SaritasHome N Lifestyle) – \nhttps://www.youtube.com/@saritashomenvlog\nFollow Us On Instagram - https://www.instagram.com/saritaskitchenofficial/\nFollow Us on FaceBook - https://www.facebook.com/people/Saritas-Kitchen/100053861679165/\nFor collaboration enquiries – saritaskitchen18@gmail.com",
        "thumbnails": {
          "default": {
            "url": "https://i.ytimg.com/vi/Lu1v8VFLDno/default.jpg",
            "width": 120,
            "height": 90
          },
          "medium": {
            "url": "https://i.ytimg.com/vi/Lu1v8VFLDno/mqdefault.jpg",
            "width": 320,
            "height": 180
          },
          "high": {
            "url": "https://i.ytimg.com/vi/Lu1v8VFLDno/hqdefault.jpg",
            "width": 480,
            "height": 360
          },
          "standard": {
            "url": "https://i.ytimg.com/vi/Lu1v8VFLDno/sddefault.jpg",
            "width": 640,
            "height": 480
          },
          "maxres": {
            "url": "https://i.ytimg.com/vi/Lu1v8VFLDno/maxresdefault.jpg",
            "width": 1280,
            "height": 720
          }
        },
        "channelTitle": "Sarita's Kitchen",
        "tags": [
          "कडाकणी",
          "कडाकणी रेसिपी",
          "पारंपरिक कडाकणी रेसिपी",
          "गव्हाच्या पिठाची कडकणी",
          "कुरकुरीत कडकणी",
          "महाराष्ट्रीयन कडाकणी रेसिपी",
          "नवरात्र स्पेशल रेसिपी",
          "उपवास थाळी",
          "साबुदाणा खिचडी रेसिपी",
          "साबुदाणा वडा रेसिपी",
          "उपवासाचे थालीपीठ रेसिपी",
          "उपवास डोसा रेसिपी",
          "kadakani",
          "khuskhushti kadakani recipe",
          "Navratra Special Recipe",
          "Kadakani Recipe Sarita",
          "Maida Kadakani Recipe",
          "Sabudana Khichadi Recipe",
          "Sabudana Vada Recipe",
          "Upvas Bhaji Bhakari Recipe",
          "Upvas Dosa Recipe",
          "kadakani recipe",
          "rava maida kadakni"
        ],
        "categoryId": "22",
        "liveBroadcastContent": "none",
        "localized": {
          "title": "खुसखुशीत कडाकणी | कडकणी मऊ व तेलकट न होण्यासाठी या 2 चुका टाळा | कुरकुरीत कडकणी Navratri Kadakani",
          "description": "सरिताज किचनची सर्व उत्पादने शुद्ध, पारंपरिक आणि केमिकल विरहित आहेत.\nसरिताज किचनचे प्रॉडक्ट्स | Saritas Kitchen Products -\n 1. सर्व प्रकारची लाकडी घाणा तेलं | All Types of Wood Pressed Oils\n 2. डंकावर कुटून केलेला कांदा लसूण मसाला | Handmade Kanda Lasun Masala\n 3. सरिताज किचन सेंद्रिय गुळ | Chemical free Jaggery cubes and powder \n 4. सेंधव मीठ | Pink Himalayan Salt\n 5. सेंद्रियहळद | Organic Turmeric\nऑर्डर करण्यासाठी | To Order -\n • Website - https://saritaskitchenofficial.com/\n • Amazon - http://bitly.ws/zDuc\n \nखुसखुशीत कडाकणी | कडकणी मऊ व तेलकट न होण्यासाठी या 2 चुका टाळा | कुरकुरीत कडकणी Navratri Kadakani\nकडाकणी \nकडाकणी रेसिपी | नवरात्र स्पेशल रेसिपी | दसरा सणानिमित्त खास रेसिपी  | सप्तमी खास कडाकणी माळ रेसिपी | खुसखुशीत व कुरकुरीत कडाकणी रेसिपी | पारंपरिक रेसिपी |  महाराष्ट्रीयन कडाकणी रेसिपी | कडाकणी रेसिपी मराठी | गोड पुरी रेसिपी | kadakani Recipe | Navratra Special Recipe | Sapatami Special Mal Recipe | Dasara Special Recipe | Crispy and Crunchy Kadakani Recipe | Tradational Recipe | Maharashtrian Kadakani Recipe | Kadakani REcipe Marathi | Sweet Puri Recipe | \nसाहित्य | Ingredients \n • मैदा २ कप | Maida 2 cup \n • बारीक रवा १/२ कप | Fine Semolina ½ cup \n • पिठी साखर ३/४ कप | Sugar Powder ¾ cup  \n • दूध ३/४ कप | Milk ½ cup \n • मीठ २ चिमूट | Salt 2 pinch \n • तेल २ मोठे चमचे | Oil 3 tbsp \n • तेल तळण्यासाठी  | Oil for frying \nKadakani Recipe \n • First add milk and sugar together. Let sugar melt. \n • In a parat take semolina, maida and salt together and mix.\n • Now add oil mohan to the maida.\n • Mix well. \n • Knead tight dough with using sugar milk. Cover and keep for 2 hours. \n • Roll to make thin layer kadakani and fry this till it gets light golden colour.   \nOther Recipes \n2 महिने टिकणारा पान मुखवास | देवीचा आवडता तांबूल / पाचक, सोपा Paan Mukhvaas\nhttps://youtu.be/Wwg8hul1UoQ?si=AX3q8BlwX84TI1dj\n\nॲसिडीटी होणार नाही अशी हलकी फुलकी उपवासाची थाळी | आलू पराठा, राजगीरा खीर Upvas Thali saritaskitchen\nhttps://youtu.be/tlYTxLqUPN0?si=mbSmD7OKH0vtANOe\n\nउपवासाला वरईची दाटसर खीर | पचायला हलकी करायला सोपी रवाळ, दाटसर उपवासाची वरी तांदळाची खीर Upvas Khir\nhttps://youtu.be/o02iLP2Huc4?si=ena__fRHib2n7kXt\n\nवरईची भाकरी करताना या 2 चुका टाळा | जास्त वेळ मऊ राहणारी भगरीची भाकरी आणि उपवासाची भेंडी Upvas Thali\nhttps://youtu.be/s6MbjAcj-d0?si=Av617p5phzdGHIkT\n\nउपवासाची कढी भजी पोटाला थंडावा देणारी कढी आणि कुरकुरीत भजी navaratri special recipe / saritaskitchen\nhttps://youtu.be/YrBUzPTtAJA?si=tZMhY1sESb268Lyp\n\nमोकळा सुटसुटीत वरई भात व चटकदार उपवासाची शेंगदाणा आमटी माझ्या खास पद्धतीने व टिप्ससहित नवरात्री थाळ\nhttps://youtu.be/D-8Fm_zzN6g?si=GxeY8Rc3UxxOy2aM\n\nउपवासाचे थालीपीठ वातड होते?अशी बनवा भाजणी व वापरा या 2 टिप्स / Upvas Bhajni Thalipith saritaskitchen\nhttps://youtu.be/hg9J2vvUQog?si=AbPR85BXWzRAAR6j\n\n#कडाकणीरेसिपी #नवरात्रस्पेशल #गोडपुरी #दसरास्पेशलरेसिपी #सरितासकिचनमराठी #Kadakani #NavratraSpecial #SweetPuri #DasaaraSpecial #SaritasKitchenMarathi\n\nSecond Channel (SaritasHome N Lifestyle) – \nhttps://www.youtube.com/@saritashomenvlog\nFollow Us On Instagram - https://www.instagram.com/saritaskitchenofficial/\nFollow Us on FaceBook - https://www.facebook.com/people/Saritas-Kitchen/100053861679165/\nFor collaboration enquiries – saritaskitchen18@gmail.com"
        },
        "defaultAudioLanguage": "mr"
      },
      "contentDetails": {
        "duration": "PT10M58S",
        "dimension": "2d",
        "definition": "hd",
        "caption": "false",
        "licensedContent": true,
        "contentRating": {
          
        },
        "projection": "rectangular"
      },
      "statistics": {
        "viewCount": "333166",
        "likeCount": "4341",
        "favoriteCount": "0",
        "commentCount": "651"
      }
    },
    {
      "kind": "youtube#video",
      "etag": "tZoldfQg21FZmHe8MEptqAIGNNU",
      "id": "Ft1S969s-cM",
      "snippet": {
        "publishedAt": "2023-10-20T04:35:00Z",
        "channelId": "UC2ziCMHFPWkFHjocUMXT__Q",
        "title": "செல் ஒலிபரப்பு எச்சரிக்கை சோதனை... மக்கள் அஞ்ச வேண்டாம் #govtalert #phone #govtupdate",
        "description": "செல் ஒலிபரப்பு எச்சரிக்கை சோதனை... மக்கள் அஞ்ச வேண்டாம் #govtalert #phone #govtupdate \n\n#Leo | #Vijay | #Trisha | #Anirudh | #LokeshKanagaraj | #LeoReview | #INDvs3BAN | #PMMementosAuction2023 | #LeoFDFS | #SanjayDutt | #Arjun | #NivinPauly | #Mysskin | #GauthamVasudev\n#ADMK | #BJP | #EPS | #EdapadiPalaniswamy | #PModi | #NarendraModi | #Annamalai | #CMStalin | #TNGovt | #DMK | #IndiaCongress | #Congress | #RahulGandhi |   #OPS | #OPanneerSelvam | #Seeman | #NTK | #NaamTamilarKatchi | #TTVDhinakaran | #UdhayanidhiStalin | #Chennai | #TNRain | #Rainfall | #Weather | #GoldRate | #PetrolPrice | #ShareMarket | #TamilNadu \n\nSathiyam TV News is streaming for 24x7 that tends to bring you all the updates on Latest News and Breaking News happening in and out of Tamil Nadu. \n\n#sathiyamnews #sathiyamtv​ #sathiyamnewslive ​ #tamilnews​ #tamilnewslive​ #livenewstamil​​​ #livenews​ #sathiyamlivenews​ #nationalpolitics #nationalnews | #newsupdates | #breakingnews | #trendingnews | #dailyinstantnews | #Trending | #ViralVideos | #Breaking | #Sports | #District | #DistrictNews | #WorldNews | #Exclusive\n\nSubscribe digital Channel - https://www.youtube.com/channel/UCJk8bxxNqSByAXMIcOrLuPg/featured\n\nSubscribe News Channel - https://bit.ly/2YlKFPW \nTo get daily updates of Sathiyam TV in Whatsapp, Click & Join using below link:  https://chat.whatsapp.com/L8Dof5Qzd7iCiJhfvLSz45\n\nAndroid App :\nhttps://play.google.com/store/apps/details?id=com.sathiyamtv\n\n iOS App\nhttps://apps.apple.com/in/app/sathiyam-tv-tamil-news/id1445003340\n\nYou Can also follow us @\nFacebook: https://www.fb.com/SathiyamNEWS \nTwitter: https://twitter.com/SathiyamNEWS\nWebsite:  https://sathiyam.tv\nInstagram:  https://www.instagram.com/sathiyamtv/",
        "thumbnails": {
          "default": {
            "url": "https://i.ytimg.com/vi/Ft1S969s-cM/default.jpg",
            "width": 120,
            "height": 90
          },
          "medium": {
            "url": "https://i.ytimg.com/vi/Ft1S969s-cM/mqdefault.jpg",
            "width": 320,
            "height": 180
          },
          "high": {
            "url": "https://i.ytimg.com/vi/Ft1S969s-cM/hqdefault.jpg",
            "width": 480,
            "height": 360
          },
          "standard": {
            "url": "https://i.ytimg.com/vi/Ft1S969s-cM/sddefault.jpg",
            "width": 640,
            "height": 480
          },
          "maxres": {
            "url": "https://i.ytimg.com/vi/Ft1S969s-cM/maxresdefault.jpg",
            "width": 1280,
            "height": 720
          }
        },
        "channelTitle": "Sathiyam News",
        "tags": [
          "தலைப்புச் செய்திகள்",
          "Today Headlines in Tamil",
          "tamil News",
          "tamil Live News",
          "Live News",
          "Live News in Tamil",
          "Sathiyam News",
          "Sathiyam Live News",
          "Trending News",
          "Latest Tamil News",
          "Sathiyam TV Live",
          "Live Sathiyam TV",
          "today headlines news in Tamil",
          "today tamil news",
          "sathiyam tv",
          "Mk Stalin",
          "Pm Modi",
          "Petrol Diesel Price",
          "Rainfall",
          "AIADMK",
          "EPS",
          "CSK",
          "CM Stalin",
          "MS Dhoni",
          "NerukkuNer",
          "Rahul gandhi",
          "politics",
          "Sathiyam news",
          "news update",
          "today news",
          "sathiyam update news",
          "#today incident"
        ],
        "categoryId": "25",
        "liveBroadcastContent": "none",
        "defaultLanguage": "ta",
        "localized": {
          "title": "செல் ஒலிபரப்பு எச்சரிக்கை சோதனை... மக்கள் அஞ்ச வேண்டாம் #govtalert #phone #govtupdate",
          "description": "செல் ஒலிபரப்பு எச்சரிக்கை சோதனை... மக்கள் அஞ்ச வேண்டாம் #govtalert #phone #govtupdate \n\n#Leo | #Vijay | #Trisha | #Anirudh | #LokeshKanagaraj | #LeoReview | #INDvs3BAN | #PMMementosAuction2023 | #LeoFDFS | #SanjayDutt | #Arjun | #NivinPauly | #Mysskin | #GauthamVasudev\n#ADMK | #BJP | #EPS | #EdapadiPalaniswamy | #PModi | #NarendraModi | #Annamalai | #CMStalin | #TNGovt | #DMK | #IndiaCongress | #Congress | #RahulGandhi |   #OPS | #OPanneerSelvam | #Seeman | #NTK | #NaamTamilarKatchi | #TTVDhinakaran | #UdhayanidhiStalin | #Chennai | #TNRain | #Rainfall | #Weather | #GoldRate | #PetrolPrice | #ShareMarket | #TamilNadu \n\nSathiyam TV News is streaming for 24x7 that tends to bring you all the updates on Latest News and Breaking News happening in and out of Tamil Nadu. \n\n#sathiyamnews #sathiyamtv​ #sathiyamnewslive ​ #tamilnews​ #tamilnewslive​ #livenewstamil​​​ #livenews​ #sathiyamlivenews​ #nationalpolitics #nationalnews | #newsupdates | #breakingnews | #trendingnews | #dailyinstantnews | #Trending | #ViralVideos | #Breaking | #Sports | #District | #DistrictNews | #WorldNews | #Exclusive\n\nSubscribe digital Channel - https://www.youtube.com/channel/UCJk8bxxNqSByAXMIcOrLuPg/featured\n\nSubscribe News Channel - https://bit.ly/2YlKFPW \nTo get daily updates of Sathiyam TV in Whatsapp, Click & Join using below link:  https://chat.whatsapp.com/L8Dof5Qzd7iCiJhfvLSz45\n\nAndroid App :\nhttps://play.google.com/store/apps/details?id=com.sathiyamtv\n\n iOS App\nhttps://apps.apple.com/in/app/sathiyam-tv-tamil-news/id1445003340\n\nYou Can also follow us @\nFacebook: https://www.fb.com/SathiyamNEWS \nTwitter: https://twitter.com/SathiyamNEWS\nWebsite:  https://sathiyam.tv\nInstagram:  https://www.instagram.com/sathiyamtv/"
        },
        "defaultAudioLanguage": "ta"
      },
      "contentDetails": {
        "duration": "PT43S",
        "dimension": "2d",
        "definition": "hd",
        "caption": "false",
        "licensedContent": true,
        "contentRating": {
          
        },
        "projection": "rectangular"
      },
      "statistics": {
        "viewCount": "415038",
        "likeCount": "3613",
        "favoriteCount": "0",
        "commentCount": "587"
      }
    },
    {
      "kind": "youtube#video",
      "etag": "kyp31yp7KZaTTEfCjYSt2XhsfN8",
      "id": "GBXnI13wEvY",
      "snippet": {
        "publishedAt": "2023-10-20T03:11:10Z",
        "channelId": "UCXsCPmJi7RZFjpS-RmYgn_Q",
        "title": "దుబాయ్ కి వచ్చినం-1 Dubai lo Lolli | Dubai frame & Shopping | AnilGeela | Gangavva | My village show",
        "description": "follow me on instagram - @myvillageshow_anil\r\nhttps://instagram.com/myvillageshow_anil?igshid=10hx4jg6bdreb \n \nfor Brands and Promotions contact to the mail \n: anilkuamargeela333@gmail.com",
        "thumbnails": {
          "default": {
            "url": "https://i.ytimg.com/vi/GBXnI13wEvY/default.jpg",
            "width": 120,
            "height": 90
          },
          "medium": {
            "url": "https://i.ytimg.com/vi/GBXnI13wEvY/mqdefault.jpg",
            "width": 320,
            "height": 180
          },
          "high": {
            "url": "https://i.ytimg.com/vi/GBXnI13wEvY/hqdefault.jpg",
            "width": 480,
            "height": 360
          },
          "standard": {
            "url": "https://i.ytimg.com/vi/GBXnI13wEvY/sddefault.jpg",
            "width": 640,
            "height": 480
          },
          "maxres": {
            "url": "https://i.ytimg.com/vi/GBXnI13wEvY/maxresdefault.jpg",
            "width": 1280,
            "height": 720
          }
        },
        "channelTitle": "Anil Geela Vlogs",
        "categoryId": "24",
        "liveBroadcastContent": "none",
        "localized": {
          "title": "దుబాయ్ కి వచ్చినం-1 Dubai lo Lolli | Dubai frame & Shopping | AnilGeela | Gangavva | My village show",
          "description": "follow me on instagram - @myvillageshow_anil\r\nhttps://instagram.com/myvillageshow_anil?igshid=10hx4jg6bdreb \n \nfor Brands and Promotions contact to the mail \n: anilkuamargeela333@gmail.com"
        },
        "defaultAudioLanguage": "te"
      },
      "contentDetails": {
        "duration": "PT16M4S",
        "dimension": "2d",
        "definition": "hd",
        "caption": "false",
        "licensedContent": true,
        "contentRating": {
          
        },
        "projection": "rectangular"
      },
      "statistics": {
        "viewCount": "212811",
        "likeCount": "8663",
        "favoriteCount": "0",
        "commentCount": "349"
      }
    },
    {
      "kind": "youtube#video",
      "etag": "kffyKe0jvrjG9TZ1rcXEB5XbomA",
      "id": "13Ag4Z-nnjc",
      "snippet": {
        "publishedAt": "2023-10-19T15:28:44Z",
        "channelId": "UCY6KjrDBN_tIRFT_QNqQbRQ",
        "title": "Leo 😭 or 🔥 R̶E̶V̶I̶E̶W̶ | Madan Gowri | MG | LEO movie Review | Trailer| Songs",
        "description": "LEO , a most awaited Tamil movie of this year from Thalapathi Vijay, directed by Lokesh kanagaraj and Music by Anirudh Ravichander. In this Video Madan Gowri shares about his point of view and gives his genuine review about LEO movie. You people don't worry , it is not a spoiler. Go and watch LEO in theaters to see if its coming under LCU or not.\n\n-------------\n📧 For Business and Interviews : work.madangowri@outlook.com\n-------------\n📸 📚 Madan Gowri’s Gadgets and Books: https://www.amazon.in/shop/madangowri\n-------------\n🖖 Join Special Madan Gowri’s MG Squad: https://www.youtube.com/channel/UCY6KjrDBN_tIRFT_QNqQbRQ/join\n\n \nContent Researchers: Arthi Rajadurai , Bharani\nEdit : Satheesh Gopi",
        "thumbnails": {
          "default": {
            "url": "https://i.ytimg.com/vi/13Ag4Z-nnjc/default.jpg",
            "width": 120,
            "height": 90
          },
          "medium": {
            "url": "https://i.ytimg.com/vi/13Ag4Z-nnjc/mqdefault.jpg",
            "width": 320,
            "height": 180
          },
          "high": {
            "url": "https://i.ytimg.com/vi/13Ag4Z-nnjc/hqdefault.jpg",
            "width": 480,
            "height": 360
          },
          "standard": {
            "url": "https://i.ytimg.com/vi/13Ag4Z-nnjc/sddefault.jpg",
            "width": 640,
            "height": 480
          },
          "maxres": {
            "url": "https://i.ytimg.com/vi/13Ag4Z-nnjc/maxresdefault.jpg",
            "width": 1280,
            "height": 720
          }
        },
        "channelTitle": "Madan Gowri",
        "tags": [
          "LEO",
          "leo",
          "thalapathy",
          "vj",
          "vijay",
          "madan",
          "madan gowri",
          "madan kowri",
          "mathan kowri",
          "mathan",
          "tamil nadu",
          "chennai",
          "bangalore",
          "hyderabad",
          "kochi",
          "news",
          "news today",
          "mgsquad",
          "madurai",
          "explained",
          "knowledge",
          "information",
          "movie",
          "moviebuzz",
          "LCU",
          "Lokesh",
          "Vikram",
          "harold das",
          "Blockbuster",
          "flop",
          "trisha",
          "Spoiler",
          "Sandy master leo",
          "leo reaction",
          "leo experience",
          "Anirudh",
          "Arjun",
          "leo kerala",
          "leo opening",
          "leo review",
          "fdfs",
          "review",
          "leo theatre response",
          "Lokesh Kanagaraj",
          "Anirudh BGM",
          "Vijay songs",
          "Badass"
        ],
        "categoryId": "27",
        "liveBroadcastContent": "none",
        "defaultLanguage": "en",
        "localized": {
          "title": "Leo 😭 or 🔥 R̶E̶V̶I̶E̶W̶ | Madan Gowri | MG | LEO movie Review | Trailer| Songs",
          "description": "LEO , a most awaited Tamil movie of this year from Thalapathi Vijay, directed by Lokesh kanagaraj and Music by Anirudh Ravichander. In this Video Madan Gowri shares about his point of view and gives his genuine review about LEO movie. You people don't worry , it is not a spoiler. Go and watch LEO in theaters to see if its coming under LCU or not.\n\n-------------\n📧 For Business and Interviews : work.madangowri@outlook.com\n-------------\n📸 📚 Madan Gowri’s Gadgets and Books: https://www.amazon.in/shop/madangowri\n-------------\n🖖 Join Special Madan Gowri’s MG Squad: https://www.youtube.com/channel/UCY6KjrDBN_tIRFT_QNqQbRQ/join\n\n \nContent Researchers: Arthi Rajadurai , Bharani\nEdit : Satheesh Gopi"
        },
        "defaultAudioLanguage": "ta"
      },
      "contentDetails": {
        "duration": "PT15M43S",
        "dimension": "2d",
        "definition": "hd",
        "caption": "false",
        "licensedContent": true,
        "contentRating": {
          
        },
        "projection": "rectangular"
      },
      "statistics": {
        "viewCount": "855017",
        "likeCount": "50224",
        "favoriteCount": "0",
        "commentCount": "2354"
      }
    },
    {
      "kind": "youtube#video",
      "etag": "rjaPOJZR5hBbtTU-jeBdTH0JhMM",
      "id": "6vPoge14ZFQ",
      "snippet": {
        "publishedAt": "2023-10-20T05:28:38Z",
        "channelId": "UCLNItyVW0epTrMVA3DxQglg",
        "title": "A New Fight In Bigg Boss House",
        "description": "Vicky ke action ne kiya Neil ko angry. Will this fight create a war in the Bigg Boss house? 😱\n\nDekhiye #BiggBoss17, Mon-Fri 10PM & Sat-Sun 9PM sirf #Colors aur #JioCinema  par.\n\n#BB17 #BiggBoss\n#SalmanKhan\n\n#NeilBhatt\n#VickyJain\n\nSubscribe to Colors TV: http://www.youtube.com/user/colorstv?sub_confirmation=1\r\n\r\nFollow us on Google+: https://plus.google.com/+colorstv\r\nFollow us on Facebook: https://www.facebook.com/ColorsTV\r\nFollow us on Twitter: https://twitter.com/ColorsTV",
        "thumbnails": {
          "default": {
            "url": "https://i.ytimg.com/vi/6vPoge14ZFQ/default.jpg",
            "width": 120,
            "height": 90
          },
          "medium": {
            "url": "https://i.ytimg.com/vi/6vPoge14ZFQ/mqdefault.jpg",
            "width": 320,
            "height": 180
          },
          "high": {
            "url": "https://i.ytimg.com/vi/6vPoge14ZFQ/hqdefault.jpg",
            "width": 480,
            "height": 360
          },
          "standard": {
            "url": "https://i.ytimg.com/vi/6vPoge14ZFQ/sddefault.jpg",
            "width": 640,
            "height": 480
          },
          "maxres": {
            "url": "https://i.ytimg.com/vi/6vPoge14ZFQ/maxresdefault.jpg",
            "width": 1280,
            "height": 720
          }
        },
        "channelTitle": "Colors",
        "tags": [
          "colors tv",
          "colorstv",
          "hindi serials"
        ],
        "categoryId": "24",
        "liveBroadcastContent": "none",
        "localized": {
          "title": "A New Fight In Bigg Boss House",
          "description": "Vicky ke action ne kiya Neil ko angry. Will this fight create a war in the Bigg Boss house? 😱\n\nDekhiye #BiggBoss17, Mon-Fri 10PM & Sat-Sun 9PM sirf #Colors aur #JioCinema  par.\n\n#BB17 #BiggBoss\n#SalmanKhan\n\n#NeilBhatt\n#VickyJain\n\nSubscribe to Colors TV: http://www.youtube.com/user/colorstv?sub_confirmation=1\r\n\r\nFollow us on Google+: https://plus.google.com/+colorstv\r\nFollow us on Facebook: https://www.facebook.com/ColorsTV\r\nFollow us on Twitter: https://twitter.com/ColorsTV"
        },
        "defaultAudioLanguage": "hi"
      },
      "contentDetails": {
        "duration": "PT30S",
        "dimension": "2d",
        "definition": "hd",
        "caption": "false",
        "licensedContent": false,
        "contentRating": {
          
        },
        "projection": "rectangular"
      },
      "statistics": {
        "viewCount": "753158",
        "likeCount": "8870",
        "favoriteCount": "0",
        "commentCount": "697"
      }
    },
    {
      "kind": "youtube#video",
      "etag": "nk2JPFsGP3wfPiXev8RAvZVqTTE",
      "id": "cjKWHY0S6Tc",
      "snippet": {
        "publishedAt": "2023-10-18T17:30:07Z",
        "channelId": "UCoY_p16GEbOQPgES1-wXpYg",
        "title": "Dhee Premier League | 11th October 2023 | Hyper Aadi, Deepika Pilli,Sekhar Master |Full Episode",
        "description": "#dheepremierleague #dhee #etvdhee #premierleague #telugudanceshow #telugushow #etvtelugu #etvwin #danceshow #ultimatedance #realityshow #pradeepmachiraju #poorna #shekarmaster #hyperaadi\n\nDhee Premier League is a power-packed dance show, where contestants represent their native places in Telugu states and compete to win the most prestigious Dhee title.\n\nTo watch your ETV all channel’s programmes any where any time Download ETV Win App for both Android & IOS: https://f66tr.app.goo.gl/apps\n\n►Visit Website : http://etv.co.in\n\n► Like us on Facebook : https://www.facebook.com/etvwin\n► Follow us on Instagram : https://www.instagram.com/etvwin/\n► Follow us on Twitter : https://twitter.com/etvwin \n► Visit Website : https://www.etvwin.com/\n► Pin us on Pinterest: https://in.pinterest.com/etv_win/\n\nETV Telugu(Youtube) - http://bit.ly/2QR0yu9  \nETV Jabardasth(Youtube) - http://bit.ly/35xdqtu\nETV Dhee(Youtube) - http://bit.ly/2Ok8zWF\nETV Plus India(Youtube) - http://bit.ly/2OlEAOg\nETV Abhiruchi(Youtube) - http://bit.ly/2OkEtTb\nETV Life(Youtube) - http://bit.ly/2OiKAY6\nETV Telangana(Youtube) - http://bit.ly/33nRaAK\nETV Andhra Pradesh(Youtube) - http://bit.ly/2OKARZz\nETV Annadata(Youtube) - https://bit.ly/3BeZXXS\n\nETV Telugu Facebook - http://bit.ly/2L2GYYh\nETV Plus India Facebook - http://bit.ly/2DudC0t\nETV Abhiruchi Facebook - http://bit.ly/2OSrIhv\nETV Life Facebook - http://bit.ly/34tiqzk\nETV Telangana Facebook - http://bit.ly/37GkVQF\nETV Andhra Pradesh Facebook - http://bit.ly/2R0vs3k\nETV Annadata Facebook - https://bit.ly/3kGnkEb",
        "thumbnails": {
          "default": {
            "url": "https://i.ytimg.com/vi/cjKWHY0S6Tc/default.jpg",
            "width": 120,
            "height": 90
          },
          "medium": {
            "url": "https://i.ytimg.com/vi/cjKWHY0S6Tc/mqdefault.jpg",
            "width": 320,
            "height": 180
          },
          "high": {
            "url": "https://i.ytimg.com/vi/cjKWHY0S6Tc/hqdefault.jpg",
            "width": 480,
            "height": 360
          },
          "standard": {
            "url": "https://i.ytimg.com/vi/cjKWHY0S6Tc/sddefault.jpg",
            "width": 640,
            "height": 480
          },
          "maxres": {
            "url": "https://i.ytimg.com/vi/cjKWHY0S6Tc/maxresdefault.jpg",
            "width": 1280,
            "height": 720
          }
        },
        "channelTitle": "ETV Dhee",
        "tags": [
          "etv dhee 16",
          "dhee premier league",
          "premier league",
          "dhee 16 etv",
          "dhee show",
          "dhee 16 dance show",
          "etv shows",
          "etv telugu",
          "etv win",
          "dhee new season",
          "ultimate dance show",
          "reality dance show",
          "reality show",
          "dhee 16 etv show",
          "Pradeep Machiraju",
          "sekhar master",
          "hyper aadi",
          "deepika pilli",
          "Bezawada Tigers Team",
          "nellore nerajanalu team",
          "hyderabad ustads team",
          "orugallu veerulu team",
          "dhee premier league full episode",
          "dhee premier league latest episode"
        ],
        "categoryId": "24",
        "liveBroadcastContent": "none",
        "defaultLanguage": "en",
        "localized": {
          "title": "Dhee Premier League | 11th October 2023 | Hyper Aadi, Deepika Pilli,Sekhar Master |Full Episode",
          "description": "#dheepremierleague #dhee #etvdhee #premierleague #telugudanceshow #telugushow #etvtelugu #etvwin #danceshow #ultimatedance #realityshow #pradeepmachiraju #poorna #shekarmaster #hyperaadi\n\nDhee Premier League is a power-packed dance show, where contestants represent their native places in Telugu states and compete to win the most prestigious Dhee title.\n\nTo watch your ETV all channel’s programmes any where any time Download ETV Win App for both Android & IOS: https://f66tr.app.goo.gl/apps\n\n►Visit Website : http://etv.co.in\n\n► Like us on Facebook : https://www.facebook.com/etvwin\n► Follow us on Instagram : https://www.instagram.com/etvwin/\n► Follow us on Twitter : https://twitter.com/etvwin \n► Visit Website : https://www.etvwin.com/\n► Pin us on Pinterest: https://in.pinterest.com/etv_win/\n\nETV Telugu(Youtube) - http://bit.ly/2QR0yu9  \nETV Jabardasth(Youtube) - http://bit.ly/35xdqtu\nETV Dhee(Youtube) - http://bit.ly/2Ok8zWF\nETV Plus India(Youtube) - http://bit.ly/2OlEAOg\nETV Abhiruchi(Youtube) - http://bit.ly/2OkEtTb\nETV Life(Youtube) - http://bit.ly/2OiKAY6\nETV Telangana(Youtube) - http://bit.ly/33nRaAK\nETV Andhra Pradesh(Youtube) - http://bit.ly/2OKARZz\nETV Annadata(Youtube) - https://bit.ly/3BeZXXS\n\nETV Telugu Facebook - http://bit.ly/2L2GYYh\nETV Plus India Facebook - http://bit.ly/2DudC0t\nETV Abhiruchi Facebook - http://bit.ly/2OSrIhv\nETV Life Facebook - http://bit.ly/34tiqzk\nETV Telangana Facebook - http://bit.ly/37GkVQF\nETV Andhra Pradesh Facebook - http://bit.ly/2R0vs3k\nETV Annadata Facebook - https://bit.ly/3kGnkEb"
        },
        "defaultAudioLanguage": "te"
      },
      "contentDetails": {
        "duration": "PT45M54S",
        "dimension": "2d",
        "definition": "hd",
        "caption": "false",
        "licensedContent": true,
        "contentRating": {
          
        },
        "projection": "rectangular"
      },
      "statistics": {
        "viewCount": "1292312",
        "likeCount": "31355",
        "favoriteCount": "0",
        "commentCount": "380"
      }
    },
    {
      "kind": "youtube#video",
      "etag": "UXxTLHBTK_OFfYQGa3t_YUpO2co",
      "id": "qO0hErep9Lg",
      "snippet": {
        "publishedAt": "2023-10-20T01:30:07Z",
        "channelId": "UC0J8BQahplvTY6LjlnLf_NQ",
        "title": "#Video | Kismat Sawar Le | Neelkamal Singh | किस्मत सवार लS | Priyanka Singh | Bhojpuri Devi Geet",
        "description": "नवरात्रि के प्यारे त्योहार को और भी ख़ास बनाने के लिए, \"किस्मत सवार लS\" ये देवी गीत सुनिए केवल  @SaregamaHumBhojpuri पर !!!!!  \n\nSubscribe to our channel for more Bhojpuri Songs:\nhttps://youtube.com/c/SaregamaHumBhojpuri\n\nCredits:\nSong:  Kismat Sawar La\nSinger - Neelkamal Singh and Priyanka Singh \nFeat - Seema Singh\nLyrics - Ashutosh Tiwari\nMusic - Priyanshu Singh\nDirector And Choreographer- Lakkie Vishwakarma \nAssistant Choreographer- Ashu And Suresh \nDop- Yogesh Singh \nEditor- LL Video Lab (Lavkesh Vishwakarma)\nDi - Rohit \nProduction- Amit And Aayush\n\nLyrics:\nMukhada:- \n\nMale:- Kismat sawar la Diya Baati Baar la,\nAili devi maai chala aarti utaar la...2\nJalwa gira ke tu ta paunwa pakhaar la ho, Paunwa pakhaar la,\nKismat sawar la Diya Baati Baar la,\nAili devi maai chala aarti utaar la...2\n\nAntara:- 1\n\nFemale:-Ho.... Lale sindur laale bindi laale chudi lawa ho, Laale chudi lawa,\nHo....Malin Sanghe milke Mori Maiya ke sajawa ho, Maiya ke sajawa...\nLale sindur laale bindi laale chudi lawa ho, Laale chudi lawa,\nHo....Malin Sanghe milke Mori Maiya ke sajawa ho, Maiya ke sajawa...\nMale:- Maiya khatir achara se rahiya bahar la ho, Rahiya bahar la...\nChunari ohaar la soharo singaar la, Aili devi maai chala aarti utaar la..\nKismat sawar la Diya Baati Baar la,\nAili devi maai chala aarti utaar la...2\n\nAnatar:- 2\n\nFemale:- Ho... Sevka ghare newta kare aili mahatari ho aili mahatari,\nHo... Neelkamal Ashu 9 din karihein sevadaari ho, Karihein sevadaari...\nSevka ghare newta kare aili mahatari ho aili mahatari,\nHo... Neelkamal Ashu 9 din karihein sevadaari ho, Karihein sevadaari...\nMale:- Laale laale taja odhulwa ke haar la, hulwa ke haar la,\nDudhwa ke dhaar la, chhak lawang dhaar la,\nAili devi maai chala aarti utaar la..\nKismat sawar la Diya Baati Baar la,\nAili devi maai chala aarti utaar la...2\n\n#kismatsawarla\n#neelkamalsingh   \n#saregamahumbhojpuri  \n#devigeet \n#bhojpuridevigeet\n#neelkamalsinghbhojpurisong \n#neelkamalsinghkegana \n\nख़रीदिए कारवाँ मोबाइल- 1500 प्रीलोडिड गानों वाला कीपैड फ़ोन धमाकेदार साउंड के साथ \nhttp://sarega.ma/ycmbuy\n\nSubscribe to our channel for more Bhojpuri Songs:\nhttps://youtube.com/c/SaregamaHumBhojpuri\n\nFollow us on:\nFacebook: https://bit.ly/3FxwPgo \nInstagram: https://bit.ly/32rkJqM\nTwitter: @saregamaglobal \n\nLabel:: Saregama India Limited, A RPSG Group Company",
        "thumbnails": {
          "default": {
            "url": "https://i.ytimg.com/vi/qO0hErep9Lg/default.jpg",
            "width": 120,
            "height": 90
          },
          "medium": {
            "url": "https://i.ytimg.com/vi/qO0hErep9Lg/mqdefault.jpg",
            "width": 320,
            "height": 180
          },
          "high": {
            "url": "https://i.ytimg.com/vi/qO0hErep9Lg/hqdefault.jpg",
            "width": 480,
            "height": 360
          },
          "standard": {
            "url": "https://i.ytimg.com/vi/qO0hErep9Lg/sddefault.jpg",
            "width": 640,
            "height": 480
          },
          "maxres": {
            "url": "https://i.ytimg.com/vi/qO0hErep9Lg/maxresdefault.jpg",
            "width": 1280,
            "height": 720
          }
        },
        "channelTitle": "Saregama Hum Bhojpuri",
        "tags": [
          "kismat sawar la",
          "neelkamal singh",
          "neelkamal singh bhojpuri song",
          "neelkamal singh new song",
          "neelkamal singh song 2023",
          "neelkamal singh new song 2023",
          "neelkamal singh bhojpuri song new",
          "neelkamal singh devi geet",
          "neelkamal singh devi geet new",
          "neelkamal singh devi geet 2023",
          "neelkamal singh devi geet song",
          "bhojpuri devi geet",
          "bhojpuri devi geet 2023",
          "devi ji ke bhojpuri gana",
          "system chalaweli maai",
          "priyanka singh",
          "priyanka singh bhojpuri song",
          "devi song whatsapp status"
        ],
        "categoryId": "10",
        "liveBroadcastContent": "none",
        "localized": {
          "title": "#Video | Kismat Sawar Le | Neelkamal Singh | किस्मत सवार लS | Priyanka Singh | Bhojpuri Devi Geet",
          "description": "नवरात्रि के प्यारे त्योहार को और भी ख़ास बनाने के लिए, \"किस्मत सवार लS\" ये देवी गीत सुनिए केवल  @SaregamaHumBhojpuri पर !!!!!  \n\nSubscribe to our channel for more Bhojpuri Songs:\nhttps://youtube.com/c/SaregamaHumBhojpuri\n\nCredits:\nSong:  Kismat Sawar La\nSinger - Neelkamal Singh and Priyanka Singh \nFeat - Seema Singh\nLyrics - Ashutosh Tiwari\nMusic - Priyanshu Singh\nDirector And Choreographer- Lakkie Vishwakarma \nAssistant Choreographer- Ashu And Suresh \nDop- Yogesh Singh \nEditor- LL Video Lab (Lavkesh Vishwakarma)\nDi - Rohit \nProduction- Amit And Aayush\n\nLyrics:\nMukhada:- \n\nMale:- Kismat sawar la Diya Baati Baar la,\nAili devi maai chala aarti utaar la...2\nJalwa gira ke tu ta paunwa pakhaar la ho, Paunwa pakhaar la,\nKismat sawar la Diya Baati Baar la,\nAili devi maai chala aarti utaar la...2\n\nAntara:- 1\n\nFemale:-Ho.... Lale sindur laale bindi laale chudi lawa ho, Laale chudi lawa,\nHo....Malin Sanghe milke Mori Maiya ke sajawa ho, Maiya ke sajawa...\nLale sindur laale bindi laale chudi lawa ho, Laale chudi lawa,\nHo....Malin Sanghe milke Mori Maiya ke sajawa ho, Maiya ke sajawa...\nMale:- Maiya khatir achara se rahiya bahar la ho, Rahiya bahar la...\nChunari ohaar la soharo singaar la, Aili devi maai chala aarti utaar la..\nKismat sawar la Diya Baati Baar la,\nAili devi maai chala aarti utaar la...2\n\nAnatar:- 2\n\nFemale:- Ho... Sevka ghare newta kare aili mahatari ho aili mahatari,\nHo... Neelkamal Ashu 9 din karihein sevadaari ho, Karihein sevadaari...\nSevka ghare newta kare aili mahatari ho aili mahatari,\nHo... Neelkamal Ashu 9 din karihein sevadaari ho, Karihein sevadaari...\nMale:- Laale laale taja odhulwa ke haar la, hulwa ke haar la,\nDudhwa ke dhaar la, chhak lawang dhaar la,\nAili devi maai chala aarti utaar la..\nKismat sawar la Diya Baati Baar la,\nAili devi maai chala aarti utaar la...2\n\n#kismatsawarla\n#neelkamalsingh   \n#saregamahumbhojpuri  \n#devigeet \n#bhojpuridevigeet\n#neelkamalsinghbhojpurisong \n#neelkamalsinghkegana \n\nख़रीदिए कारवाँ मोबाइल- 1500 प्रीलोडिड गानों वाला कीपैड फ़ोन धमाकेदार साउंड के साथ \nhttp://sarega.ma/ycmbuy\n\nSubscribe to our channel for more Bhojpuri Songs:\nhttps://youtube.com/c/SaregamaHumBhojpuri\n\nFollow us on:\nFacebook: https://bit.ly/3FxwPgo \nInstagram: https://bit.ly/32rkJqM\nTwitter: @saregamaglobal \n\nLabel:: Saregama India Limited, A RPSG Group Company"
        },
        "defaultAudioLanguage": "bh"
      },
      "contentDetails": {
        "duration": "PT4M10S",
        "dimension": "2d",
        "definition": "hd",
        "caption": "false",
        "licensedContent": true,
        "contentRating": {
          
        },
        "projection": "rectangular"
      },
      "statistics": {
        "viewCount": "996331",
        "likeCount": "16343",
        "favoriteCount": "0",
        "commentCount": "1415"
      }
    },
    {
      "kind": "youtube#video",
      "etag": "IhdhoxRv_JMwH4LHcsKrUl-JSzg",
      "id": "wJKasfDLjOI",
      "snippet": {
        "publishedAt": "2023-10-20T02:30:31Z",
        "channelId": "UCjvgGbPPn-FgYeguc5nxG4A",
        "title": "Car Race With Piyush 🤩",
        "description": "Follow me on Instagram- https://www.instagram.com/souravjoshivlogs/?hl=en\n \nI hope you enjoyed this video\n\nhit likes.\nAnd do subscribe to my channel\n\nThank you so much for watching\n\ngod bless you all.\nlots of  ❤️\n\n( For Collaboration - officialsouravjoshivlogs@gmail.com",
        "thumbnails": {
          "default": {
            "url": "https://i.ytimg.com/vi/wJKasfDLjOI/default.jpg",
            "width": 120,
            "height": 90
          },
          "medium": {
            "url": "https://i.ytimg.com/vi/wJKasfDLjOI/mqdefault.jpg",
            "width": 320,
            "height": 180
          },
          "high": {
            "url": "https://i.ytimg.com/vi/wJKasfDLjOI/hqdefault.jpg",
            "width": 480,
            "height": 360
          },
          "standard": {
            "url": "https://i.ytimg.com/vi/wJKasfDLjOI/sddefault.jpg",
            "width": 640,
            "height": 480
          },
          "maxres": {
            "url": "https://i.ytimg.com/vi/wJKasfDLjOI/maxresdefault.jpg",
            "width": 1280,
            "height": 720
          }
        },
        "channelTitle": "Sourav Joshi Vlogs",
        "tags": [
          "sourav joshi",
          "sourav joshi arts",
          "sourav joshi vlog",
          "vlog",
          "vlogs",
          "daily vlogs",
          "family vlogs",
          "travel videos",
          "travel vlogs",
          "south korea",
          "south korea vlogs",
          "pohh in korea",
          "piyush joshi",
          "piyush joshi vlogs",
          "birthday",
          "birthday vlog",
          "birthday surprise"
        ],
        "categoryId": "22",
        "liveBroadcastContent": "none",
        "localized": {
          "title": "Car Race With Piyush 🤩",
          "description": "Follow me on Instagram- https://www.instagram.com/souravjoshivlogs/?hl=en\n \nI hope you enjoyed this video\n\nhit likes.\nAnd do subscribe to my channel\n\nThank you so much for watching\n\ngod bless you all.\nlots of  ❤️\n\n( For Collaboration - officialsouravjoshivlogs@gmail.com"
        }
      },
      "contentDetails": {
        "duration": "PT11M8S",
        "dimension": "2d",
        "definition": "hd",
        "caption": "false",
        "licensedContent": true,
        "contentRating": {
          
        },
        "projection": "rectangular"
      },
      "statistics": {
        "viewCount": "3317879",
        "likeCount": "271264",
        "favoriteCount": "0",
        "commentCount": "4530"
      }
    },
    {
      "kind": "youtube#video",
      "etag": "LwGli-YBZp9p02saX4UbpNj5r_E",
      "id": "63s0sFwLZSg",
      "snippet": {
        "publishedAt": "2023-10-19T06:49:52Z",
        "channelId": "UCPmpyXciSmUXPwdTW_0mbGw",
        "title": "Kundali Bhagya: Palki-Shourya gets closer?; Srishti Gun Shot by Goons | SBB",
        "description": "Checkout the Latest Twist & Turns of the TV Show Kundali Bhagya Which Aired on Zee TV\n\n#saasbahuaurbetiyaan #sbb #atsbb #LuthraBrothers #ShauryaLuthra #RajveerLuthra #KundaliBhagya #ZeeTv #BaseerAli #ParasKalnawat\n\n----------------------------------------------------------------------------------------------------------------------------------------\n\nIf you like the video please press the thumbs-up button. Also, leave us your valuable feedback in the comments below. For the latest updates on Television News visit us at:  https://bit.ly/3X6E9Y5\n\nFree Subscribe: https://bit.ly/3X6E9Y5\nFollow Us On Instagram - https://www.instagram.com/atsbb/\nFollow Us on Twitter - https://twitter.com/ATSBB \nLike Us on Facebook - https://www.facebook.com/ATSBBOfficial\n\nThanks For Watching.",
        "thumbnails": {
          "default": {
            "url": "https://i.ytimg.com/vi/63s0sFwLZSg/default.jpg",
            "width": 120,
            "height": 90
          },
          "medium": {
            "url": "https://i.ytimg.com/vi/63s0sFwLZSg/mqdefault.jpg",
            "width": 320,
            "height": 180
          },
          "high": {
            "url": "https://i.ytimg.com/vi/63s0sFwLZSg/hqdefault.jpg",
            "width": 480,
            "height": 360
          },
          "standard": {
            "url": "https://i.ytimg.com/vi/63s0sFwLZSg/sddefault.jpg",
            "width": 640,
            "height": 480
          },
          "maxres": {
            "url": "https://i.ytimg.com/vi/63s0sFwLZSg/maxresdefault.jpg",
            "width": 1280,
            "height": 720
          }
        },
        "channelTitle": "Saas Bahu Aur Betiyaan",
        "tags": [
          "saas bahu beti",
          "saas bahu aur beti",
          "saas bahu aur betiyaan",
          "celeb interviews",
          "SBB",
          "Aaj Tak",
          "kundali bhagya aaj ka episode",
          "kumkum bhagya",
          "kundali bhagya leap",
          "kundali bhagya update",
          "kundali bhagya new episode",
          "kundali bhagya full episode",
          "kundali bhagya today episode",
          "kundali bhagya online episode",
          "kundali bhagya official promo",
          "kundali bhagya upcoming twist",
          "preeta in denger kundali bhagya",
          "kundali bhagya karan love preeta",
          "kundali bhagya actress offscreen"
        ],
        "categoryId": "24",
        "liveBroadcastContent": "none",
        "localized": {
          "title": "Kundali Bhagya: Palki-Shourya gets closer?; Srishti Gun Shot by Goons | SBB",
          "description": "Checkout the Latest Twist & Turns of the TV Show Kundali Bhagya Which Aired on Zee TV\n\n#saasbahuaurbetiyaan #sbb #atsbb #LuthraBrothers #ShauryaLuthra #RajveerLuthra #KundaliBhagya #ZeeTv #BaseerAli #ParasKalnawat\n\n----------------------------------------------------------------------------------------------------------------------------------------\n\nIf you like the video please press the thumbs-up button. Also, leave us your valuable feedback in the comments below. For the latest updates on Television News visit us at:  https://bit.ly/3X6E9Y5\n\nFree Subscribe: https://bit.ly/3X6E9Y5\nFollow Us On Instagram - https://www.instagram.com/atsbb/\nFollow Us on Twitter - https://twitter.com/ATSBB \nLike Us on Facebook - https://www.facebook.com/ATSBBOfficial\n\nThanks For Watching."
        },
        "defaultAudioLanguage": "hi"
      },
      "contentDetails": {
        "duration": "PT4M7S",
        "dimension": "2d",
        "definition": "hd",
        "caption": "false",
        "licensedContent": true,
        "contentRating": {
          
        },
        "projection": "rectangular"
      },
      "statistics": {
        "viewCount": "752416",
        "likeCount": "6399",
        "favoriteCount": "0",
        "commentCount": "796"
      }
    },
    {
      "kind": "youtube#video",
      "etag": "KPaa9oeoVXSxvyR-0htA2saomg0",
      "id": "VSRH7_22zzE",
      "snippet": {
        "publishedAt": "2023-10-19T09:47:42Z",
        "channelId": "UCz5OR1qz402ZdnH8wsjKHFQ",
        "title": "പൊന്നൂന്റെ പ്രസവം കഴിഞ്ഞു👩‍🍼👩‍🍼",
        "description": "",
        "thumbnails": {
          "default": {
            "url": "https://i.ytimg.com/vi/VSRH7_22zzE/default.jpg",
            "width": 120,
            "height": 90
          },
          "medium": {
            "url": "https://i.ytimg.com/vi/VSRH7_22zzE/mqdefault.jpg",
            "width": 320,
            "height": 180
          },
          "high": {
            "url": "https://i.ytimg.com/vi/VSRH7_22zzE/hqdefault.jpg",
            "width": 480,
            "height": 360
          },
          "standard": {
            "url": "https://i.ytimg.com/vi/VSRH7_22zzE/sddefault.jpg",
            "width": 640,
            "height": 480
          },
          "maxres": {
            "url": "https://i.ytimg.com/vi/VSRH7_22zzE/maxresdefault.jpg",
            "width": 1280,
            "height": 720
          }
        },
        "channelTitle": "UPPUM MULAKUM LITE",
        "categoryId": "22",
        "liveBroadcastContent": "none",
        "localized": {
          "title": "പൊന്നൂന്റെ പ്രസവം കഴിഞ്ഞു👩‍🍼👩‍🍼",
          "description": ""
        },
        "defaultAudioLanguage": "ml"
      },
      "contentDetails": {
        "duration": "PT13M36S",
        "dimension": "2d",
        "definition": "hd",
        "caption": "false",
        "licensedContent": true,
        "contentRating": {
          
        },
        "projection": "rectangular"
      },
      "statistics": {
        "viewCount": "181896",
        "likeCount": "4399",
        "favoriteCount": "0",
        "commentCount": "367"
      }
    },
    {
      "kind": "youtube#video",
      "etag": "63evCUCvxizt1s6JqppBxDHdFO0",
      "id": "V7Nd63vm65w",
      "snippet": {
        "publishedAt": "2023-10-19T11:52:49Z",
        "channelId": "UCNhaliLwhGH9wX3pe9bFTbA",
        "title": "Leo | Vijay | Lokesh | Lokesh Kanagaraj | My Opinion | Malayalam",
        "description": "Register Now: https://forms.gle/gNdgEDhYdEpfajuz8\nFor more details and to get exclusive offers on stock market integrated course by Entri Finacademy, \nCall: 8921626124",
        "thumbnails": {
          "default": {
            "url": "https://i.ytimg.com/vi/V7Nd63vm65w/default.jpg",
            "width": 120,
            "height": 90
          },
          "medium": {
            "url": "https://i.ytimg.com/vi/V7Nd63vm65w/mqdefault.jpg",
            "width": 320,
            "height": 180
          },
          "high": {
            "url": "https://i.ytimg.com/vi/V7Nd63vm65w/hqdefault.jpg",
            "width": 480,
            "height": 360
          },
          "standard": {
            "url": "https://i.ytimg.com/vi/V7Nd63vm65w/sddefault.jpg",
            "width": 640,
            "height": 480
          },
          "maxres": {
            "url": "https://i.ytimg.com/vi/V7Nd63vm65w/maxresdefault.jpg",
            "width": 1280,
            "height": 720
          }
        },
        "channelTitle": "LifeofShazzam",
        "categoryId": "22",
        "liveBroadcastContent": "none",
        "localized": {
          "title": "Leo | Vijay | Lokesh | Lokesh Kanagaraj | My Opinion | Malayalam",
          "description": "Register Now: https://forms.gle/gNdgEDhYdEpfajuz8\nFor more details and to get exclusive offers on stock market integrated course by Entri Finacademy, \nCall: 8921626124"
        }
      },
      "contentDetails": {
        "duration": "PT7M29S",
        "dimension": "2d",
        "definition": "hd",
        "caption": "false",
        "licensedContent": true,
        "contentRating": {
          
        },
        "projection": "rectangular"
      },
      "statistics": {
        "viewCount": "1217642",
        "likeCount": "115923",
        "favoriteCount": "0",
        "commentCount": "5302"
      }
    },
    {
      "kind": "youtube#video",
      "etag": "VXM1oZZsj1daT1IgwueBNDCsxHk",
      "id": "Rel8fZE9mi0",
      "snippet": {
        "publishedAt": "2023-10-19T12:41:43Z",
        "channelId": "UCIihexFQucy1Sm7V7yvL_mA",
        "title": "Leo Movie Review | Yogi Bolta Hai",
        "description": "Leo movie review by Yogi Bolta Hai\nLeo movie review\nLeo Review\n#Leo #LeoMovie #LeoMovieReview #ThalapathyVijay #YogiBoltaHai\n\nLeo, leo movie, leo review, leo movie review, review, LCU, Lokesh Cinematic universe, Lokesh, Joseph Vijay, Thalapathi, thalapathy, vijay Thalapathi, new movie, cinematic universe, south movie, Hindi Dubbed, Krishna Abhishek, Yogi bolta hai, leo ratings, mass movie, sanjay dutt,\n\nFollow Yogi on Instagram - \nhttps://www.instagram.com/yogirokde\n\nEditor - maxstudios1722@gmail.com\n\nNote: - All Images, Pictures, Music used in the video belongs to the respected owners.\n\nDisclaimer: - This channel DOES NOT promote or encourage any illegal activities. All content provided by this channel is meant for EDUCATIONAL and INFORMATIONAL PURPOSE only. \n\nCopyright Disclaimer: - Under section 107 of the copyright Act 1976, allowance is made for FAIR USE for purpose such as criticism, comment, news reporting, teaching, scholarship and research. Fair use is a use permitted by copyright statues that might otherwise be infringing. Non- Profit, educational or personal use tips the balance in favor of FAIR USE.\n\nChannel Disclaimer – Yogi Bolta Hai is the FILM REVIIEW channel dedicated to Review Films, Web Series, Songs, and Trailers. Yogi Bolta Hai channel sometimes use Film Clips, TV series Clips, Web Series Clips, Animation Series Clips to explain about the Film, Web Series, Trailers and Songs, but all under section 107 of the copyright Act 1976, allowance is made for FAIR USE for purpose such as criticism, comment, news reporting, teaching, scholarship and research.",
        "thumbnails": {
          "default": {
            "url": "https://i.ytimg.com/vi/Rel8fZE9mi0/default.jpg",
            "width": 120,
            "height": 90
          },
          "medium": {
            "url": "https://i.ytimg.com/vi/Rel8fZE9mi0/mqdefault.jpg",
            "width": 320,
            "height": 180
          },
          "high": {
            "url": "https://i.ytimg.com/vi/Rel8fZE9mi0/hqdefault.jpg",
            "width": 480,
            "height": 360
          },
          "standard": {
            "url": "https://i.ytimg.com/vi/Rel8fZE9mi0/sddefault.jpg",
            "width": 640,
            "height": 480
          },
          "maxres": {
            "url": "https://i.ytimg.com/vi/Rel8fZE9mi0/maxresdefault.jpg",
            "width": 1280,
            "height": 720
          }
        },
        "channelTitle": "YOGI BOLTA HAI",
        "tags": [
          "Leo",
          "leo movie",
          "leo review",
          "leo movie review",
          "review",
          "LCU",
          "Lokesh Cinematic universe",
          "Lokesh",
          "Joseph Vijay",
          "Thalapathi",
          "thalapathy",
          "vijay Thalapathi",
          "new movie",
          "cinematic universe",
          "south movie",
          "Hindi Dubbed",
          "Krishna Abhishek",
          "Yogi bolta hai",
          "leo ratings",
          "mass movie",
          "sanjay dutt"
        ],
        "categoryId": "24",
        "liveBroadcastContent": "none",
        "localized": {
          "title": "Leo Movie Review | Yogi Bolta Hai",
          "description": "Leo movie review by Yogi Bolta Hai\nLeo movie review\nLeo Review\n#Leo #LeoMovie #LeoMovieReview #ThalapathyVijay #YogiBoltaHai\n\nLeo, leo movie, leo review, leo movie review, review, LCU, Lokesh Cinematic universe, Lokesh, Joseph Vijay, Thalapathi, thalapathy, vijay Thalapathi, new movie, cinematic universe, south movie, Hindi Dubbed, Krishna Abhishek, Yogi bolta hai, leo ratings, mass movie, sanjay dutt,\n\nFollow Yogi on Instagram - \nhttps://www.instagram.com/yogirokde\n\nEditor - maxstudios1722@gmail.com\n\nNote: - All Images, Pictures, Music used in the video belongs to the respected owners.\n\nDisclaimer: - This channel DOES NOT promote or encourage any illegal activities. All content provided by this channel is meant for EDUCATIONAL and INFORMATIONAL PURPOSE only. \n\nCopyright Disclaimer: - Under section 107 of the copyright Act 1976, allowance is made for FAIR USE for purpose such as criticism, comment, news reporting, teaching, scholarship and research. Fair use is a use permitted by copyright statues that might otherwise be infringing. Non- Profit, educational or personal use tips the balance in favor of FAIR USE.\n\nChannel Disclaimer – Yogi Bolta Hai is the FILM REVIIEW channel dedicated to Review Films, Web Series, Songs, and Trailers. Yogi Bolta Hai channel sometimes use Film Clips, TV series Clips, Web Series Clips, Animation Series Clips to explain about the Film, Web Series, Trailers and Songs, but all under section 107 of the copyright Act 1976, allowance is made for FAIR USE for purpose such as criticism, comment, news reporting, teaching, scholarship and research."
        },
        "defaultAudioLanguage": "zxx"
      },
      "contentDetails": {
        "duration": "PT3M45S",
        "dimension": "2d",
        "definition": "hd",
        "caption": "false",
        "licensedContent": true,
        "contentRating": {
          
        },
        "projection": "rectangular"
      },
      "statistics": {
        "viewCount": "615488",
        "likeCount": "40990",
        "favoriteCount": "0",
        "commentCount": "1653"
      }
    },
    {
      "kind": "youtube#video",
      "etag": "eYG9IeCS_9sibXWmVebftvycv1M",
      "id": "7rX1js_bdxI",
      "snippet": {
        "publishedAt": "2023-10-19T08:25:06Z",
        "channelId": "UCWSyWK6oS5VL3RrJZuWsdSA",
        "title": "Apne Ajeeb Khisse (Part-2) | Hyderabadi Comedy | Warangal Diaries",
        "description": "#Ad #KhiladiApp #Paidpartnership \n\nCheckout Khiladi App\nhttps://bit.ly/45RfJXr\n\nApne ajeeb khisse: three types of different people in this world who are very rarely found and crazy relatable scenes It's all about fun & hyderabadi comedy make sure you guys like comment and share this video with your friends, family.\n\nNEW HERE? Subscribe to our channel by clicking on the link below! \nhttps://www.youtube.com/channel/UCWSyWK6oS5VL3RrJZuWsdSA?sub_confirmation=1\n\nFollow us on social media: \nFacebook :- https://www.facebook.com/WarangalDiaries\nTwitter :- https://www.twitter.com/WarangalDiaries\nInstagram :- https://www.instagram.com/WarangalDiaries\nGoogle+ :- https://www.plus.google.com/+Warangaldiarieschannel\nYoutube :- https://www.youtube.com/WarangalDiariesChannel\n\nSocial media links of artists:\n\nNABEEL AFRIDI\nYouTube channel: https://www.youtube.com/@NabeelAfridi\nInstagram :- https://www.instagram.com/IamNabeelAfridi\nFacebook: https://www.facebook.com/IamNabeelAfridi\nTwitter :-  https://www.twitter.com/IamNabeelAfridi\nSnapchat :- IamNabeelAfridi\n\nSHARJEEL ALI\nYouTube channel: https://www.youtube.com/@iamsharjeelali\nInstagram: https://www.instagram.com/iamsharjeelali\n\nREHAN WAQHAR\nYouTube chanel: https://www.youtube.com/@TheRehaanWaqhar\nInstagram: https://www.instagram.com/the_rehan_waqhar\n\n\nTEAM: Sonu shahnawaz, Sameer shaik, Irshan rider, Raouf lala, Fayaz shaik.\n\nWarangal Diaries bringing you the best hyderabadi linguistic vines & funny videos which you can relate with everyone's routine life.\nWe will make you smile, We will win your hearts.\n\n#Hyderabadicomedy #Warangaldiaries #Nabeelproductions\n\n'EVERY SUNDAY A NEW VIDEO' #warangaldiariesfamily :)",
        "thumbnails": {
          "default": {
            "url": "https://i.ytimg.com/vi/7rX1js_bdxI/default.jpg",
            "width": 120,
            "height": 90
          },
          "medium": {
            "url": "https://i.ytimg.com/vi/7rX1js_bdxI/mqdefault.jpg",
            "width": 320,
            "height": 180
          },
          "high": {
            "url": "https://i.ytimg.com/vi/7rX1js_bdxI/hqdefault.jpg",
            "width": 480,
            "height": 360
          },
          "standard": {
            "url": "https://i.ytimg.com/vi/7rX1js_bdxI/sddefault.jpg",
            "width": 640,
            "height": 480
          },
          "maxres": {
            "url": "https://i.ytimg.com/vi/7rX1js_bdxI/maxresdefault.jpg",
            "width": 1280,
            "height": 720
          }
        },
        "channelTitle": "Warangal Diaries",
        "tags": [
          "warangal diaries",
          "latest",
          "funny",
          "comedy",
          "vines",
          "warangal diaries new video",
          "warangal diaries latest video",
          "warangal diaries comedy",
          "warangal diaries funny",
          "hyderabadi comedy",
          "hyderabad",
          "apne ajeeb khisse",
          "funny weird things",
          "warangal diaries comedy video",
          "apne ajeeb khisse funny video",
          "apne ajeeb khisse hyderabadi comedy",
          "world full of different people",
          "hyderabadi humour",
          "hyderabad diaries",
          "shehbaaz khan",
          "part 2",
          "apne ajeeb khisse part 2",
          "ajeeb khisse",
          "episode 2",
          "pichi yakuu"
        ],
        "categoryId": "23",
        "liveBroadcastContent": "none",
        "defaultLanguage": "en-GB",
        "localized": {
          "title": "Apne Ajeeb Khisse (Part-2) | Hyderabadi Comedy | Warangal Diaries",
          "description": "#Ad #KhiladiApp #Paidpartnership \n\nCheckout Khiladi App\nhttps://bit.ly/45RfJXr\n\nApne ajeeb khisse: three types of different people in this world who are very rarely found and crazy relatable scenes It's all about fun & hyderabadi comedy make sure you guys like comment and share this video with your friends, family.\n\nNEW HERE? Subscribe to our channel by clicking on the link below! \nhttps://www.youtube.com/channel/UCWSyWK6oS5VL3RrJZuWsdSA?sub_confirmation=1\n\nFollow us on social media: \nFacebook :- https://www.facebook.com/WarangalDiaries\nTwitter :- https://www.twitter.com/WarangalDiaries\nInstagram :- https://www.instagram.com/WarangalDiaries\nGoogle+ :- https://www.plus.google.com/+Warangaldiarieschannel\nYoutube :- https://www.youtube.com/WarangalDiariesChannel\n\nSocial media links of artists:\n\nNABEEL AFRIDI\nYouTube channel: https://www.youtube.com/@NabeelAfridi\nInstagram :- https://www.instagram.com/IamNabeelAfridi\nFacebook: https://www.facebook.com/IamNabeelAfridi\nTwitter :-  https://www.twitter.com/IamNabeelAfridi\nSnapchat :- IamNabeelAfridi\n\nSHARJEEL ALI\nYouTube channel: https://www.youtube.com/@iamsharjeelali\nInstagram: https://www.instagram.com/iamsharjeelali\n\nREHAN WAQHAR\nYouTube chanel: https://www.youtube.com/@TheRehaanWaqhar\nInstagram: https://www.instagram.com/the_rehan_waqhar\n\n\nTEAM: Sonu shahnawaz, Sameer shaik, Irshan rider, Raouf lala, Fayaz shaik.\n\nWarangal Diaries bringing you the best hyderabadi linguistic vines & funny videos which you can relate with everyone's routine life.\nWe will make you smile, We will win your hearts.\n\n#Hyderabadicomedy #Warangaldiaries #Nabeelproductions\n\n'EVERY SUNDAY A NEW VIDEO' #warangaldiariesfamily :)"
        },
        "defaultAudioLanguage": "en-GB"
      },
      "contentDetails": {
        "duration": "PT9M10S",
        "dimension": "2d",
        "definition": "hd",
        "caption": "false",
        "licensedContent": true,
        "contentRating": {
          
        },
        "projection": "rectangular"
      },
      "statistics": {
        "viewCount": "160783",
        "likeCount": "10633",
        "favoriteCount": "0",
        "commentCount": "312"
      }
    }
  ]