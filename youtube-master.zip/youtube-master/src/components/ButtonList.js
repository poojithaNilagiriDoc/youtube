import React from "react";
import Button from "./Button";
const ButtonList= () =>{
    return(
        <div className="flex flex-wrap"> 
            <Button  name="All" />
            <Button name = "Mixes" />
            <Button name="Live" />
            <Button name="Dramedy" />
            <Button name="JavaScript" />
            <Button name="Satsang" />
            <Button name="Lo-fi" />
            <Button name="Arijit singh" />
            <Button name="Lecture" />
            <Button name="News" />
            <Button  name="All" />
            <Button name = "Mixes" />
            <Button name="Live" />
            <Button name="Dramedy" />
            <Button name="JavaScript" />
            <Button name="Satsang" />
            <Button name="Lo-fi" />
            <Button name="Arijit singh" />
            <Button name="Lecture" />
            <Button name="News" />
        </div>
    )
}
export default ButtonList;

// AIzaSyBAubYkDr5e2UiKeBY1IZwlhMifex3urdc